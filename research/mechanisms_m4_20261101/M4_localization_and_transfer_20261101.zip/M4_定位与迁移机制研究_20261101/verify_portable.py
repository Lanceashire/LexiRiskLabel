"""Independent endpoint recomputation from public label-world risks, no GPU."""
from pathlib import Path
import argparse,hashlib,json
import numpy as np
import pandas as pd
from scipy.stats import t,spearmanr
ROOT=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--examples',action='store_true');a=ap.parse_args();manifest=json.loads((ROOT/'SHA256_MANIFEST.json').read_text())
    for rel,h in manifest['files'].items():assert sha(ROOT/rel)==h,rel
    plan=json.loads((ROOT/'protocols/registration.json').read_text());maximum=0.;intervals=0;world_checks=0
    for role in ['family_confirmation','transfer']:
        if not (ROOT/'tables'/role).exists():continue
        tab=ROOT/'tables'/role;f=pd.read_csv(tab/'label_world_risks.csv.gz');s=pd.read_csv(tab/'world_summary.csv');p=pd.read_csv(tab/'primary_intervals.csv')
        assert set(f.world_id)==set(plan[role+'_worlds'])
        if role=='family_confirmation':
            winner=pd.read_csv(tab/'search_winners.csv');lookup=winner.set_index(['world_id','condition','learner'])
        recomputed=[]
        for (w,c,learner),q in f.groupby(['world_id','condition','learner']):
            ev=q[q.split=='eval'].groupby('method').risk.mean();r={'world_id':w,'condition':c,'learner':learner,'direction':c.split('_')[1],'structure':c.split('_')[0],'Pending_aware_gain':float(ev.MinRisk-ev['Pending-aware'])}
            if role=='family_confirmation':
                wh=int(lookup.loc[w,c,learner].set_id);srch=q[q.split=='search'].groupby('set_id',sort=False).risk.mean();assert int(srch.idxmin())==wh
                risk=float(q[(q.split=='eval')&(q.set_id==wh)].drop_duplicates(['replicate','set_id']).risk.mean());r['heldout_search_winner_gain']=float(ev.MinRisk-risk)
            else:r['ParBaLS_minus_PA']=float(ev.ParBaLS-ev['Pending-aware'])
            recomputed.append(r)
        actual=pd.DataFrame(recomputed)
        for r in p.itertuples():
            q=actual[(actual.learner==r.learner)&(actual.direction==r.direction)]
            if role=='family_confirmation':x=q[r.metric]
            elif r.metric=='ParBaLS_minus_PA/linear':x=q[q.structure=='linear'].ParBaLS_minus_PA
            else:
                qq=q.pivot(index='world_id',columns='structure',values='Pending_aware_gain');x=qq.nonlinear-qq.linear
            n=len(x);mean=float(x.mean());se=float(x.std(ddof=1)/np.sqrt(n));rad=float(t.ppf(1-r.family_alpha/(2*r.family),n-1)*se)
            assert n==r.n_worlds;maximum=max(maximum,abs(mean-r.mean),abs(se-r.SE),abs(mean-rad-r.low),abs(mean+rad-r.high));intervals+=1
        world_checks+=actual.world_id.nunique()
    if (ROOT/'tables/mc_diagnostic').exists():
        tab=ROOT/'tables/mc_diagnostic';f=pd.read_csv(tab/'model_label_world_risks.csv.gz');s=pd.read_csv(tab/'selection_results.csv');p=pd.read_csv(tab/'primary_intervals.csv')
        raw=[]
        for (w,d,l),q in f.groupby(['world_id','direction','learner']):
            v=q[q.bank==2].groupby('set_id').risk.mean()
            for bank in [0,1]:
                scores=q[q.bank==bank].pivot(index='replicate',columns='set_id',values='risk')
                for M in [2,16,128]:
                    picked=int(scores.iloc[:M].mean().idxmin());risk=float(v[picked]);z=s[(s.world_id==w)&(s.direction==d)&(s.learner==l)&(s.bank==bank)&(s.M==M)].iloc[0]
                    assert picked==z.winner;maximum=max(maximum,abs(risk-z.model_verification_risk));raw.append({'world_id':w,'direction':d,'learner':l,'bank':bank,'M':M,'risk':risk})
        raw=pd.DataFrame(raw)
        for r in p.itertuples():
            q=raw[(raw.direction==r.direction)&(raw.learner==r.learner)].pivot(index=['world_id','bank'],columns='M',values='risk');x=(q[2]-q[128]).groupby('world_id').mean();se=float(x.std(ddof=1)/np.sqrt(len(x)));rad=float(t.ppf(1-r.family_alpha/(2*r.family),len(x)-1)*se)
            maximum=max(maximum,abs(x.mean()-r.mean),abs(se-r.SE),abs(x.mean()-rad-r.low),abs(x.mean()+rad-r.high));intervals+=1
    examples=0
    if a.examples:
        # One complete first-ID family world is included. Recompute every risk directly.
        from scipy.special import expit
        for dest in (ROOT/'examples/family_confirmation').glob('w[0-9]*'):
            with np.load(dest/'inputs.npz') as z:inputs={k:z[k] for k in z.files}
            fits=pd.read_csv(dest/'fits.csv')
            for (c,split),q in fits.groupby(['condition','split']):
                with np.load(dest/f'{c}_{split}_predictions.npz') as z:pred={k:z[k] for k in z.files}
                structure=c.split('_')[0];T=inputs[structure+'_'+split+'_T'];truth=inputs[structure+'_'+split+'_p']
                for r in q.itertuples():
                    pr=expit(T@pred['LR_coefficients'][r.prediction_index]) if r.learner=='LR' else pred['XGB_predictions'][r.prediction_index].astype(float)
                    maximum=max(maximum,abs(np.mean((pr-truth)**2)-r.risk))
            examples+=1
    assert maximum<1e-12,maximum
    result={'passed':True,'intervals_recomputed':intervals,'maximum_recomputation_error':maximum,'independent_world_sets_checked':int(world_checks),'raw_family_examples_recomputed':examples,'manifest_files':len(manifest['files']),'GPU_or_new_training_required':False,'scope':'all registered endpoint intervals and MC winner-risk accounting; complete local raw audits are indexed, public example is first-ID world'}
    (ROOT/'portable_verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
