"""Prepare a relocated, new-identity retraining copy; never mutate evidence."""
from pathlib import Path
import argparse,datetime,hashlib,json,shutil
ROOT=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
    p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);a=p.parse_args();out=a.out.resolve();assert not out.exists(),'Use a new empty output path'
    assert (ROOT/'SHA256_MANIFEST.json').exists(),'Run the copy included in the published evidence package'
    manifest=json.loads((ROOT/'SHA256_MANIFEST.json').read_text())
    for rel,h in manifest['files'].items():assert sha(ROOT/rel)==h,rel
    out.mkdir(parents=True);shutil.copytree(ROOT/'code',out,dirs_exist_ok=True)
    for name in ['registration.json','mc_registration.json','stage_governance_v1.json','controlling_plan_v2.txt']:shutil.copy2(ROOT/'protocols'/name,out/name)
    plan=json.loads((out/'registration.json').read_text());original_main=sha(ROOT/'protocols/registration.json');original_mc=sha(ROOT/'protocols/mc_registration.json')
    oldhashes=plan['source_hashes'].copy();plan['version']+='_relocated_public_reproduction';plan['source_hashes']={rel:sha(out/rel) for rel in oldhashes}
    plan['reproduction_provenance']={'original_main_registration_sha256':original_main,'purpose':'fresh reproduction identity for path-redacted relocated source; numerical design, seeds, estimands and stopping rules unchanged','timestamp_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'original_source_hashes':oldhashes}
    (out/'registration.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n');mc=json.loads((out/'mc_registration.json').read_text());mc['main_registration_sha256']=sha(out/'registration.json');mc['source_hashes']={rel:sha(out/rel) for rel in mc['source_hashes']};mc['original_MC_registration_sha256']=original_mc;(out/'mc_registration.json').write_text(json.dumps(mc,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'prepared_only':True,'new_identity_directory':str(out),'new_main_registration_sha256':sha(out/'registration.json'),'GPU_training_started':False,'commands':['python experiment.py family_confirmation --workers 8','python audit_analyze_v2.py family_confirmation --workers 8','Only if acceptance actual_space_identified: python experiment.py transfer --workers 8; audit with audit_analyze_v2.py transfer','Only if space gate passes: python mc_diagnostic.py run; then python mc_diagnostic.py audit'],'note':'Actual CUDA and pinned dependencies required for retraining; original engineering parity check additionally needs the historical baseline source. Portable verification requires neither historical source nor GPU.'},indent=2))
if __name__=='__main__':main()
