M4机制研究证据包。先读M4_研究报告.txt和M4_ACCEPTANCE.json。
python verify_portable.py --examples 可无需GPU重算登记区间及第一ID原始样例。
冻结源与历史源哈希见protocols；公开导出字节见SHA256_MANIFEST.json。部分代码中LOCAL_WORKSPACE是脱敏路径占位。
如需从头重训：python prepare_reproduction.py --out /new/empty/path，生成新身份的独立副本。数值协议和种子不改，但公开路径脱敏导致源字节变化，故重训副本另有身份并记录原件哈希；不会覆盖正式证据。实际CUDA和固定依赖为重训要求。旧生成器逐字节工程对照还需要历史源码，便携区间复核不需要。M5未执行。
