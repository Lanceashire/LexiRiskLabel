"""Independent finite-family confirmation and bounded method/structure transfer."""
from common import *
from neighbor import select_neighbor
import concurrent.futures

def run_world(args):
    w,role,plan=args;check(plan);dest=HERE/role/f'w{w}';planhash=sha(HERE/'registration.json')
    if (dest/'complete.json').exists():
        d=json.loads((dest/'complete.json').read_text());assert d['plan_sha256']==planhash;return d
    if dest.exists():dest.rename(dest.with_name(dest.name+'_interrupted_'+str(time.time_ns())))
    dest.mkdir(parents=True);start=time.perf_counter();cfg=plan['config'];contexts=[];locks=[];saver={};metadata=[]
    for nonlinear in ([False] if role=='family_confirmation' else [False,True]):
        structure='nonlinear' if nonlinear else 'linear';e=environment(w,cfg,nonlinear);ids=e['candidate_ids'];tag=structure+'_'
        for k in ['D','yD','C','Q','theta','candidate_ids']:saver[tag+k]=e[k]
        saver[tag+'cost']=e['costs']['neutral'];saver[tag+'B']=e['B']
        for direction in ['target','unlock']:
            s=state(e,w,cfg,direction);cid=structure+'_'+direction;saver[cid+'_O']=s.ordinary_x
            if role=='family_confirmation':a=family(s,ids,w);nd={}
            else:
                a=four(s,ids);a['ParBaLS'],di=select_neighbor(s,plan['neighbor']);nd={k:di[k] for k in ['internal_LR_refits','selection_seconds']}
                np.savez_compressed(dest/f'{cid}_neighbor_fantasies.npz',theta=di['universe_parameters'],ordinary=di['fantasy_ordinary_labels'],candidate=di['fantasy_candidate_labels'])
            unique={};lookup={};h,g,u=core.geometry(s,True)
            for method,idx in a.items():
                assert s.cost[idx].sum()<=s.budget+1e-8 and len(idx)==len(np.unique(idx));key=tuple(np.sort(idx).tolist());lookup[method]=key
                unique.setdefault(key,[]).append(method)
                locks.append({'condition':cid,'method':method,'selected_indices':idx,'selected_ids':ids[idx],'select_hash':core.digest(ids[idx]),'cost':float(s.cost[idx].sum()),'count':len(idx),'B':s.budget,'proxy':core.set_value(h,g,u,idx)})
            assert len(unique)<=16
            contexts.append((cid,nonlinear,direction,e,s,unique,lookup));metadata.append({'condition':cid,'family_size':len(unique),'neighbor':nd})
    write(dest/'selection_locks.json',locks);locksha=sha(dest/'selection_locks.json');write(dest/'selection_commitment.json',{'all_selections_locked_before_any_future_label_draw_or_outcome_fit':True,'sha256':locksha,'conditions':metadata})
    # Separate evaluation references and label worlds; no true future labels enter acquisition.
    for nonlinear in ([False] if role=='family_confirmation' else [False,True]):
        structure='nonlinear' if nonlinear else 'linear'
        for split,t in [('search',89001),('eval',89002)]:
            T,p=target(w,t,plan['reference_n'],nonlinear);saver[structure+'_'+split+'_T']=T;saver[structure+'_'+split+'_p']=p
    rows=[];fits=[];stored={};winners=[]
    splits=['search','eval'] if role=='family_confirmation' else ['eval']
    for split in splits:
        reps=list(range(plan['search_M'])) if split=='search' else list(range(1000,1000+(plan['eval_M'] if role=='family_confirmation' else plan['transfer_M'])))
        if split=='eval' and role=='family_confirmation':
            frame=pd.DataFrame(rows)
            for cid,nonlinear,direction,e,s,unique,lookup in contexts:
                for learner in ['LR','XGB']:
                    m=frame[(frame.condition==cid)&(frame.learner==learner)].groupby('set_id',sort=False).risk.mean();winner=int(m.idxmin());winners.append({'condition':cid,'learner':learner,'set_id':winner,'search_risk':float(m[winner])})
            write(dest/'search_winners.json',winners);winnerhash=sha(dest/'search_winners.json')
        for cid,nonlinear,direction,e,s,unique,lookup in contexts:
            structure='nonlinear' if nonlinear else 'linear';T=saver[structure+'_'+split+'_T'];p=saver[structure+'_'+split+'_p'];predstore={};coefs=[];xgbpred=[]
            for rep in reps:
                g=rng(w,88001,rep);yo=(g.random(len(s.ordinary_x))<probability(s.ordinary_x,nonlinear)).astype(np.uint8);yc=(g.random(len(s.candidate_x))<probability(s.candidate_x,nonlinear)).astype(np.uint8)
                for setid,(key,names) in enumerate(unique.items()):
                    idx=np.array(key,int);x=np.vstack([s.visible_x,s.ordinary_x,s.candidate_x[idx]]);y=np.r_[s.visible_y,yo,yc[idx]]
                    for learner in ['LR','XGB']:
                        pred,saved,backend,seconds=fitted(x,y,[T],w,learner,cfg);pr=pred[0];fitid=len(fits)
                        if learner=='LR':pi=len(coefs);coefs.append(saved)
                        else:pi=len(xgbpred);xgbpred.append(saved)
                        fits.append({'fit_id':fitid,'condition':cid,'split':split,'replicate':rep,'set_id':setid,'primary_name':names[0],'learner':learner,'prediction_index':pi,'backend':backend,'train_x_hash':core.digest(x),'train_y_hash':core.digest(y),'train_n':len(y),'risk':float(np.mean((pr-p)**2)),'seconds':seconds})
                        for method in names:rows.append({'world_id':w,'condition':cid,'structure':structure,'direction':direction,'split':split,'replicate':rep,'set_id':setid,'method':method,'learner':learner,'risk':fits[-1]['risk'],'fit_id':fitid})
            np.savez_compressed(dest/f'{cid}_{split}_predictions.npz',LR_coefficients=np.array(coefs),XGB_predictions=np.array(xgbpred,dtype=np.float32))
            pd.DataFrame(fits).to_csv(dest/'fits.csv',index=False)
    np.savez_compressed(dest/'inputs.npz',**saver);pd.DataFrame(rows).to_csv(dest/'outcomes.csv',index=False);assert sha(dest/'selection_locks.json')==locksha
    if role=='family_confirmation':assert sha(dest/'search_winners.json')==winnerhash
    done={'completed':True,'world_id':w,'role':role,'plan_sha256':planhash,'unique_fits':len(fits),'outcome_rows':len(rows),'seconds':time.perf_counter()-start,'files':{p.name:sha(p) for p in dest.iterdir() if p.is_file()}}
    write(dest/'complete.json',done);return done

def main():
    p=argparse.ArgumentParser();p.add_argument('role',choices=['engineering','family_confirmation','transfer']);p.add_argument('--workers',type=int,default=8);a=p.parse_args();plan=json.loads((HERE/'registration.json').read_text());check(plan)
    ids=plan[a.role+'_worlds'];(HERE/a.role).mkdir(exist_ok=True)
    if a.role=='transfer':assert json.loads((HERE/'family_confirmation/acceptance.json').read_text())['actual_space_identified'], 'No additional model diagnostic/transfer computation before independent space evidence'
    with concurrent.futures.ProcessPoolExecutor(max_workers=a.workers) as pool:
        for r in pool.map(run_world,[(w,a.role,plan) for w in ids]):print(json.dumps({k:r[k] for k in ['world_id','unique_fits','seconds']}),flush=True)
    reports=[json.loads((HERE/a.role/f'w{w}/complete.json').read_text()) for w in ids]
    write(HERE/a.role/'completion.json',{'completed':True,'role':a.role,'worlds':len(ids),'unique_fits':sum(r['unique_fits'] for r in reports),'plan_sha256':sha(HERE/'registration.json')});print((HERE/a.role/'completion.json').read_text(),flush=True)
if __name__=='__main__':main()
