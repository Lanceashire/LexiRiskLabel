from pathlib import Path
from dataclasses import replace
import argparse,hashlib,json,sys,time,os
import numpy as np
import pandas as pd
from scipy.special import expit
from xgboost import XGBClassifier
from deps import core,exact,base,stage_gate
HERE=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def default(x):
    if isinstance(x,np.ndarray):return x.tolist()
    if isinstance(x,np.generic):return x.item()
    if isinstance(x,Path):return str(x)
    raise TypeError(type(x).__name__)
def write(p,x):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);tmp=p.with_name(p.name+'.tmp');tmp.write_text(json.dumps(x,ensure_ascii=False,indent=2,default=default)+'\n');tmp.replace(p)
def rng(w,t,r=0):return np.random.default_rng(np.random.SeedSequence([w,t,r]))
def probability(x,nonlinear=False):return expit(x@np.array([-1,.8,1.4,0,0])+(.8*(x[:,2]**2-1) if nonlinear else 0))
def target(w,tag,n,nonlinear=False):
    g=rng(w,tag);x=np.zeros((n,5));x[:,0]=1;x[:,1]=g.uniform(-2,2.2,n);x[:,2]=g.normal(0,1.2,n);return x,probability(x,nonlinear)
def environment(w,cfg,nonlinear=False):
    e=base.environment(w,cfg)
    if nonlinear:
        e['yD']=(rng(w,30).random(len(e['D']))<probability(e['D'],True)).astype(np.uint8)
        e['theta']=core.fit_logistic(e['D'],e['yD'],cfg['lr_ridge'])
    return e
def state(e,w,cfg,direction):
    d=np.array(cfg['directions'][direction]);o=e['O'].copy();o[:,2:]=e['O'][:,2,None]*d
    return core.State(e['D'],e['yD'],o,e['C'],e['Q'],e['costs']['neutral'],e['B'],e['theta'],w,ridge=cfg['lr_ridge'],exchanges=0)
def four(s,ids):
    order=np.lexsort((ids,s.cost));k=core.kstar(s.cost,s.budget);a={'OrdinaryOnly':np.empty(0,int),'MinRisk':np.sort(order[:k])}
    for c,n in [(False,'D-only'),(True,'Pending-aware')]:
        h,g,u=core.geometry(s,c);a[n]=np.sort(exact.greedy(h,g,u,s.cost,s.budget,ids))
    return a
def family(s,ids,w):
    a=four(s,ids);order=np.lexsort((ids,s.cost));k=core.kstar(s.cost,s.budget)
    for pct in [25,50,75]:a[f'MinRisk-k{pct}']=np.sort(order[:int(k*pct/100)])
    for cond,name in [(False,'D-static'),(True,'Pending-static')]:
        h,g,u=core.geometry(s,cond);v=core.marginal(core.inverse(h),g,u);order=np.lexsort((ids,-v/s.cost));chosen=[];left=s.budget
        for i in order:
            if s.cost[i]<=left+1e-12 and v[i]>1e-15:chosen.append(int(i));left-=s.cost[i]
        a[name]=np.sort(np.array(chosen,int))
    for r in range(4):
        chosen=[];left=s.budget
        for i in np.argsort(ids,kind='stable')[rng(w,87001,r).permutation(len(ids))]:
            if s.cost[i]<=left+1e-12:chosen.append(int(i));left-=s.cost[i]
        a[f'Random-{r}']=np.sort(np.array(chosen,int))
    return a
def check(plan):
    policy=json.loads((HERE/'stage_governance_v1.json').read_text());stage_gate.require_stage('M4',policy);assert policy['M4_training_authorized']
    for f,h in plan['source_hashes'].items():assert sha(HERE/f)==h,('source drift',f)
def fitted(x,y,refs,w,learner,cfg):
    tick=time.perf_counter()
    if learner=='LR':
        coef=core.fit_logistic(x,y,cfg['lr_ridge']);pred=[expit(T@coef) for T in refs];backend='cpu';saved=coef
    else:
        m=XGBClassifier(**cfg['xgb'],random_state=w+7000,objective='binary:logistic',eval_metric='logloss');m.fit(x[:,1:].astype(np.float32),y)
        conf=json.loads(m.get_booster().save_config())['learner'];backend=conf['generic_param']['device'];assert backend.startswith('cuda')
        def find(o,k):return ([o[k]] if k in o else [])+[v for c in o.values() if isinstance(c,dict) for v in find(c,k)]
        assert set(find(conf,'max_bin'))=={'256'} and set(find(conf,'max_depth'))=={'3'} and m.get_booster().num_boosted_rounds()==100
        pred=[m.predict_proba(T[:,1:].astype(np.float32))[:,1].astype(float) for T in refs];saved=pred[0].astype(np.float32)
    return pred,saved,backend,time.perf_counter()-tick
