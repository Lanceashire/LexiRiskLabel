"""Reconstruct legal training and every saved risk before endpoint inference."""
from common import *
from scipy.stats import t,spearmanr
import concurrent.futures
def audit_world(args):
    w,role,plan=args;dest=HERE/role/f'w{w}';done=json.loads((dest/'complete.json').read_text());assert done['plan_sha256']==sha(HERE/'registration.json')
    for f,h in done['files'].items():assert sha(dest/f)==h,(w,f)
    with np.load(dest/'inputs.npz') as z:e={k:z[k] for k in z.files}
    locks=json.loads((dest/'selection_locks.json').read_text());commit=json.loads((dest/'selection_commitment.json').read_text());assert commit['sha256']==sha(dest/'selection_locks.json') and commit['all_selections_locked_before_any_future_label_draw_or_outcome_fit']
    sets={};look={}
    for row in locks:
        cid=row['condition'];ids=np.array(row['selected_indices'],int);assert len(ids)==len(np.unique(ids));structure=cid.split('_')[0];cost=e[structure+'_cost'];B=float(e[structure+'_B'])
        assert cost[ids].sum()<=B+1e-8 and abs(cost[ids].sum()-row['cost'])<1e-12 and core.digest(e[structure+'_candidate_ids'][ids])==row['select_hash']
        if cid not in sets:sets[cid]=[]
        key=tuple(ids.tolist())
        if key not in sets[cid]:sets[cid].append(key)
        look[cid,row['method']]=sets[cid].index(key)
    fits=pd.read_csv(dest/'fits.csv');rows=pd.read_csv(dest/'outcomes.csv');errors=[];pred={};maxerr=0.
    for (cid,split),frame in fits.groupby(['condition','split']):
        with np.load(dest/f'{cid}_{split}_predictions.npz') as z:pred={k:z[k] for k in z.files}
        st=cid.split('_')[0];nonlinear=st=='nonlinear';T=e[st+'_'+split+'_T'];p=e[st+'_'+split+'_p'];assert np.array_equal(p,probability(T,nonlinear))
        for row in frame.itertuples():
            idx=np.array(sets[cid][row.set_id],int);O=e[cid+'_O'];C=e[st+'_C'];g=rng(w,88001,row.replicate);yo=(g.random(len(O))<probability(O,nonlinear)).astype(np.uint8);yc=(g.random(len(C))<probability(C,nonlinear)).astype(np.uint8)
            x=np.vstack([e[st+'_D'],O,C[idx]]);y=np.r_[e[st+'_yD'],yo,yc[idx]];assert core.digest(x)==row.train_x_hash and core.digest(y)==row.train_y_hash and len(y)==row.train_n
            if row.learner=='LR':pr=expit(T@pred['LR_coefficients'][row.prediction_index])
            else:pr=pred['XGB_predictions'][row.prediction_index].astype(float);assert row.backend.startswith('cuda')
            risk=float(np.mean((pr-p)**2));maxerr=max(maxerr,abs(risk-row.risk))
    assert maxerr<1e-12
    fitmap=fits.set_index('fit_id')
    for r in rows.itertuples():assert abs(r.risk-fitmap.loc[r.fit_id,'risk'])<1e-15 and r.set_id==look[r.condition,r.method]
    summaries=[];rr=[];ranks=[]
    for (cid,learner),q in rows.groupby(['condition','learner']):
        ev=q[q.split=='eval'].pivot(index='replicate',columns='method',values='risk');means=ev.mean();mine=float(means.MinRisk);pa=float(means['Pending-aware']);proxies={r['method']:r['proxy'] for r in locks if r['condition']==cid};pick=max(proxies,key=proxies.get)
        source=q.groupby('set_id',sort=False).method.first();unique=q[q.split=='eval'].drop_duplicates(['replicate','set_id']).pivot(index='replicate',columns='set_id',values='risk');bestid=int(unique.mean().idxmin())
        row={'world_id':w,'condition':cid,'direction':cid.split('_')[1],'structure':cid.split('_')[0],'learner':learner,'family_size':len(unique.columns),
             'Pending_aware_gain':mine-pa,'D_only_gain':mine-float(means['D-only']),'ordinary_gain':float(means.OrdinaryOnly)-pa,'proxy_family_pick_gain':mine-float(means[pick]),
             'proxy_solver_gap':max(proxies.values())-proxies['Pending-aware'],'empirical_best_gain':mine-float(unique.mean().min()),'empirical_PA_regret':pa-float(unique.mean().min()),'proxy_pick':pick,
             'proxy_rank_correlation':float(spearmanr([proxies[source[k]] for k in unique.columns],[-unique[k].mean() for k in unique.columns]).statistic)}
        if role=='family_confirmation':
            winners=json.loads((dest/'search_winners.json').read_text());winner=next(r for r in winners if r['condition']==cid and r['learner']==learner);search=q[q.split=='search'].groupby('set_id').risk.mean();assert int(search.idxmin())==winner['set_id']
            wh=winner['set_id'];row.update({'heldout_search_winner_gain':mine-float(unique[wh].mean()),'winner_agrees_with_eval':int(wh==bestid),'winner_name':source[wh]})
        else:row['ParBaLS_minus_PA']=float(means.ParBaLS)-pa;row['ParBaLS_gain']=mine-float(means.ParBaLS)
        summaries.append(row)
        for method,val in means.items():rr.append({'world_id':w,'condition':cid,'learner':learner,'method':method,'risk':float(val),'gain_vs_MinRisk':mine-float(val),'proxy':proxies[method]})
    return {'world_id':w,'maximum_risk_error':maxerr,'fits':len(fits),'rows':len(rows),'summaries':summaries,'means':rr}
def ci(x,family,alpha):
    x=np.asarray(x,float);n=len(x);mean=float(x.mean());se=float(x.std(ddof=1)/np.sqrt(n));rad=float(t.ppf(1-alpha/(2*family),n-1)*se)
    return {'n_worlds':n,'mean':mean,'SE':se,'low':mean-rad,'high':mean+rad,'family':family,'family_alpha':alpha}
def verdict(r):
    lo,hi=r['low'],r['high'];d=.0001
    return 'meaningful_positive' if lo>d else 'meaningful_negative' if hi< -d else 'positive_direction_only' if lo>0 else 'negative_direction_only' if hi<0 else 'within_delta_band' if lo>=-d and hi<=d else 'unresolved'
def main():
    p=argparse.ArgumentParser();p.add_argument('role',choices=['engineering','family_confirmation','transfer']);p.add_argument('--workers',type=int,default=8);a=p.parse_args();plan=json.loads((HERE/'registration.json').read_text());check(plan);root=HERE/a.role
    assert json.loads((root/'completion.json').read_text())['completed'];ids=plan[a.role+'_worlds']
    with concurrent.futures.ProcessPoolExecutor(max_workers=a.workers) as pool:results=list(pool.map(audit_world,[(w,a.role,plan) for w in ids]))
    s=pd.DataFrame([r for x in results for r in x['summaries']]);s.to_csv(root/'world_summary.csv',index=False);pd.DataFrame([r for x in results for r in x['means']]).to_csv(root/'world_method_means.csv',index=False)
    audit={'passed':True,'worlds':len(ids),'fits_reconstructed':sum(r['fits'] for r in results),'outcome_rows':sum(r['rows'] for r in results),'maximum_risk_error':max(r['maximum_risk_error'] for r in results),'label_draws_training_membership_and_all_risks_reconstructed':True};write(root/'audit.json',audit)
    if a.role=='engineering':print(json.dumps(audit),flush=True);return
    primary=[];extra=[]
    if a.role=='family_confirmation':
        for direction in ['target','unlock']:
            for learner in ['LR','XGB']:
                q=s[(s.direction==direction)&(s.learner==learner)]
                for metric in ['heldout_search_winner_gain','Pending_aware_gain']:
                    r={'learner':learner,'direction':direction,'metric':metric,'role':'primary' if learner=='LR' else 'exploratory_transfer',**(ci(q[metric],4,.02) if learner=='LR' else ci(q[metric],1,.05))}
                    r['verdict']=verdict(r);(primary if learner=='LR' else extra).append(r)
                for metric in ['proxy_family_pick_gain','proxy_rank_correlation','proxy_solver_gap','empirical_best_gain','empirical_PA_regret','winner_agrees_with_eval']:
                    r={'learner':learner,'direction':direction,'metric':metric,'role':'descriptive',**ci(q[metric],1,.05)};extra.append(r)
        space=any(r['low']>.0001 for r in primary);accept={'completed':True,'registered_fixed_endpoint':True,'worlds':len(ids),'all_worlds_audited':True,'primary_contrasts':4,'actual_space_identified':space,'space_rule':'at least one of four simultaneous LR heldout-procedure or prelocked PA gains has lower bound > delta=.0001','MC_and_transfer_entry_authorized':space,'full_feasible_domain_oracle_claim':False}
    else:
        for direction in ['target','unlock']:
            for learner in ['LR','XGB']:
                q=s[(s.direction==direction)&(s.structure=='linear')&(s.learner==learner)];r={'learner':learner,'direction':direction,'metric':'ParBaLS_minus_PA/linear','role':'method_transfer_primary',**ci(q.ParBaLS_minus_PA,4,.01)};r['verdict']=verdict(r);primary.append(r)
            q=s[(s.direction==direction)&(s.learner=='LR')].pivot(index='world_id',columns='structure',values='Pending_aware_gain');r={'learner':'LR','direction':direction,'metric':'nonlinear_minus_linear_PA_gain','role':'structure_primary',**ci(q.nonlinear-q.linear,2,.01)};r['verdict']=verdict(r);primary.append(r)
        accept={'completed':True,'worlds':len(ids),'all_worlds_audited':True,'method_primary_contrasts':4,'structure_primary_contrasts':2,'nonlinear_truth':'linear logit + .8*(z1^2-1), frozen from prior planned form','upstream_NUTS_reproduction':False,'same_pending_reference_cost_and_solver_access':True}
    pd.DataFrame(primary).to_csv(root/'primary_intervals.csv',index=False);pd.DataFrame(extra).to_csv(root/'secondary_descriptive_intervals.csv',index=False);write(root/'acceptance.json',accept);print(pd.DataFrame(primary).to_string(index=False),flush=True);print(json.dumps(accept),flush=True)
if __name__=='__main__':main()
