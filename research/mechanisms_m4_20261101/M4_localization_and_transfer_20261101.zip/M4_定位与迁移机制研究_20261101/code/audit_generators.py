"""Recreate every saved feature/target/model-world draw from frozen seeds."""
from common import *
def main():
    plan=json.loads((HERE/'registration.json').read_text());check(plan);roles={}
    for role in ['family_confirmation','transfer']:
        if not (HERE/role/'completion.json').exists():continue
        ids=plan[role+'_worlds'];checked=0
        for w in ids:
            path=HERE/role/f'w{w}'/'inputs.npz'
            with np.load(path) as z:inputs={k:z[k] for k in z.files}
            for nonlinear in ([False] if role=='family_confirmation' else [False,True]):
                prefix='nonlinear' if nonlinear else 'linear';e=environment(w,plan['config'],nonlinear)
                for k in ['D','yD','C','Q','theta','candidate_ids']:assert np.array_equal(e[k],inputs[prefix+'_'+k]),(role,w,k)
                assert np.array_equal(e['costs']['neutral'],inputs[prefix+'_cost']) and e['B']==float(inputs[prefix+'_B'])
                for direction in ['target','unlock']:
                    s=state(e,w,plan['config'],direction);assert np.array_equal(s.ordinary_x,inputs[prefix+'_'+direction+'_O'])
                for split,tag in [('search',89001),('eval',89002)]:
                    T,p=target(w,tag,plan['reference_n'],nonlinear);assert np.array_equal(T,inputs[prefix+'_'+split+'_T']) and np.array_equal(p,inputs[prefix+'_'+split+'_p'])
            checked+=1
        roles[role]={'worlds':checked,'all_feature_labels_cost_budget_targets_exactly_regenerated':True}
    if (HERE/'mc_diagnostic/completion.json').exists():
        ids=json.loads((HERE/'mc_registration.json').read_text())['world_ids']
        for w in ids:
            with np.load(HERE/'mc_diagnostic'/f'w{w}'/'inputs.npz') as z:inputs={k:z[k] for k in z.files}
            e=environment(w,plan['config']);s=state(e,w,plan['config'],'target');h,_,_=core.geometry(s,False)
            for k in ['D','yD','C','Q','theta']:assert np.array_equal(e[k],inputs[k])
            assert np.array_equal(h,inputs['H_D']) and np.array_equal(e['costs']['neutral'],inputs['cost']) and e['B']==float(inputs['B'])
            for bank,n in [(0,128),(1,128),(2,256)]:
                g=rng(w,94001,bank);theta=g.multivariate_normal(e['theta'],core.inverse(h),size=n);uo=g.random((n,4000));uc=g.random((n,400))
                for name,v in [('theta',theta),('uniformO',uo),('uniformC',uc)]:assert np.array_equal(v,inputs[f'bank{bank}_{name}'])
        roles['mc_diagnostic']={'worlds':len(ids),'all_model_parameter_and_pseudo_label_uniform_draws_exactly_regenerated':True}
    result={'passed':True,'roles':roles,'source_sha256':sha(__file__),'no_model_fits_run':True};write(HERE/'generator_reconstruction_audit.json',result);print(json.dumps(result),flush=True)
if __name__=='__main__':main()
