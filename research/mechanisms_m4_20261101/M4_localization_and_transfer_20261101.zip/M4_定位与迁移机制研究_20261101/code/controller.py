"""One checkpointed, task-local M4 service; no automatic experiment expansion."""
from pathlib import Path
import datetime,fcntl,json,os,subprocess,sys,time,traceback
HERE=Path(__file__).resolve().parent
PIPE='/tmp/m4-mechanism-mps-20261101'
def write(p,d):
    p=Path(p);t=p.with_name(p.name+'.tmp');t.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');t.replace(p)
def status(stage,**details):
    d={'stage':stage,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'controller_pid':os.getpid(),**details};write(HERE/'service_status.json',d);print(json.dumps(d),flush=True)
def run(script,args,log,threads=6):
    env=os.environ.copy();env.update({'CUDA_MPS_PIPE_DIRECTORY':PIPE,'CUDA_MPS_ACTIVE_THREAD_PERCENTAGE':str(threads),'PYTHONDONTWRITEBYTECODE':'1','MPLCONFIGDIR':'/tmp/m4-matplotlib','OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1'})
    with (HERE/log).open('a') as f:
        r=subprocess.run([sys.executable,'-B',str(HERE/script),*args],cwd=HERE.parents[1],env=env,stdout=f,stderr=subprocess.STDOUT)
    if r.returncode:raise RuntimeError(f'{script} {args} failed: exit {r.returncode}; {log}')
def main():
    lock=(HERE/'service.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    plan=json.loads((HERE/'registration.json').read_text());assert plan['confirmation_n']==512
    status('resuming_family_confirmation',completed_before_resume=len(list((HERE/'family_confirmation').glob('w[0-9]*/complete.json'))),workers=16)
    Path(PIPE).mkdir(exist_ok=True);(HERE/'mps_logs').mkdir(exist_ok=True)
    env=os.environ.copy();env.update({'CUDA_MPS_PIPE_DIRECTORY':PIPE,'CUDA_MPS_LOG_DIRECTORY':str(HERE/'mps_logs')})
    mps=subprocess.run(['nvidia-cuda-mps-control','-d'],env=env,capture_output=True,text=True);assert mps.returncode==0,mps.stderr
    error=None
    try:
        audit=HERE/'family_confirmation/audit.json';completed=HERE/'family_confirmation/completion.json'
        reusable=audit.exists() and completed.exists() and json.loads(audit.read_text()).get('passed') and json.loads(audit.read_text()).get('worlds')==512 and json.loads(completed.read_text()).get('plan_sha256')==__import__('hashlib').sha256((HERE/'registration.json').read_bytes()).hexdigest()
        if not reusable:
            run('experiment.py',['family_confirmation','--workers','16'],'family_confirmation.log')
            status('auditing_family_confirmation');run('audit_analyze_v2.py',['family_confirmation','--workers','16'],'family_audit_analysis.log')
        accept=json.loads((HERE/'family_confirmation/acceptance.json').read_text())
        if accept['actual_space_identified']:
            status('method_and_structure_transfer_running',worlds=64,workers=16)
            run('experiment.py',['transfer','--workers','16'],'transfer.log',threads=6)
            status('auditing_method_and_structure_transfer');run('audit_analyze_v2.py',['transfer','--workers','8'],'transfer_audit_analysis.log')
            status('MC_ranking_diagnostic_running',worlds=6,workers=6,M=[2,16,128],verification_M=256)
            run('mc_diagnostic.py',['run','--workers','6'],'mc_diagnostic.log',threads=16)
            status('auditing_MC_ranking_diagnostic');run('mc_diagnostic.py',['audit','--workers','6'],'mc_audit_analysis.log')
        else:write(HERE/'conditional_stop.json',{'reason':'No preregistered simultaneous LR endpoint establishes space > delta. Additional MC/transfer computation stopped by original M4 entry rule.','not_a_claim_of_no_global_space':True})
        status('all_registered_training_and_raw_audits_finished',actual_space_identified=accept['actual_space_identified'])
    except BaseException:
        error=traceback.format_exc();status('failed',error=error)
    finally:
        stop=subprocess.run(['nvidia-cuda-mps-control'],input='quit\n',text=True,env=env,capture_output=True)
        write(HERE/'runtime_shutdown.json',{'pipe':PIPE,'shutdown_returncode':stop.returncode,'stdout':stop.stdout,'stderr':stop.stderr,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'controller_completed_without_error':error is None})
    if error:raise RuntimeError(error)
    helper=HERE/'export_results.py'
    if helper.exists():
        status('building_portable_delivery');run('export_results.py',[],'export_results.log');status('complete_audited_packaged')
    else:status('training_complete_report_pending')
if __name__=='__main__':main()
