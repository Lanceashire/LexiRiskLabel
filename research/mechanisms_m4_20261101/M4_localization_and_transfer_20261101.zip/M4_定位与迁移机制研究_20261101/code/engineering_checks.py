from common import *
from neighbor import criterion_check
def main():
    plan=json.loads((HERE/'registration.json').read_text());check(plan);cfg=plan['config'];w=23900001;e=environment(w,cfg)
    legacy=Path('LOCAL_WORKSPACE/2026-10-31/zhe/work/LexiRiskLabel/experiments/mechanism_v2');sys.path.insert(0,str(legacy))
    from run_paired_mechanism_states import generate
    from evaluate_frozen_family import family as oldfamily
    old=generate(w,cfg)[0];reports=[]
    for direction in ['target','unlock']:
        s=state(e,w,cfg,direction);ids=e['candidate_ids'];a=family(s,ids,w);prior=next(x for x in old if x[1]==direction and x[2]==4000 and x[3]=='neutral');p=prior[4]
        for k in ['visible_x','visible_y','ordinary_x','candidate_x','reference_x','cost','theta']:assert np.array_equal(getattr(s,k),getattr(p,k)),k
        aa,lookup=oldfamily(p,prior[7],w)
        for method,indices in a.items():assert core.digest(ids[indices])==lookup[method],method
        null=four(replace(s,ordinary_x=s.ordinary_x[:0]),ids);assert np.array_equal(null['D-only'],null['Pending-aware'])
        zero=family(replace(s,budget=0.),ids,w);assert all(len(idx)==0 for idx in zero.values())
        perm=rng(w,99001).permutation(len(ids));ps=replace(s,candidate_x=s.candidate_x[perm],cost=s.cost[perm]);pa=family(ps,ids[perm],w)
        for m in a:assert np.array_equal(np.sort(ids[a[m]]),np.sort(ids[perm][pa[m]])),m
        assert not any(k in vars(s) for k in ['yO','yC','pT','T','truth'])
        reports.append({'direction':direction,'exact_original_generator_and_family_parity':True,'stable_ID_permutation':True,'emptyO':True,'zero_budget':True})
    write(HERE/'engineering_checks.json',{'passed':True,'checks':reports,'neighbor_criterion':criterion_check(),'future_labels_absent_from_selector_state':True,'registered_confirmation_worlds_used':0});print('M4 engineering and original-family parity passed',flush=True)
if __name__=='__main__':main()
