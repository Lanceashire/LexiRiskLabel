"""Conditional MC ranking diagnosis; never reactivates Fantasy as a candidate."""
from common import *
from scipy.stats import spearmanr,t
import concurrent.futures

def validate(plan):
    check(plan);reg=json.loads((HERE/'mc_registration.json').read_text())
    for f,h in reg['source_hashes'].items():assert sha(HERE/f)==h
    assert reg['main_registration_sha256']==sha(HERE/'registration.json')
    assert json.loads((HERE/'family_confirmation/acceptance.json').read_text())['actual_space_identified']
    return reg
def run_world(args):
    w,plan=args;reg=validate(plan);root=HERE/'mc_diagnostic';dest=root/f'w{w}';identity=sha(HERE/'mc_registration.json')
    if (dest/'complete.json').exists():
        done=json.loads((dest/'complete.json').read_text());assert done['identity']==identity;return done
    if dest.exists():dest.rename(dest.with_name(dest.name+'_interrupted_'+str(time.time_ns())))
    dest.mkdir(parents=True);start=time.perf_counter();cfg=plan['config'];e=environment(w,cfg);ids=e['candidate_ids'];contexts=[];locks=[]
    original=json.loads((HERE/'family_confirmation'/f'w{w}'/'selection_locks.json').read_text())
    for direction in ['target','unlock']:
        s=state(e,w,cfg,direction);a=family(s,ids,w);unique={}
        for name,idx in a.items():
            assert core.digest(ids[idx])==next(r['select_hash'] for r in original if r['condition']=='linear_'+direction and r['method']==name)
            unique.setdefault(tuple(idx.tolist()),[]).append(name)
        contexts.append((direction,s,unique))
        locks.extend({'direction':direction,'set_id':i,'selected_indices':key,'methods':names} for i,(key,names) in enumerate(unique.items()))
    write(dest/'family_locks.json',locks);locksha=sha(dest/'family_locks.json');write(dest/'commitment.json',{'family_unchanged_from_preregistered_first_six_worlds':True,'sha256':locksha,'true_future_labels_not_used':True,'outer_T_not_used_for_scoring':True})
    h,_,_=core.geometry(contexts[0][1],False);cov=core.inverse(h);inputs={'D':e['D'],'yD':e['yD'],'C':e['C'],'Q':e['Q'],'theta':e['theta'],'H_D':h,'cost':e['costs']['neutral'],'B':e['B']};fitrows=[];scores=[]
    for bank,n in [(0,128),(1,128),(2,256)]:
        g=rng(w,94001,bank);theta=g.multivariate_normal(e['theta'],cov,size=n);uo=g.random((n,4000));uc=g.random((n,400));inputs[f'bank{bank}_theta']=theta;inputs[f'bank{bank}_uniformO']=uo;inputs[f'bank{bank}_uniformC']=uc
        for direction,s,unique in contexts:
            inputs[direction+'_O']=s.ordinary_x;coefs=[];xgbpred=[]
            for r in range(n):
                yo=(uo[r]<expit(s.ordinary_x@theta[r])).astype(np.uint8);yc=(uc[r]<expit(s.candidate_x@theta[r])).astype(np.uint8);p=expit(s.reference_x@theta[r])
                for setid,(key,names) in enumerate(unique.items()):
                    idx=np.array(key,int);x=np.vstack([s.visible_x,s.ordinary_x,s.candidate_x[idx]]);y=np.r_[s.visible_y,yo,yc[idx]]
                    for learner in ['LR','XGB']:
                        pp,saved,backend,seconds=fitted(x,y,[s.reference_x],w,learner,cfg);pr=pp[0]
                        if learner=='LR':pi=len(coefs);coefs.append(saved)
                        else:pi=len(xgbpred);xgbpred.append(saved)
                        risk=float(np.mean((pr-p)**2));fitrows.append({'world_id':w,'direction':direction,'bank':bank,'replicate':r,'set_id':setid,'method':names[0],'learner':learner,'prediction_index':pi,'backend':backend,'risk':risk,'seconds':seconds,'train_x_hash':core.digest(x),'train_y_hash':core.digest(y)})
                        scores.append({'world_id':w,'direction':direction,'bank':bank,'replicate':r,'set_id':setid,'learner':learner,'risk':risk})
            np.savez_compressed(dest/f'{direction}_bank{bank}_predictions.npz',LR_coefficients=np.array(coefs),XGB_predictions=np.array(xgbpred,dtype=np.float32))
    np.savez_compressed(dest/'inputs.npz',**inputs);pd.DataFrame(fitrows).to_csv(dest/'fits.csv',index=False);pd.DataFrame(scores).to_csv(dest/'scores.csv.gz',index=False,compression='gzip');assert sha(dest/'family_locks.json')==locksha
    done={'completed':True,'world_id':w,'identity':identity,'fits':len(fitrows),'seconds':time.perf_counter()-start,'files':{p.name:sha(p) for p in dest.iterdir() if p.is_file()}};write(dest/'complete.json',done);return done
def audit_world(args):
    w,plan=args;reg=validate(plan);dest=HERE/'mc_diagnostic'/f'w{w}';done=json.loads((dest/'complete.json').read_text());assert done['identity']==sha(HERE/'mc_registration.json')
    for f,h in done['files'].items():assert sha(dest/f)==h,f
    with np.load(dest/'inputs.npz') as z:e={k:z[k] for k in z.files}
    sets={(r['direction'],r['set_id']):np.array(r['selected_indices'],int) for r in json.loads((dest/'family_locks.json').read_text())};fits=pd.read_csv(dest/'fits.csv');error=0.
    for (direction,bank),q in fits.groupby(['direction','bank']):
        with np.load(dest/f'{direction}_bank{bank}_predictions.npz') as z:pred={k:z[k] for k in z.files}
        O=e[direction+'_O'];C=e['C'];Q=e['Q'];theta=e[f'bank{bank}_theta'];uo=e[f'bank{bank}_uniformO'];uc=e[f'bank{bank}_uniformC']
        for row in q.itertuples():
            idx=sets[direction,row.set_id];yo=(uo[row.replicate]<expit(O@theta[row.replicate])).astype(np.uint8);yc=(uc[row.replicate]<expit(C@theta[row.replicate])).astype(np.uint8)
            x=np.vstack([e['D'],O,C[idx]]);y=np.r_[e['yD'],yo,yc[idx]];assert core.digest(x)==row.train_x_hash and core.digest(y)==row.train_y_hash
            if row.learner=='LR':p=expit(Q@pred['LR_coefficients'][row.prediction_index])
            else:p=pred['XGB_predictions'][row.prediction_index].astype(float);assert row.backend.startswith('cuda')
            error=max(error,abs(np.mean((p-expit(Q@theta[row.replicate]))**2)-row.risk))
    assert error<1e-12
    external=pd.read_csv(HERE/'family_confirmation'/f'w{w}'/'outcomes.csv');records=[];ranks=[]
    for direction in ['target','unlock']:
        for learner in ['LR','XGB']:
            q=fits[(fits.direction==direction)&(fits.learner==learner)];verify=q[q.bank==2].groupby('set_id').risk.mean();truth=external[(external.condition=='linear_'+direction)&(external.learner==learner)&(external.split=='eval')].groupby('set_id').risk.mean()
            methods=external[(external.condition=='linear_'+direction)&(external.learner==learner)&(external.split=='eval')];mi=int(methods[methods.method=='MinRisk'].set_id.iloc[0]);pa=int(methods[methods.method=='Pending-aware'].set_id.iloc[0])
            for bank in [0,1]:
                p=q[q.bank==bank].pivot(index='replicate',columns='set_id',values='risk')
                for M in [2,16,128]:
                    score=p.iloc[:M].mean();winner=int(score.idxmin());records.append({'world_id':w,'direction':direction,'learner':learner,'bank':bank,'M':M,'winner':winner,'model_verification_risk':float(verify[winner]),'model_verification_gain_vs_MinRisk':float(verify[mi]-verify[winner]),'external_true_gain_vs_MinRisk':float(truth[mi]-truth[winner]),'external_true_gain_vs_PA':float(truth[pa]-truth[winner]),'model_empirical_reference_regret':float(verify[winner]-verify.min()),'ranking_correlation_model_verification':float(spearmanr(score,verify.loc[score.index]).statistic),'ranking_correlation_external_true_risk':float(spearmanr(score,truth.loc[score.index]).statistic)})
    return {'world_id':w,'fits':len(fits),'maximum_risk_error':error,'records':records}
def main():
    p=argparse.ArgumentParser();p.add_argument('mode',choices=['run','audit']);p.add_argument('--workers',type=int,default=6);a=p.parse_args();plan=json.loads((HERE/'registration.json').read_text());reg=validate(plan);ids=reg['world_ids'];root=HERE/'mc_diagnostic';root.mkdir(exist_ok=True)
    fn=run_world if a.mode=='run' else audit_world
    with concurrent.futures.ProcessPoolExecutor(max_workers=a.workers) as pool:
        results=[]
        for r in pool.map(fn,[(w,plan) for w in ids]):results.append(r);print(json.dumps({k:v for k,v in r.items() if k!='records' and k!='files'}),flush=True)
    if a.mode=='run':write(root/'completion.json',{'completed':True,'worlds':len(ids),'fits':sum(r['fits'] for r in results)});return
    f=pd.DataFrame([r for x in results for r in x['records']]);f.to_csv(root/'selection_results.csv',index=False);summary=[]
    for direction in ['target','unlock']:
        for learner in ['LR','XGB']:
            q=f[(f.direction==direction)&(f.learner==learner)];p=q.pivot(index=['world_id','bank'],columns='M',values='model_verification_risk');x=(p[2]-p[128]).groupby('world_id').mean();n=len(x);se=float(x.std(ddof=1)/np.sqrt(n));family=2 if learner=='LR' else 1;alpha=.01 if learner=='LR' else .05;rad=float(t.ppf(1-alpha/(2*family),n-1)*se)
            summary.append({'learner':learner,'direction':direction,'contrast':'model_verified_risk_M2_minus_M128','role':'primary' if learner=='LR' else 'exploratory_transfer','n_worlds':n,'mean':float(x.mean()),'SE':se,'low':float(x.mean()-rad),'high':float(x.mean()+rad),'family':family,'family_alpha':alpha})
    pd.DataFrame(summary).to_csv(root/'primary_intervals.csv',index=False);write(root/'audit.json',{'passed':True,'worlds':len(ids),'fits_reconstructed':sum(r['fits'] for r in results),'maximum_risk_error':max(r['maximum_risk_error'] for r in results),'true_labels_and_outer_T_not_used_for_MC_scoring':True,'fixed_families_and_independent_model_verification':True});write(root/'acceptance.json',{'completed':True,'n_worlds':len(ids),'M_values':[2,16,128],'independent_banks':2,'independent_verification_M':256,'new_algorithm_candidate':False,'scope':'conditional frozen-world-model ranking noise, paired external risk evaluation remains finite family M16; n=6, no general error-bound claim'});print(pd.DataFrame(summary).to_string(index=False),flush=True)
if __name__=='__main__':main()
