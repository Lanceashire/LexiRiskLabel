"""Independent recomputation from published aggregate evidence, no credit data."""
from pathlib import Path
import hashlib,json
import numpy as np
import pandas as pd
from sklearn.linear_model import Ridge
ROOT=Path(__file__).resolve().parent
def main():
    manifest=json.loads((ROOT/'SHA256_MANIFEST.json').read_text())
    for p,h in manifest['files'].items():assert hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==h,p
    results=json.loads((ROOT/'tables/results.json').read_text());plan=results['analysis_plan'];state=pd.read_csv(ROOT/'tables/common_state_aggregates.csv')
    moments=pd.read_csv(ROOT/'tables/paired_reduction_moments.csv')
    errors=[];equivalent_expression_errors=[];pvalues=[];count=0
    for name in ['LendingClub2017','SouthGermanCredit']:
        seed=pd.read_csv(ROOT/'tables'/f'{name}_seed_method_Brier.csv');boot=np.load(ROOT/'tables'/f'{name}_aggregate_bootstrap.npz')
        rows=[r for r in results['endpoints'] if r['dataset']==name];points=[]
        for row in rows:
            learner=row['learner'];q=state[(state.dataset==name)&(state.learner==learner)]
            if row['kind']=='algorithm_gain':
                comparator=row['endpoint'].split('ten_round_PA_gain_vs_')[1];pivot=seed[seed.learner==learner].pivot(index='seed',columns='method',values='ten_round_Brier')
                equivalent=float((pivot[comparator]-pivot['Pending-aware']).mean())
            elif row['kind']=='mechanism_interaction':
                a,b=('high','low') if 'direction' in row['endpoint'] else ('full','empty')
                pivot=q.pivot(index=['seed','round'],columns='treatment',values='actual_PA_gain_vs_MinRisk')
                equivalent=float((pivot[a]-pivot[b]).mean())
            else:
                q=q[q.treatment=='full'];actual=q.actual_PA_gain_vs_MinRisk.to_numpy();pred=q.predicted_gain.to_numpy();base=q.constant_prediction.to_numpy()
                estimate=float((np.abs(actual-base)-np.abs(actual-pred)).mean())
                errors.extend([abs(np.abs(actual-pred).mean()-row['MAE_model']),abs(np.abs(actual-base).mean()-row['MAE_constant'])])
            if row['kind']!='explanation_prediction':
                m=moments[(moments.dataset==name)&(moments.learner==learner)&(moments.endpoint==row['endpoint'])].iloc[0]
                dt=np.dtype(m.reduction_dtype);estimate=float(np.asarray(m.paired_total,dtype=dt)/np.asarray(m.test_rows,dtype=dt))
                equivalent_expression_errors.append(abs(equivalent-estimate))
            points.append(estimate);errors.append(abs(estimate-row['estimate']))
        errors.append(float(np.max(np.abs(np.array(points)-boot['point']))))
        alpha=plan['family_alpha']/(2*plan['primary_family_size']);lo,hi=np.quantile(boot['bootstrap'],[alpha,1-alpha],axis=0)
        for j,row in enumerate(rows):
            p=float((1+(np.abs(boot['bootstrap'][:,j]-boot['point'][j])>=abs(boot['point'][j])).sum())/(len(boot['bootstrap'])+1));pvalues.append((row,p))
            errors.extend([abs(lo[j]-row['low']),abs(hi[j]-row['high']),abs(p-row['bootstrap_centered_p'])]);count+=1
    adjusted=0.
    for rank,(row,p) in enumerate(sorted(pvalues,key=lambda x:x[1])):
        adjusted=max(adjusted,min(1.,(len(pvalues)-rank)*p));errors.append(abs(adjusted-row['Holm_adjusted_bootstrap_p']))
    f=pd.read_csv(ROOT/'source/diagnostic_development.csv');cfg=json.loads((ROOT/'source/diagnostic_frozen.json').read_text())
    for learner,m in cfg['models'].items():
        d=f[f.learner==learner];x=d[cfg['features']].to_numpy();y=d.gain.to_numpy()/d.scale.to_numpy();mu=x.mean(0);sd=x.std(0);sd=np.where(sd>1e-12,sd,1.)
        fit=Ridge(alpha=1.).fit((x-mu)/sd,y);errors.extend([float(np.max(np.abs(fit.coef_-m['coef']))),abs(float(fit.intercept_)-m['intercept'])])
    assert count==20 and max(errors)<1e-10,(count,max(errors))
    # Equivalent expressions can round differently for registered float32 XGB
    # predictions. This cross-check uses a data-format precision bound, and
    # never replaces the strict canonical-statistic verification above.
    assert max(equivalent_expression_errors)<np.finfo(np.float32).eps
    result={'passed':True,'primary_point_estimates_recomputed':count,'simultaneous_intervals_recomputed':count,'Holm_family_recomputed':20,
        'M4_diagnostic_rules_recomputed':2,'maximum_absolute_recomputation_error':max(errors),'manifest_files':len(manifest['files']),
        'float32_equivalent_expression_max_difference':max(equivalent_expression_errors),'canonical_reduction_moments_preserve_original_dtype':True,
        'original_credit_data_or_GPU_required':False,'inference_scope':'Conditional fixed-model test-group bootstrap, not training-population coverage.'}
    (ROOT/'portable_verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
