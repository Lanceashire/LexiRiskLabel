from pathlib import Path
import csv,hashlib,importlib.util,json
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parent
def main():
    manifest=json.loads((ROOT/'MANIFEST_SHA256.json').read_text())
    for name,rec in manifest.items():
        p=ROOT/name;assert p.stat().st_size==rec['bytes']
        assert hashlib.sha256(p.read_bytes()).hexdigest()==rec['sha256'],name
    spec=importlib.util.spec_from_file_location('portable',ROOT/'experiments/verify_portable.py')
    mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);stats=mod.verify(ROOT/'experiments')
    raw=pd.read_csv(ROOT/'experiments/synthetic/E1/world_mean_risks.csv',float_precision='round_trip')
    saved=pd.read_csv(ROOT/'closure/reports/fixed_action_world_decomposition.csv',float_precision='round_trip')
    computed=[]
    for (world,learner,history,direction),g in raw.groupby(['world','learner','history','direction']):
        v={}
        for n,h in g.groupby('O_n'):
            a=h.set_index('method').excess_Brier
            v[n]={m:float(a['OrdinaryOnly']-a[m]) for m in ['D-only','MinRisk','Pending-aware']}
        d=[v[4000][m]-v[110][m] for m in ['D-only','MinRisk','Pending-aware']]
        computed.append([world,learner,history,direction,*d,d[2]-d[1]])
    fresh=pd.DataFrame(computed,columns=saved.columns)
    keys=['world','learner','history','direction'];cols=list(saved.columns[4:])
    a=fresh.sort_values(keys).reset_index(drop=True);b=saved.sort_values(keys).reset_index(drop=True)
    assert a[keys].equals(b[keys])
    err=float(np.max(np.abs(a[cols].to_numpy()-b[cols].to_numpy())));assert err<1e-12
    e0=pd.read_csv(ROOT/'closure/e0_aggregate/round_metrics_full.csv',float_precision='round_trip')
    required={'budget','expected_selected_loss','realized_selected_loss','D_count','O_count','C_count',
              'full_O_count','full_C_count','candidate_truncation','overlap_with_MinRisk','Brier','lock_sha256'}
    assert len(e0)==380 and required.issubset(e0.columns)
    assert (e0.expected_selected_loss<=e0.budget+1e-8).all() and not e0.failed.any()
    assert int(e0.candidate_truncation.sum())==0
    assert int(e0.realized_loss_exceeds_predicted_budget.sum())==120
    protocol=json.loads((ROOT/'closure/protocols/e0_logging_completion.json').read_text())
    for name,h in protocol['source_hashes'].items():
        assert hashlib.sha256((ROOT/'closure'/name).read_bytes()).hexdigest()==h,name
    reg=json.loads((ROOT/'closure/e0_public/frozen/registration.json').read_text())
    for name,h in reg['source_hashes'].items():
        assert hashlib.sha256((ROOT/'closure/e0_public/frozen'/name).read_bytes()).hexdigest()==h
    primary=list(csv.DictReader((ROOT/'七项主要端点.csv').open()));assert len(primary)==7
    assert all(r['learner']=='LR' for r in primary)
    original=list(csv.DictReader((ROOT/'experiments/全部主次端点.csv').open()))
    assert primary==[r for r in original if r['learner']=='LR']
    for p in ROOT.rglob('*'):
        if not p.is_file():continue
        rel=str(p.relative_to(ROOT))
        assert 'private_paired_losses/' not in rel and '/runtime/' not in rel
        if p.suffix=='.npz':
            assert rel=='experiments/E3/public_bootstrap_draws.npz' or rel.startswith('experiments/engineering/'),rel
        if p.suffix=='.jsonl':raise AssertionError('No private individual journals in public bundle')
    acceptance=json.loads((ROOT/'ACCEPTANCE.json').read_text())
    assert not acceptance['full_paper_written'] and not acceptance['full_original_precision_targets_met']
    assert acceptance['unresolved']==2
    result={'passed':True,'manifest_files':len(manifest),'primary_endpoints':7,'all_endpoints':stats['all_primary_and_secondary_endpoints'],
            'fixed_action_max_error':err,'E0_resource_rows':380,'private_credit_rows_in_archive':False,
            'full_manuscript_written':False,'all_original_precision_targets_met':False}
    print(json.dumps(result,indent=2));return result
if __name__=='__main__':main()
