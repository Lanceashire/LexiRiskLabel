"""One public entry: exact frozen training, timestamped observer, complete schema."""
from pathlib import Path
import sys,subprocess
ROOT=Path(__file__).resolve().parent
if __name__=='__main__':
    # The schema receipt below is the registered two-task, seed-51001
    # engineering check.  Do not silently present another task as that check.
    args=sys.argv[1:]
    if not any(v in args for v in ['--help','-h']):
        for flag,allowed in [('--seed','51001'),('--dataset','all')]:
            values=[args[i+1] for i,v in enumerate(args[:-1]) if v==flag]
            values += [v.split('=',1)[1] for v in args if v.startswith(flag+'=')]
            if any(v!=allowed for v in values):
                raise SystemExit(f'run_public.py verifies {flag}={allowed}; use run_full.py for other replay-only runs')
    subprocess.run([sys.executable,str(ROOT/'run_full.py'),*sys.argv[1:]],check=True)
    if any(v in args for v in ['--help','-h']):raise SystemExit(0)
    output=next((v.split('=',1)[1] for v in args if v.startswith('--output=')),None)
    if output is None:output=args[args.index('--output')+1]
    subprocess.run([sys.executable,str(ROOT/'complete_outputs.py'),'--output',output],check=True)
