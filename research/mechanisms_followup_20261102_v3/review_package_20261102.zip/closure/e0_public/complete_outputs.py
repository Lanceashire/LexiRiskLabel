"""Complete E0 engineering schema without changing frozen scientific results."""
from pathlib import Path
import argparse,json,hashlib,sys
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parent
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def main():
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);a=p.parse_args();out=a.output
    receipt=json.loads((out/'full_reproduction_receipt.json').read_text())
    compared=receipt['main_and_common_prediction_files_checked']>0
    if compared:assert receipt['all_predictions_bitwise_identical']
    # A public fresh replay without --reference is reproducible execution,
    # not an independent equality comparison to unavailable private arrays.
    receipt['reference_comparison_performed']=compared
    if not compared:
        receipt['all_predictions_bitwise_identical']=None
        receipt['maximum_prediction_error']=None
    (out/'full_reproduction_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    frame=pd.read_csv(out/'round_metrics_full.csv',float_precision='round_trip');assert len(frame)==380
    full=[];index=[];known={}
    for dataset in frame.dataset.unique():
        task=out/'runtime/runs'/f'{dataset}_51001';native=pd.read_csv(task/'trajectory_no_T_outcomes.csv')
        known[dataset]=native
        for row in frame[frame.dataset==dataset].itertuples(index=False):
            method=row.method if row.branch=='main' else 'MinRisk'
            reference=native[(native.learner==row.learner)&(native.method==method)&(native['round']==row.round)].iloc[0]
            d=row._asdict();d.update({'full_O_count':int(reference.O_count),'full_C_count':int(reference.full_C_count),
                'candidate_truncation':int(reference.full_C_count>reference.retained_C_count),'retained_C_count':row.C_count})
            assert row.O_count<=d['full_O_count'] and row.C_count==reference.retained_C_count
            full.append(d)
            file=f'{row.learner}_{row.method}.npz' if row.branch=='main' else f'{row.learner}_r{row.round}_{row.branch}_{row.method}.npz'
            lossfile=out/'private_paired_losses'/f'{dataset}_51001'/file;z=np.load(lossfile)
            loss=z['loss'][row.round-1] if row.branch=='main' else z['loss'];assert abs(float(loss.mean())-row.Brier)<1e-14
            index.append({'dataset':dataset,'seed':51001,'learner':row.learner,'method':row.method,'round':row.round,'branch':row.branch,
                'file':str(lossfile.relative_to(out)),'array_key':'loss','array_row':row.round-1 if row.branch=='main' else None,
                'group_array_key':'group_id','test_entity_count':len(z['group_id']),'file_sha256':sha(lossfile)})
    frame=pd.DataFrame(full);frame.to_csv(out/'round_metrics_full.csv',index=False);pd.DataFrame(index).to_csv(out/'per_group_loss.index.csv',index=False)
    contrasts=[]
    for (dataset,learner,r,branch),group in frame.groupby(['dataset','learner','round','branch']):
        risk=group.set_index('method').Brier
        contrasts.append({'dataset':dataset,'learner':learner,'round':r,'branch':branch,
            'estimand':'own_history_round_comparison' if branch=='main' else 'common_MinRisk_history_action_comparison',
            'E':float(risk['OrdinaryOnly']-risk['Pending-aware']),'J':float(risk['MinRisk']-risk['Pending-aware']),
            'P':float(risk['D-only']-risk['Pending-aware']) if 'D-only' in risk else None})
    pd.DataFrame(contrasts).to_csv(out/'round_contrasts.csv',index=False)
    sources=json.loads((ROOT/'frozen/source_download_receipts.json').read_text())
    manifest={'role':'public E0 rerun with separate identity; not fresh confirmation','wrapper_sha256':sha(ROOT/'run_full.py'),
        'observer_sha256':sha(ROOT/'observed_vault.py'),'schema_completion_sha256':sha(__file__),
        'historical_registration_sha256':receipt['historical_registration_sha256'],
        'sources':[{k:r[k] for k in ['dataset','url','sha256','bytes']} for r in sources],
        'original_source_hashes':json.loads((ROOT/'frozen/registration.json').read_text())['source_hashes'],
        'backend':'CPU','loss_format':'NPZ arrays plus per_group_loss.index.csv; all requested entity/seed/round/method dimensions recoverable',
        'private_indices_and_labels_not_in_public_archive':True}
    for name in ['public_reproduction_manifest.json','source_manifest.json']:(out/name).write_text(json.dumps(manifest,indent=2)+'\n')
    (out/'protocol.json').write_text(json.dumps({'role':'engineering','datasets':2,'seeds':[51001],'main_rounds':10,
        'scientific_protocol':'unchanged original M5','independent_new_confirmatory_n':0,'methods':5,'learners':['LR','XGB'],
        'new_outcomes':False,'main_comparators_use_own_history':True,'common_state_P_missing_by_original_design':True,
        'predicted_loss_budget_not_realized_hard_guarantee':True},indent=2)+'\n')
    result={'passed':True,'resource_records':len(frame),'paired_loss_records_reconstructed':len(index),'source_predictions_bitwise_identical':receipt['all_predictions_bitwise_identical'],
        'reference_comparison_performed':compared,
        'all_expected_spends_feasible':bool((frame.expected_selected_loss<=frame.budget+1e-8).all()),'candidate_truncations':int(frame.candidate_truncation.sum()),
        'realized_over_budget_state_records':int(frame.realized_loss_exceeds_predicted_budget.sum()),
        'realized_over_budget_count_not_independent_applicants':True,'new_scientific_confirmation':False}
    (out/'results.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
if __name__=='__main__':main()
