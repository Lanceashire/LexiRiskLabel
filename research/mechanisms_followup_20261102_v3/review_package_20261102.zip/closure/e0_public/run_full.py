"""Run unmodified full M5 code in a NEW isolated runtime, including common states."""
from pathlib import Path
import argparse,hashlib,json,shutil,sys,urllib.request
ROOT=Path(__file__).resolve().parent

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def main():
    p=argparse.ArgumentParser();p.add_argument('--data-dir',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    p.add_argument('--seed',type=int,default=51001);p.add_argument('--dataset',choices=['all','LendingClub2017','SouthGermanCredit'],default='all');p.add_argument('--reference',type=Path)
    p.add_argument('--proxy')
    a=p.parse_args();assert 51001<=a.seed<=51020
    runtime=a.output/'runtime';runtime.mkdir(parents=True,exist_ok=True)
    reg=json.loads((ROOT/'frozen/registration.json').read_text())
    for f,h in reg['source_hashes'].items():assert sha(ROOT/'frozen'/f)==h,('historical source drift',f)
    a.data_dir.mkdir(parents=True,exist_ok=True)
    receipts={r['dataset']:r for r in json.loads((ROOT/'frozen/source_download_receipts.json').read_text())}
    opener=urllib.request.build_opener(urllib.request.ProxyHandler({'http':a.proxy,'https':a.proxy} if a.proxy else {}))
    for dataset,file in [('LendingClub2017','LC_Loan_sample_2017.csv'),('SouthGermanCredit','SouthGermanCredit.zip')]:
        path=a.data_dir/file
        if not path.exists():
            partial=path.with_suffix(path.suffix+'.part')
            with opener.open(receipts[dataset]['url'],timeout=90) as response,partial.open('wb') as output:shutil.copyfileobj(response,output)
            assert sha(partial)==reg['data_hashes'][dataset];partial.replace(path)
    shutil.copytree(ROOT/'frozen',runtime,dirs_exist_ok=True);dest=runtime/'private/source_raw';dest.mkdir(parents=True,exist_ok=True)
    for dataset,file in [('LendingClub2017','LC_Loan_sample_2017.csv'),('SouthGermanCredit','SouthGermanCredit.zip')]:
        assert sha(a.data_dir/file)==reg['data_hashes'][dataset];shutil.copy2(a.data_dir/file,dest/file)
    sys.path.insert(0,str(runtime.resolve()))
    import replay
    from observed_vault import instrument,expand_metrics
    native_vault=replay.FeedbackVault
    results=[];checks=[];maxerr=0.;bitwise=True;metrics=[];full_metrics=[]
    for dataset in (['LendingClub2017','SouthGermanCredit'] if a.dataset=='all' else [a.dataset]):
        replay.FeedbackVault=instrument(native_vault,a.output,dataset,a.seed,runtime)
        results.append(replay.task(dataset,a.seed))
        if a.reference:
            task=f'{dataset}_{a.seed}';old=a.reference/task;new=runtime/'runs'/task
            for path in new.rglob('*.npz'):
                import numpy as np
                x=np.load(path);y=np.load(old/path.relative_to(new))
                assert set(x.files)==set(y.files)
                for k in x.files:
                    if k=='test_ids':assert np.array_equal(x[k],y[k])
                    else:
                        err=float(np.max(np.abs(x[k]-y[k])));maxerr=max(maxerr,err);bitwise=bitwise and np.array_equal(x[k],y[k]);assert err<=1e-10
                checks.append(str(path.relative_to(new)))
        # Old M5 is development evidence here. Evaluate AFTER replay has finished.
        import numpy as np
        import pandas as pd
        from data import load
        _,labels,_,group,_=load(dataset);taskdir=runtime/'runs'/f'{dataset}_{a.seed}'
        lossdir=a.output/'private_paired_losses'/f'{dataset}_{a.seed}';lossdir.mkdir(parents=True,exist_ok=True)
        for learner in ['LR','XGB']:
            for method in ['OrdinaryOnly','MinRisk','D-only','Pending-aware','ParBaLS-Laplace-cost-pending']:
                path=taskdir/learner/method/'predictions.npz';z=np.load(path);test=z['test_ids'];loss=(labels[test]-z['prediction'])**2
                np.savez_compressed(lossdir/f'{learner}_{method}.npz',loss=loss,group_id=group[test])
                for r,v in enumerate(loss,1):metrics.append({'dataset':dataset,'learner':learner,'method':method,'round':r,'branch':'main','Brier':float(np.mean(v))})
            for path in (taskdir/'common_state'/learner).glob('*.npz'):
                z=np.load(path);test=z['test_ids'];loss=(labels[test]-z['prediction'])**2;parts=path.stem.split('_')
                metrics.append({'dataset':dataset,'learner':learner,'method':'_'.join(parts[2:]),'round':int(parts[0][1:]),'branch':parts[1],'Brier':float(np.mean(loss))})
                np.savez_compressed(lossdir/f'{learner}_{path.stem}.npz',loss=loss,group_id=group[test])
        full_metrics.extend(expand_metrics(replay,runtime,a.output,dataset,a.seed))
    pd.DataFrame(metrics).to_csv(a.output/'round_metrics.csv',index=False)
    pd.DataFrame(full_metrics).to_csv(a.output/'round_metrics_full.csv',index=False)
    receipt={'public_wrapper_sha256':sha(__file__),'historical_registration_sha256':sha(runtime/'registration.json'),
        'tasks':results,'main_and_common_prediction_files_checked':len(checks),'all_predictions_bitwise_identical':bool(bitwise),
        'maximum_prediction_error':maxerr,'round_risk_records':len(metrics),'checks':checks,
        'separate_runtime':True,'full_10_round_and_common_state_replay':True,'historical_sources_unchanged':True,
        'read_only_feedback_observer':True,'observer_sha256':sha(ROOT/'observed_vault.py'),
        'full_resource_and_realized_loss_rows':len(full_metrics),'successful_releases_logged':len(full_metrics)}
    (a.output/'full_reproduction_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True)
if __name__=='__main__':main()
