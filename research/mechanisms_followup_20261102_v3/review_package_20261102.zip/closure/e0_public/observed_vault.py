"""Read-only instrumentation of frozen M5 releases; does not change acquisition."""
from pathlib import Path
import json,time,hashlib
import numpy as np

def instrument(base,out,dataset,seed,runtime):
    out=Path(out);runtime=Path(runtime).resolve();out.mkdir(parents=True,exist_ok=True)
    selection=out/f'{dataset}_{seed}_selection_locks.jsonl';release=out/f'{dataset}_{seed}_release_log.jsonl'
    assert not selection.exists() and not release.exists(),'fresh engineering output required'
    def emit(path,data):
        with path.open('a') as f:f.write(json.dumps(data,ensure_ascii=False)+'\n')
    class ObservedVault(base):
        def __init__(self,*args,**kwargs):super().__init__(*args,**kwargs);self.allowed_initial=set();self.sequence=0
        def initial(self,ids):
            result=super().initial(ids);self.allowed_initial.update(map(int,ids));return result
        def release(self,path,expected):
            path=Path(path);payload=path.read_bytes();lock=json.loads(payload);sha=hashlib.sha256(payload).hexdigest()
            lock_time=path.stat().st_mtime_ns;before=time.time_ns();self.sequence+=1
            meta={'dataset':dataset,'seed':seed,'sequence':self.sequence,'lock_file':str(path.relative_to(runtime)),
                'lock_sha256':sha,'lock_persisted_ns':lock_time,'release_call_ns':before,'status':'locked',**lock}
            emit(selection,meta)
            try:ids,labels=super().release(path,expected)
            except Exception as error:
                emit(release,{'sequence':self.sequence,'lock_sha256':sha,'status':'rejected','reason':type(error).__name__,'time_ns':time.time_ns()});raise
            assert lock_time<=before<=time.time_ns()
            known=self.allowed_initial|set(lock['visible_ids']);seen=known|set(map(int,ids))
            emit(release,{'dataset':dataset,'seed':seed,'sequence':self.sequence,'lock_sha256':sha,
                'ordinary_ids':lock['ordinary_ids'],'selected_ids':lock['selected_ids'],'visible_training_ids':lock['visible_ids'],
                'known_labels_before':sorted(known),'known_labels_after':sorted(seen),
                'released_labels_sha256':hashlib.sha256(np.asarray(labels).tobytes()).hexdigest(),
                'lock_persisted_ns':lock_time,'release_started_ns':before,'release_completed_ns':time.time_ns(),'status':'released'})
            return ids,labels
    return ObservedVault

def expand_metrics(replay,runtime,output,dataset,seed):
    import pandas as pd
    from data import load,preprocess
    from common import four,core,digest
    raw,y,exposure,group,_=load(dataset);task=runtime/'runs'/f'{dataset}_{seed}';split=np.load(task/'split.npz');initial=split['initial'];q=split['reference']
    x,_=preprocess(raw,initial);exposure=exposure/float(np.mean(exposure[initial]));rows=[]
    locks=[json.loads(s) for s in (output/f'{dataset}_{seed}_selection_locks.jsonl').read_text().splitlines()]
    releases=[json.loads(s) for s in (output/f'{dataset}_{seed}_release_log.jsonl').read_text().splitlines()]
    assert len(locks)==len(releases)==190
    for lock,event in zip(locks,releases):
        assert lock['lock_sha256']==event['lock_sha256'] and event['status']=='released'
        ids=np.r_[lock['ordinary_ids'],lock['selected_ids']].astype(int)
        assert hashlib.sha256(y[ids].tobytes()).hexdigest()==event['released_labels_sha256']
        assert not np.intersect1d(ids,split['test']).size
        file=runtime/lock['lock_file'];original=json.loads(file.read_text());learner=original.get('learner')
        if learner is None:learner=file.parent.name
        method=original['method'];r=int(original['round']);branch=original.get('treatment','main')
        if branch=='main':pred=np.load(file.parent/'predictions.npz')['prediction'][r-1]
        else:pred=np.load(file.with_suffix('.npz'))['prediction']
        D=np.asarray(original['visible_ids'],int);O=np.asarray(original['ordinary_ids'],int);C=np.asarray(original['candidate_ids'],int);S=np.asarray(original['selected_ids'],int)
        cost=np.asarray(original['cost']);B=original['budget'];s=core.State(x[D],y[D],x[O],x[C],x[q],cost,B,core.fit_logistic(x[D],y[D],1.),seed*100+r,ridge=1.,exchanges=0)
        reference=C[four(s,C)['MinRisk']];selected_cost=float(cost[np.isin(C,S)].sum());realized=float(np.sum(y[S]*exposure[S]));k=len(S)
        assert selected_cost<=B+1e-8
        rows.append({'dataset':dataset,'seed':seed,'learner':learner,'method':method,'round':r,'branch':branch,
            'D_count':len(D),'O_count':len(O),'C_count':len(C),'selected_count':k,'budget':B,'expected_selected_loss':selected_cost,
            'realized_selected_loss':realized,'realized_loss_exceeds_predicted_budget':bool(realized>B+1e-8),
            'MinRisk_reference_count':len(reference),'overlap_with_MinRisk':len(np.intersect1d(S,reference)),
            'MinRisk_jaccard':len(np.intersect1d(S,reference))/max(len(np.union1d(S,reference)),1),
            'count_sacrifice':len(reference)-k,'composition_premium':selected_cost-float(np.sort(cost)[:k].sum()),
            'Brier':float(np.mean((y[split['test']]-pred)**2)),'lock_sha256':lock['lock_sha256'],'failed':False})
    return rows
