from pathlib import Path
import json,sys
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parents[1]
STUDY=ROOT.parent/'mechanisms_followup_20261102_v2'
PUBLIC=ROOT.parents[1]/'outputs/LexiRiskLabel_E0_E3_机制确认_20261102'

def main():
    f=pd.read_csv(PUBLIC/'synthetic/E1/fixed_and_reoptimized_action_gains.csv',float_precision='round_trip')
    long=[];summary=[];maxerr=0.
    for (learner,history,direction),group in f.groupby(['learner','history','direction']):
        x=group.pivot(index='world',columns='O_n',values=['gain_D-only','gain_MinRisk','gain_Pending-aware'])
        d=x.xs(4000,level=1,axis=1)-x.xs(110,level=1,axis=1)
        j110=x['gain_Pending-aware'][110]-x['gain_MinRisk'][110];j4000=x['gain_Pending-aware'][4000]-x['gain_MinRisk'][4000]
        deltaJ=j4000-j110;error=np.abs(deltaJ-(d['gain_Pending-aware']-d['gain_MinRisk'])).max();maxerr=max(maxerr,float(error))
        for world in x.index:long.append({'world':int(world),'learner':learner,'history':history,'direction':direction,
            'delta_fixed_D_only_E':float(d.loc[world,'gain_D-only']),'delta_fixed_MinRisk_E':float(d.loc[world,'gain_MinRisk']),
            'delta_reselected_PA_E':float(d.loc[world,'gain_Pending-aware']),'delta_relative_J':float(deltaJ.loc[world])})
        summary.append({'learner':learner,'history':history,'direction':direction,'n_worlds':len(x),
            'delta_fixed_D_only_E':float(d['gain_D-only'].mean()),'delta_fixed_MinRisk_E':float(d['gain_MinRisk'].mean()),
            'delta_reselected_PA_E':float(d['gain_Pending-aware'].mean()),'delta_relative_J':float(deltaJ.mean()),
            'J_O110':float(j110.mean()),'J_O4000':float(j4000.mean()),'role':'descriptive re-expression of frozen results, not new primary hypothesis'})
    assert maxerr<1e-14
    for world in range(36100001,36100513):
        states=json.loads((STUDY/f'confirmation/E1/w{world}/selection_locks.json').read_text())
        assert len(set(tuple(s['actions']['MinRisk']) for s in states))==1
        for h in ['original_gap','broad_independent']:assert len(set(tuple(s['actions']['D-only']) for s in states if s['history']==h))==1
    pd.DataFrame(long).to_csv(ROOT/'reports/fixed_action_world_decomposition.csv',index=False)
    pd.DataFrame(summary).to_csv(ROOT/'reports/fixed_action_summary.csv',index=False)
    check={'passed':True,'worlds':512,'MinRisk_and_D_only_invariance_rechecked':True,'accounting_max_error':maxerr,
        'new_training_or_future_labels':False,'identity':'J=E_PA-E_MinRisk; Delta_O J=Delta_O E_PA-Delta_O E_MinRisk',
        'bias_variance_extension_triggered':False,'reason':'opposite signs refer to absolute and relative gains; exact identity resolves the apparent contradiction'}
    (ROOT/'reports/fixed_action_audit.json').write_text(json.dumps(check,indent=2)+'\n')
    example=next(s for s in summary if s['learner']=='LR' and s['history']=='original_gap' and s['direction']=='unlock')
    text=f'''固定动作与重新选样解释汇总 2026年11月2日

同一批冻结结果中的三个量不能混为一个：绝对探索收益E=R(OrdinaryOnly)-R(PA)；相对收益J=R(MinRisk)-R(PA)；固定D-only动作的绝对探索收益。
恒等式J=E_PA-E_MinRisk，以及Delta_O J=Delta_O E_PA-Delta_O E_MinRisk，对每个独立世界成立。

原历史、unlock、LR中，O从110增至4000：
固定D-only的绝对探索收益变化 {example['delta_fixed_D_only_E']:+.12f}。
固定MinRisk的绝对探索收益变化 {example['delta_fixed_MinRisk_E']:+.12f}。
重选PA的绝对探索收益变化 {example['delta_reselected_PA_E']:+.12f}。
PA相对MinRisk的收益变化 {example['delta_relative_J']:+.12f}。

普通反馈更多时，PA额外获取标签本身的绝对价值下降，但MinRisk的绝对价值下降更多，因此PA相对MinRisk的优势反而增加。这两个方向并不矛盾。不能把相对优势增加写成“探索标签的绝对价值增加”。

D-only与MinRisk选集已在全部512世界重新核对为按方案固定；PA允许随O重选。D-only与PA并非同一策略的冻结/重选版本，因此二者差值也不能直接称为纯重优化因果效应。

本项仅使用原冻结风险表和选集，不产生新确认世界，也不改变七项主端点。逐世界分账最大误差为{maxerr:.3g}。原文件关于“固定动作与重新选样解释冲突”的触发条件，经统一估计对象后得到解释，不需要为此另开偏差—方差拟合批次。
'''
    (ROOT/'reports/固定动作解释汇总.txt').write_text(text)
    fig,axes=plt.subplots(1,2,figsize=(9,3.0))
    sub=f[(f.learner=='LR')&(f.direction=='unlock')]
    for ax,hist in zip(axes,['original_gap','broad_independent']):
        g=sub[sub.history==hist].groupby('O_n').mean(numeric_only=True)
        for column,label,style in [('gain_D-only','Fixed D-only','--'),('gain_MinRisk','Fixed MinRisk',':'),('gain_Pending-aware','Reselected PA','-')]:
            ax.plot([110,4000],g.loc[[110,4000],column],style,marker='o',label=label)
        ax.set_title(hist.replace('_',' '));ax.set_xlabel('Ordinary feedback count');ax.set_ylabel('Absolute exploration gain E');ax.ticklabel_format(axis='y',style='sci',scilimits=(-3,3))
        ax.legend(fontsize=8)
    fig.tight_layout();fig.savefig(ROOT/'paper_assets/fixed_actions.png',dpi=180,bbox_inches='tight');fig.savefig(ROOT/'paper_assets/fixed_actions.pdf',bbox_inches='tight');plt.close(fig)
    print(json.dumps({'example':example,'audit':check}),flush=True)
if __name__=='__main__':main()
