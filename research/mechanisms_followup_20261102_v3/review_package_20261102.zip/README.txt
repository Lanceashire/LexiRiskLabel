LexiRiskLabel 实验收束与写法核验 2026-11-02
先读 实验收束总报告.txt，再读 投稿写法核验.txt 和 原计划逐项验收.csv。
本次范围：完成已登记且明确修订范围的实验、收束证据、核验写法。
没有完整论文、匿名投稿PDF或正式提交。7项主要端点：3正幅度、2实质带、2未定。

核验（使用experiments/e0_full_public/requirements.lock.txt的固定依赖）：
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python verify_consolidation.py
这将复核所有文件SHA256，独立重建全部14项主次端点和固定动作算术。

新版E0完整工程入口（会下载或读取第三方数据并训练；本地私有输出）：
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MPLCONFIGDIR=/tmp/m5-matplotlib python closure/e0_public/run_public.py --data-dir ./local_inputs --output ./e0_new_runtime
可选 --proxy http://127.0.0.1:7897；默认不配置代理。
此入口固定两个任务和seed51001，重放十轮及共同状态，输出完整预算/资源/实现损失表、
锁与释放日志、NPZ+索引。另有run_full.py支持其他原登记seed的重放。
私有日志/NPZ只会在你本地新生成，不随本公开包发布。
不提供--reference时，重放不会声称与私有旧预测逐位比较；对应收据为未比较。
本轮实际工程验收提供了本地原始参照，202项比较已通过。

experiments是130项清单文件的既有v2包，含完整协议、生成器修订、精度范围修订、
源代码、世界级风险、E3聚合bootstrap、审计和三张结果图，保持字节不变。
旧包中的未发布标记是历史状态；最终上传证据在包外的GitHub发布收据。
closure是本轮增量。只公开聚合380行工程表和收据，不含成组真实损失索引、个体日志。
closure/src/close_fixed_actions.py保留原分析出处，可能使用历史工作目录；
可移植独立核验请运行根目录verify_consolidation.py，无需原目录。
各主张范围、缺失桥接实现、未达精度和两个未定结果必须保留。
