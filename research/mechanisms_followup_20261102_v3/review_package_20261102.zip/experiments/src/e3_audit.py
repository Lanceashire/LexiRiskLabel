"""Independently replay every new-cohort prediction and persisted feedback lock."""
from pathlib import Path
import argparse,json,multiprocessing as mp
from concurrent.futures import ProcessPoolExecutor,as_completed
import numpy as np
import pandas as pd
from scipy.special import expit
from study import ROOT,core,four,fit,sha,write,digest
from data import preprocess,split
from neighbor import select_neighbor

def audit_seed(seed):
    dest=ROOT/'e3/runs'/f'LC2012_{seed}';cohort=ROOT/'private/e3_cohort';raw=pd.read_pickle(cohort/'features.pkl');cust=np.load(cohort/'custodian.npz')
    z=np.load(dest/'predictions.npz');initial=z['initial'];dev=z['development'];test=z['test'];q=z['reference'];refs=np.r_[dev,test]
    i,d,t,batches=split(raw,cust['group'],seed,'LendingClub2017');assert np.array_equal(i,initial) and np.array_equal(d,dev) and np.array_equal(t,test)
    for a,b in [(initial,test),(dev,test),(initial,dev)]:assert not np.intersect1d(cust['group'][a],cust['group'][b]).size
    x,_=preprocess(raw,initial);rec=pd.read_csv(dest/'round_records.csv');releases=json.loads((dest/'release_log.json').read_text())
    release={r['lock']:r for r in releases};cache={};refits=0;worst=0.;selection_checks=0;flow={};histories={};checked=0
    theta0=core.fit_logistic(x[initial],cust['y'][initial],1.);price=expit(x@theta0);threshold=float(np.quantile(price[dev],.7))
    exposure=cust['exposure']/float(np.mean(cust['exposure'][initial]));costall=price*exposure
    for row in rec.itertuples(index=False):
        action='main' if row.kind=='main' else 'cross_'+row.action
        name=f'{row.learner}_{row.history}_r{row.round}_{action}.json';path=dest/name;lock=json.loads(path.read_text());r=release[name]
        assert sha(path)==r['lock_sha256'] and path.stat().st_mtime_ns<=r['release_time_ns']
        D=np.array(lock['visible_ids'],int);O=np.array(lock['ordinary_ids'],int);C=np.array(lock['candidate_ids'],int);S=np.array(lock['selected_ids'],int)
        future=np.r_[O,S];assert len(future)==len(np.unique(future)) and not np.intersect1d(future,test).size and not np.intersect1d(future,D).size
        assert np.isin(S,C).all() and not np.intersect1d(O,C).size
        assert digest(future)==r['future_ids_hash'] and digest(cust['y'][future])==r['future_labels_hash']
        assert digest(cust['y'][D])==lock['visible_y_hash'] and digest([x[D],x[O],x[C],x[q]])==lock['state_hash']
        batch=batches[row.round-1];oo=batch[price[batch]<threshold];full=batch[price[batch]>=threshold]
        cc=np.sort(np.random.default_rng(np.random.SeedSequence([seed,913,row.round])).choice(full,min(128,len(full)),replace=False))
        assert np.array_equal(O,oo) and np.array_equal(C,cc) and np.array_equal(np.array(lock['cost']),costall[C])
        B=.1*float(costall[C].sum());assert B==lock['budget'] and costall[S].sum()<=B+1e-8
        statekey=(lock['state_hash'],lock['visible_y_hash']);theta=core.fit_logistic(x[D],cust['y'][D],1.)
        state=core.State(x[D],cust['y'][D],x[O],x[C],x[q],costall[C],B,theta,seed*100+row.round,ridge=1.,exchanges=0)
        method=row.history if row.kind=='main' else row.action
        if method!='ParBaLS-Laplace-cost-pending':
            selected=four(state,C)[method];assert np.array_equal(C[selected],S);selection_checks+=1
        elif seed==51001 and row.learner=='LR':
            selected,_=select_neighbor(state,{'universes':10,'posterior_draws':32});assert np.array_equal(C[selected],S);selection_checks+=1
        if row.kind=='main':
            hk=(row.learner,row.history);prior=histories.get(hk,initial)
            assert np.array_equal(D,prior);histories[hk]=np.r_[D,future]
        else:
            main=json.loads((dest/f'{row.learner}_{row.history}_r{row.round}_main.json').read_text())
            assert lock['visible_ids']==main['visible_ids']
        key=(row.learner,*statekey,tuple(S),row.round)
        if key not in cache:
            ids=np.r_[D,future];p,_=fit(x[ids],cust['y'][ids],x[refs],row.learner,seed*100+row.round);cache[key]=p.astype(np.float64);refits+=1
        expected=z[row.kind][row.index];err=float(np.max(np.abs(expected-cache[key])));worst=max(worst,err);checked+=1
    assert worst<=1e-10
    result={'seed':seed,'prediction_records_checked':checked,'independent_unique_refits':refits,'max_prediction_error':worst,
        'selection_checks':selection_checks,'release_checks':len(releases),'test_risk_evaluated':False,'passed':True}
    write(dest/'independent_audit.json',result);return result

def main():
    p=argparse.ArgumentParser();p.add_argument('plan',type=Path);p.add_argument('--workers',type=int,default=4);a=p.parse_args();plan=json.loads(a.plan.read_text());done=[]
    with ProcessPoolExecutor(max_workers=a.workers,mp_context=mp.get_context('fork')) as pool:
        futures=[pool.submit(audit_seed,s) for s in plan['seeds']]
        for f in as_completed(futures):done.append(f.result());print(f'{len(done)}/20 seed audits complete',flush=True)
    result={'passed':True,'seeds':20,'all_predictions_refitted':True,'prediction_records_checked':sum(r['prediction_records_checked'] for r in done),
        'independent_unique_refits':sum(r['independent_unique_refits'] for r in done),'max_prediction_error':max(r['max_prediction_error'] for r in done),
        'selection_checks':sum(r['selection_checks'] for r in done),'release_checks':sum(r['release_checks'] for r in done),
        'test_risks_evaluated':False,'rows':sorted(done,key=lambda x:x['seed'])}
    write(ROOT/'e3/independent_audit.json',result);print(json.dumps(result),flush=True)
if __name__=='__main__':main()
