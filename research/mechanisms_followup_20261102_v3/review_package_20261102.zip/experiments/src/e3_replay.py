"""Frozen new-cohort replay with explicit history-source by current-action crossing."""
from pathlib import Path
import json,sys,time
import numpy as np
import pandas as pd
from scipy.special import expit
from study import ROOT,core,four,fit,sha,write,digest
sys.path.insert(0,str(ROOT/'vendor'))
from data import split,preprocess
from neighbor import select_neighbor
METHODS=['OrdinaryOnly','MinRisk','D-only','Pending-aware','ParBaLS-Laplace-cost-pending']

class Vault:
    def __init__(self,y,test):self.__y=y.copy();self.test=test;self.log=[]
    def legal_initial(self,ids):
        assert not np.intersect1d(ids,self.test).size;return self.__y[ids].copy()
    def release(self,path,commit,visible):
        assert sha(path)==commit;lock=json.loads(path.read_text());ids=np.r_[lock['ordinary_ids'],lock['selected_ids']].astype(int)
        assert len(ids)==len(np.unique(ids)) and not np.intersect1d(ids,self.test).size and not np.intersect1d(ids,visible).size
        self.log.append({'lock':str(path.name),'lock_sha256':commit,'release_time_ns':time.time_ns(),
            'future_ids_hash':digest(ids),'future_labels_hash':digest(self.__y[ids])})
        return ids,self.__y[ids].copy()

def task(seed,plan_path):
    plan=json.loads(Path(plan_path).read_text());assert seed in plan['seeds']
    for file,h in plan['source_hashes'].items():assert sha(ROOT/file)==h,('source drift',file)
    dest=ROOT/'e3/runs'/f'LC2012_{seed}';dest.mkdir(parents=True,exist_ok=True)
    if (dest/'complete.json').exists():
        result=json.loads((dest/'complete.json').read_text());assert result['plan_sha256']==sha(plan_path);return result
    tick=time.monotonic();cohort=ROOT/'private/e3_cohort';identity=json.loads((cohort/'identity.json').read_text())
    assert sha(cohort/'features.pkl')==identity['features_sha256'] and sha(cohort/'custodian.npz')==identity['custodian_sha256']
    raw=pd.read_pickle(cohort/'features.pkl');custodian=np.load(cohort/'custodian.npz');group=custodian['group'];exposure=custodian['exposure']
    initial,dev,test,batches=split(raw,group,seed,'LendingClub2017');vault=Vault(custodian['y'],test)
    x,_=preprocess(raw,initial);initial_y=vault.legal_initial(initial);theta0=core.fit_logistic(x[initial],initial_y,1.)
    price=expit(x@theta0);threshold=float(np.quantile(price[dev],.7));exposure=exposure/float(np.mean(exposure[initial]));costall=price*exposure
    delta=.005*float(np.mean((vault.legal_initial(dev)-price[dev])**2));qids=np.sort(np.random.default_rng(seed+77).choice(dev,min(128,len(dev)),replace=False))
    refs=np.r_[dev,test];main=[];cross=[];records=[];locks=[];fit_count=0
    for learner in ['LR','XGB']:
        for method in METHODS:
            visible=initial.copy();visible_y=initial_y.copy()
            for r,batch in enumerate(batches,1):
                ordinary=batch[price[batch]<threshold];full=batch[price[batch]>=threshold]
                candidate=np.sort(np.random.default_rng(np.random.SeedSequence([seed,913,r])).choice(full,min(128,len(full)),replace=False))
                cost=costall[candidate];B=.1*float(cost.sum());theta=core.fit_logistic(x[visible],visible_y,1.)
                s=core.State(x[visible],visible_y,x[ordinary],x[candidate],x[qids],cost,B,theta,seed*100+r,ridge=1.,exchanges=0)
                options=four(s,candidate)
                chosen=select_neighbor(s,{'universes':10,'posterior_draws':32})[0] if method==METHODS[-1] else options[method]
                actions={'main':chosen}
                if method in ['MinRisk','Pending-aware'] and r in [2,5,8]:
                    actions.update({'cross_MinRisk':options['MinRisk'],'cross_Pending-aware':options['Pending-aware']})
                # All current actions are locked before any current O/C label release.
                pending=[]
                for action,selected in actions.items():
                    lock={'learner':learner,'history_source':method,'round':r,'action':action,'visible_ids':visible,
                        'ordinary_ids':ordinary,'candidate_ids':candidate,'selected_ids':candidate[selected],'cost':cost,'budget':B,
                        'state_hash':digest([s.visible_x,s.ordinary_x,s.candidate_x,s.reference_x]),'visible_y_hash':digest(visible_y)}
                    path=dest/f'{learner}_{method}_r{r}_{action}.json';write(path,lock);pending.append((action,selected,path,sha(path)));locks.append(path.name)
                cache={};main_visible=None;main_labels=None
                for action,selected,path,commit in pending:
                    ids,yy=vault.release(path,commit,visible);key=tuple(selected.tolist())
                    if key not in cache:
                        pp,_=fit(x[np.r_[visible,ids]],np.r_[visible_y,yy],x[refs],learner,seed*100+r);fit_count+=1
                        cache[key]=pp.astype(np.float64)
                    pred=cache[key]
                    if action=='main':
                        main.append(pred);main_visible=np.r_[visible,ids];main_labels=np.r_[visible_y,yy]
                        records.append({'kind':'main','learner':learner,'history':method,'action':method,'round':r,'index':len(main)-1,
                            'D_count':len(visible),'O_count':len(ordinary),'C_count':len(candidate),'full_C_count':len(full),
                            'candidate_truncation':int(len(full)>128),'selected_count':len(selected),'spend':float(cost[selected].sum()),'budget':B})
                    else:
                        cross.append(pred);records.append({'kind':'cross','learner':learner,'history':method,'action':action[6:],'round':r,'index':len(cross)-1,
                            'D_count':len(visible),'O_count':len(ordinary),'C_count':len(candidate),'selected_count':len(selected),'spend':float(cost[selected].sum()),'budget':B})
                visible=main_visible;visible_y=main_labels
    np.savez_compressed(dest/'predictions.npz',main=np.array(main),cross=np.array(cross),development=dev,test=test,group=group,
        reference=qids,initial=initial)
    pd.DataFrame(records).to_csv(dest/'round_records.csv',index=False);write(dest/'release_log.json',vault.log)
    write(dest/'prediction_commitment.json',{'predictions_sha256':sha(dest/'predictions.npz'),'records_sha256':sha(dest/'round_records.csv'),
        'test_outcomes_evaluated':False,'plan_sha256':sha(plan_path)})
    result={'seed':seed,'plan_sha256':sha(plan_path),'complete':True,'main_records':100,'cross_records':24,'actual_model_fits':fit_count,
        'development_count':len(dev),'test_count':len(test),'feature_dimension':x.shape[1],'delta':delta,'test_outcomes_evaluated':False,
        'candidate_truncations':sum(r.get('candidate_truncation',0) for r in records),'seconds':time.monotonic()-tick}
    write(dest/'complete.json',result);return result
