"""Bounded, checkpointed multi-process execution of preregistered world IDs."""
from pathlib import Path
import argparse,json,time,multiprocessing as mp
from concurrent.futures import ProcessPoolExecutor,as_completed
from study import ROOT,run_world,write,sha

def main():
    p=argparse.ArgumentParser();p.add_argument('plan',type=Path);p.add_argument('--workers',type=int,default=4);a=p.parse_args()
    plan=json.loads(a.plan.read_text());out=ROOT/plan['output_dir'];out.mkdir(parents=True,exist_ok=True)
    jobs=[];done=[]
    for w in plan['world_ids']:
        path=out/f'w{w}'/'complete.json'
        if path.exists():
            r=json.loads(path.read_text());assert r['plan_sha256']==sha(a.plan);done.append(r)
        else:jobs.append(w)
    started=time.time()
    write(out/'progress.json',{'completed':len(done),'registered':len(plan['world_ids']),'state':'running','workers':a.workers})
    with ProcessPoolExecutor(max_workers=a.workers,mp_context=mp.get_context('fork')) as pool:
        pending={pool.submit(run_world,w,str(a.plan.resolve())):w for w in jobs}
        for job in as_completed(pending):
            r=job.result();done.append(r)
            status={'completed':len(done),'registered':len(plan['world_ids']),'world':r['world'],'last_seconds':r['seconds'],
                'total_fits':sum(x['actual_model_fits'] for x in done),'state':'running','elapsed_seconds':time.time()-started}
            write(out/'progress.json',status);print(json.dumps(status),flush=True)
    write(out/'completion.json',{'complete':True,'plan_sha256':sha(a.plan),'worlds':len(done),'model_fits':sum(x['actual_model_fits'] for x in done),
        'risk_records':sum(x['risk_records'] for x in done),'elapsed_seconds':time.time()-started,'workers':a.workers})
    write(out/'progress.json',{'completed':len(done),'registered':len(done),'state':'complete'})
if __name__=='__main__':main()
