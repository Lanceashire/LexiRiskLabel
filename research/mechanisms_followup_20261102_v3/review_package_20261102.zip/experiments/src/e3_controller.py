from pathlib import Path
import argparse,json,multiprocessing as mp,time
from concurrent.futures import ProcessPoolExecutor,as_completed
from e3_replay import ROOT,task,write

def main():
    p=argparse.ArgumentParser();p.add_argument('plan',type=Path);p.add_argument('--workers',type=int,default=4);a=p.parse_args()
    plan=json.loads(a.plan.read_text());out=ROOT/'e3';out.mkdir(exist_ok=True);done=[];start=time.monotonic()
    with ProcessPoolExecutor(max_workers=a.workers,mp_context=mp.get_context('fork')) as pool:
        futures=[pool.submit(task,s,str(a.plan.resolve())) for s in plan['seeds']]
        for future in as_completed(futures):
            r=future.result();done.append(r);status={'complete_tasks':len(done),'registered':20,'last_seed':r['seed'],
                'actual_fits':sum(d['actual_model_fits'] for d in done),'elapsed_seconds':time.monotonic()-start,'test_evaluated':False}
            write(out/'progress.json',status);print(json.dumps(status),flush=True)
    write(out/'execution_complete.json',{'complete':True,'seeds':20,'main_records':sum(r['main_records'] for r in done),
        'cross_records':sum(r['cross_records'] for r in done),'actual_fits':sum(r['actual_model_fits'] for r in done),
        'elapsed_seconds':time.monotonic()-start,'test_evaluated':False})
if __name__=='__main__':main()
