from pathlib import Path
import json,sys,importlib.util,time
import numpy as np
from study import ROOT,covariates,choose_all,validate_fixed_actions,rng,core,sha,write

def main():
    w=35900001;e=covariates(w,'E1');states=choose_all(e,w,'E1');validate_fixed_actions(states,'E1')
    # Independent literal reconstruction of the old M4 history/candidate/Q law.
    d=np.ones((800,5));d[:,1]=rng(w,1).uniform(-2,.8,800);d[:,2]=rng(w,2).normal(0,.12,800)
    d[:,3]=d[:,2]+rng(w,3).normal(0,.05,800);d[:,4]=rng(w,4).normal(size=800)
    assert np.array_equal(d,e['D']['original_gap'])
    c=np.ones((400,5));c[:,1]=1+np.log(3);c[:,2]=rng(w,5).normal(0,1.2,400);c[:,3:]=rng(w,6).normal(size=(400,2))
    assert np.array_equal(c,e['C'])
    # D-only is chosen once per history; MinRisk held fixed globally.
    assert len(states)==8 and len(set(tuple(s['actions']['MinRisk']) for s in states))==1
    for h in ['original_gap','broad_independent']:assert len(set(tuple(s['actions']['D-only']) for s in states if s['history']==h))==1
    e2=covariates(36900001,'E2');s2=choose_all(e2,36900001,'E2');validate_fixed_actions(s2,'E2')
    for s in s2:assert core.kstar(e2['cost'],s['budget'])==s['capacity']
    # Future O=110 is the exact same covariate prefix as O=4000, and C/Q/T/cost
    # are shared across BOTH histories, by construction rather than resampling.
    assert np.array_equal(e['O']['unlock'][:110],e['O']['unlock'][:4000][:110])
    assert not np.array_equal(e['D']['original_gap'],e['D']['broad_independent'])
    z=rng(w,2).normal(size=800);assert np.array_equal(e['D']['broad_independent'][:,2],1.2*z)
    assert np.array_equal(e['D']['broad_independent'][:,3],rng(w,3).normal(size=800))
    for file in list((ROOT/'src').glob('*.py')):compile(file.read_text(),str(file),'exec')
    write(ROOT/'reports/engineering_checks.json',{'passed':True,'original_M4_history_and_C_reconstructed_exactly':True,
        'broad_independent_numeric_law_verified':True,'fixed_MinRisk_and_D_only_verified':True,'nested_O_prefix_verified':True,
        'E2_Kstar_3_and_15_verified':True,'selection_states':len(states)+len(s2),'new_pilot_worlds_used':False,
        'development_worlds':[35900001,36900001],'source':'new explicit v2, not external audit restoration'})
    print('engineering passed',flush=True)
if __name__=='__main__':main()
