"""Freeze a previously unused 2012 mature term36 cohort, with test evaluation sealed."""
from pathlib import Path
import json,hashlib,sys
import numpy as np
import pandas as pd
from study import ROOT,sha,write
sys.path.insert(0,str(ROOT/'vendor'))
from data import LC_COLS,groups

def prepare():
    cfg=json.loads((ROOT/'protocols/e3_pre_source_outcome_scope.json').read_text());src=ROOT/'private/e3_source/LendingClub_2007_to_2018Q4.csv'
    receipt=json.loads(src.with_name('source_receipt.json').read_text());assert sha(src)==receipt['sha256']
    columns=LC_COLS+['id','member_id','issue_d','loan_status'];parts=[];rows=0
    for chunk in pd.read_csv(src,usecols=columns,chunksize=100000,low_memory=False):
        mask=chunk.issue_d.astype(str).str.endswith('2012')&chunk.term.astype(str).str.contains('36')&(pd.to_numeric(chunk.loan_amnt,errors='coerce')>0)
        a=chunk.loc[mask].copy();a['source_row']=np.flatnonzero(mask)+rows;rows+=len(chunk);parts.append(a)
    df=pd.concat(parts,ignore_index=True);covariate_eligible=len(df)
    terminal=df.loan_status.isin(['Fully Paid','Charged Off']);df=df.loc[terminal].reset_index(drop=True)
    assert len(df)>=6000,'eligible unseen mature cohort is too small for fixed 6000 sample'
    # Source outcome fields are used ONLY by this data custodian for eligibility.
    # Their numerical labels are not available to selectors or final evaluation yet.
    chosen=np.sort(np.random.default_rng(52000).choice(len(df),6000,replace=False));df=df.iloc[chosen].reset_index(drop=True)
    raw=df[LC_COLS].copy()
    for c in ['int_rate','revol_util']:raw[c]=pd.to_numeric(raw[c].astype(str).str.rstrip('%'),errors='coerce')
    group=groups(raw,{c:df[c].to_numpy() for c in ['id','member_id']});assert len(np.unique(group))>5500
    dest=ROOT/'private/e3_cohort';dest.mkdir(parents=True,exist_ok=True)
    raw.to_pickle(dest/'features.pkl');np.savez_compressed(dest/'custodian.npz',y=(df.loan_status=='Charged Off').to_numpy(np.uint8),
        exposure=df.loan_amnt.to_numpy(float),group=group,source_row=df.source_row.to_numpy(),loan_id=df.id.astype(str).to_numpy(dtype='str'))
    # Check registered source-cohort identity rather than assuming a different seed is new.
    overlap=[]
    oldbase=ROOT.parent.parent.parent/'2026-10-26/chatgpt-conversation-6adf3bf3-4a84-83ec-bf74/work/data'
    # Resolve the historical workspace relative to the shared Codex root if needed.
    oldbase=Path('/home/jiezichuan/Documents/Codex/2026-10-26/chatgpt-conversation-6adf3bf3-4a84-83ec-bf74/work/data')
    newids=set(df.id.dropna().astype(str)) - {'nan','0','0.0',''}
    for file in [oldbase/f'LC_Loan_sample_{yr}.csv' for yr in [2014,2015,2016]]+[ROOT.parent/'m5_study/private/source_raw/LC_Loan_sample_2017.csv']:
        header=pd.read_csv(file,nrows=0)
        use=[c for c in ['id','issue_d'] if c in header];old=pd.read_csv(file,usecols=use,low_memory=False)
        if 'issue_d' in old:assert not old.issue_d.astype(str).str.endswith('2012').any()
        valid=set(old.id.dropna().astype(str)) - {'nan','0','0.0',''} if 'id' in old else set()
        common=newids&valid;assert not common;overlap.append({'source':file.name,'loan_ID_overlap':len(common)})
    identity={'source':receipt,'scope_protocol_sha256':sha(ROOT/'protocols/e3_pre_source_outcome_scope.json'),
        'cohort':'2012 issued, term36, positive amount, terminal status subset','source_covariate_eligible_rows':covariate_eligible,
        'terminal_eligible_rows':int(terminal.sum()),'sampled_rows':len(df),'entity_groups':len(np.unique(group)),
        'old_cohort_source_overlap_checks':overlap,'maturity':'contractual term ends by Dec2015; source Last-Modified Dec2019; actual label-availability dates still absent',
        'new_historical_cohort_not_later_calendar_transfer':True,'true_borrower_ID_not_guaranteed':True,
        'features_sha256':sha(dest/'features.pkl'),'custodian_sha256':sha(dest/'custodian.npz'),'T_evaluated':False}
    write(dest/'identity.json',identity);write(ROOT/'reports/e3_eligibility.json',identity);print(json.dumps(identity),flush=True)
if __name__=='__main__':prepare()
