"""Variance-only roadmap planning. Never uses pilot means to select N."""
import math
import numpy as np
from scipy.stats import chi2,t,beta

def plan(world_endpoint_matrix,alpha,halfwidths,match_count=None,total_pilot=None,maximum=512):
    x=np.asarray(world_endpoint_matrix,float)
    assert x.ndim==2 and x.shape[0]>=3 and not np.isinf(x).any()
    n,m=x.shape;assert len(halfwidths)==m
    counts=np.isfinite(x).sum(axis=0)
    if np.any(counts<3):
        return {'freeze_N':None,'resource_precision_conflict':True,'reason':'fewer than 3 observed pilot worlds for an endpoint',
            'pilot_worlds':n,'endpoint_effective_n':counts.tolist(),'pilot_means_used':False,'no_confirmation_started':True}
    sd=np.nanstd(x,axis=0,ddof=1)
    # Simultaneously conservative planning bounds across endpoint variances.
    upper=sd*np.sqrt((counts-1)/chi2.ppf(.05/m,counts-1))
    needed=[]
    for s,h in zip(upper,halfwidths):
        k=128
        while k<=maximum and t.ppf(1-alpha/(2*m),k-1)*s/np.sqrt(k)>h:k+=32
        needed.append(k)
    result={'pilot_worlds':n,'endpoint_effective_n':counts.tolist(),'endpoint_sd':sd.tolist(),'sd_simultaneous_95pct_upper':upper.tolist(),'needed_n':needed,
        'alpha':alpha,'halfwidths':halfwidths,'normal_world_t_and_chi_square_approximation':True,'pilot_means_used':False}
    required=max(needed)
    if match_count is not None:
        assert m==2 and total_pilot==n and 0<=match_count<=total_pilot and counts[1]==match_count
        lower=0. if match_count==0 else float(beta.ppf(.05,match_count,total_pilot-match_count+1))
        # Planning heuristic; final matched n is random and must be reported as such.
        result['complete_match_fraction_CP95_lower']=lower
        # Column 0 is QM over ALL worlds; column 1 is CM over complete-match worlds.
        required=maximum+32 if lower==0 else max(needed[0],int(math.ceil(needed[1]/lower/32)*32))
    result.update({'freeze_N':required if required<=maximum else None,'resource_precision_conflict':required>maximum,
        'maximum':maximum,'no_confirmation_started':True})
    return result
