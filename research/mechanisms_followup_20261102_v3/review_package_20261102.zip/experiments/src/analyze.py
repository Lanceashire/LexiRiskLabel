from pathlib import Path
import argparse,json
import numpy as np
import pandas as pd
from scipy.stats import t
from study import ROOT,write,sha
from plan_sample_size import plan as precision_plan

def world_values(path,experiment):
    f=pd.read_csv(path/'risks.csv',float_precision='round_trip');rows=[]
    assert f.groupby(['state','learner','method']).size().eq(8).all()
    for learner in ['LR','XGB']:
        g=f[f.learner==learner];means=g.groupby(['state','method']).excess_Brier.mean().unstack()
        states=json.loads((path/'selection_locks.json').read_text());J={};state_metrics=[]
        for i,s in enumerate(states):
            a=means.loc[i];j=float(a['MinRisk']-a['Pending-aware']);J[(s['history'],s['direction'],s['O_n'])]=j
            mm={'history':s['history'],'direction':s['direction'],'O_n':s['O_n'],'capacity':s['capacity'],
                'J':j,'E':float(a['OrdinaryOnly']-a['Pending-aware']),'P':float(a['D-only']-a['Pending-aware'])}
            if experiment=='E2':
                mm['QM']=float(a['MinRisk-k']-a['MinRisk']);mm['residual']=float(a['Pending-aware']-a['MinRisk-k'])
                mm['CM']=float(a[[k for k in a.index if k.startswith('Match')]].mean()-a['Pending-aware']) if s['matching']['sets'] else None
                assert abs((-mm['J'])-(mm['QM']+mm['residual']))<1e-14
            state_metrics.append(mm)
        if experiment=='E1':
            anchor=J[('original_gap','unlock',4000)];broad=J[('broad_independent','unlock',4000)]
            theta=(anchor-J[('original_gap','unlock',110)])-(broad-J[('broad_independent','unlock',110)])
            values=[anchor,theta,broad]
        else:
            values=[float(np.mean([s['QM'] for s in state_metrics])),
                float(np.mean([s['CM'] for s in state_metrics])) if all(s['CM'] is not None for s in state_metrics) else None]
        rows.append({'world':int(path.name[1:]),'learner':learner,'endpoints':values,'states':state_metrics})
    return rows

def classify(low,high,delta):
    if low>delta:return 'supports_practical_positive'
    if high< -delta:return 'supports_practical_negative'
    if low> -delta and high<delta:return 'within_practical_band'
    if high<delta:return 'excludes_practical_positive'
    return 'unresolved'

def analyze(plan_path,planning=False):
    p=json.loads(Path(plan_path).read_text());out=ROOT/p['output_dir'];rows=[]
    for w in p['world_ids']:
        path=out/f'w{w}';done=json.loads((path/'complete.json').read_text());assert done['plan_sha256']==sha(plan_path)
        rows.extend(world_values(path,p['experiment']))
    write(out/'world_endpoints.json',rows)
    if planning:
        assert p['role']=='variance_pilot' and len(p['world_ids'])==32
        lr=[r for r in rows if r['learner']=='LR'];x=np.array([[np.nan if v is None else v for v in r['endpoints']] for r in lr])
        kw={'match_count':int(np.isfinite(x[:,1]).sum()),'total_pilot':32} if p['experiment']=='E2' else {}
        result=precision_plan(x,p['alpha'],p['halfwidths'],**kw)
        times=[json.loads((out/f'w{w}'/'complete.json').read_text())['seconds'] for w in p['world_ids']]
        result.update({'experiment':p['experiment'],'source_plan_sha256':sha(plan_path),'median_world_seconds':float(np.median(times)),
            'max_world_seconds':max(times),'minimum_world_seconds':min(times),'test_or_confirmation_outcomes_used':False})
        write(out/'variance_precision_plan.json',result);print(json.dumps(result),flush=True);return result
    summaries=[]
    for learner in ['LR','XGB']:
        sub=[r for r in rows if r['learner']==learner]
        for i,name in enumerate(p['endpoint_names']):
            v=np.array([r['endpoints'][i] for r in sub if r['endpoints'][i] is not None]);n=len(v)
            point=float(np.mean(v)) if n else None
            half=float(t.ppf(1-p['alpha']/(2*len(p['endpoint_names'])),n-1)*np.std(v,ddof=1)/np.sqrt(n)) if n>1 else None
            lo,hi=(point-half,point+half) if half is not None else (None,None)
            summaries.append({'learner':learner,'endpoint':name,'n':n,'total_registered_worlds':len(sub),'point':point,'low':lo,'high':hi,
                'family_alpha':p['alpha'],'multiplicity':len(p['endpoint_names']),'delta':p['delta'],
                'verdict':classify(lo,hi,p['delta']) if lo is not None else 'not_estimable',
                'status':'primary' if learner=='LR' and p['role']=='confirmation' else 'secondary_or_pilot_descriptive'})
    write(out/'results.json',{'experiment':p['experiment'],'role':p['role'],'independent_worlds':len(p['world_ids']),
        'intervals':'approximate paired world t, Bonferroni within experiment; XGB secondary only','results':summaries})
    pd.DataFrame(summaries).to_csv(out/'primary_and_secondary.csv',index=False);print(json.dumps(summaries),flush=True)

if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('plan',type=Path);a.add_argument('--planning',action='store_true');p=a.parse_args();analyze(p.plan,p.planning)
