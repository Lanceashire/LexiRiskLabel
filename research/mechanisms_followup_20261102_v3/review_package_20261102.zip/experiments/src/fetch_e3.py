from pathlib import Path
import urllib.request,json,hashlib,time
ROOT=Path(__file__).resolve().parents[1]
URL='https://bigblue.depaul.edu/jlee141/econdata/LendingClub_LoanData/LendingClub_2007_to_2018Q4.csv'

def main():
    folder=ROOT/'private/e3_source';folder.mkdir(parents=True,exist_ok=True);dest=folder/'LendingClub_2007_to_2018Q4.csv';part=dest.with_suffix('.csv.part')
    op=urllib.request.build_opener(urllib.request.ProxyHandler({'http':'http://127.0.0.1:7897','https':'http://127.0.0.1:7897'}))
    with op.open(urllib.request.Request(URL,method='HEAD'),timeout=45) as response:
        size=int(response.headers['Content-Length']);etag=response.headers.get('ETag');modified=response.headers.get('Last-Modified')
    receipt={'url':URL,'expected_bytes':size,'etag':etag,'last_modified':modified,'raw_outcomes_inspected':False,'role':'candidate source for E3; not yet eligible'}
    (folder/'source_headers.json').write_text(json.dumps(receipt,indent=2)+'\n')
    if dest.exists():
        assert dest.stat().st_size==size;return
    start=part.stat().st_size if part.exists() else 0;h=hashlib.sha256()
    if start:
        with part.open('rb') as f:
            for chunk in iter(lambda:f.read(4*1024*1024),b''):h.update(chunk)
    req=urllib.request.Request(URL,headers={'Range':f'bytes={start}-','If-Range':etag} if start else {})
    tick=time.monotonic();total=start;last=total
    with op.open(req,timeout=90) as response:
        assert response.headers.get('ETag')==etag
        if start:assert response.status==206,'server did not resume requested source identity'
        with part.open('ab' if start else 'wb') as f:
            while True:
                chunk=response.read(1024*1024)
                if not chunk:break
                f.write(chunk);h.update(chunk);total+=len(chunk)
                if total-last>=64*1024*1024:
                    print(json.dumps({'bytes':total,'total':size,'fraction':total/size,'download_MB_per_second':(total-start)/max(time.monotonic()-tick,1)/1e6}),flush=True);last=total
    assert total==size,(total,size);part.replace(dest);receipt.update({'sha256':h.hexdigest(),'bytes':total,'download_complete':True})
    (folder/'source_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True)
if __name__=='__main__':main()
