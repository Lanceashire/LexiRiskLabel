"""Reconstruct risk, release authorization and training hashes from persisted arrays."""
from pathlib import Path
import argparse,json,hashlib
import numpy as np
import pandas as pd
from scipy.special import expit
from study import ROOT,sha,write,probability,validate_fixed_actions,fit

def audit(plan_path,refit_first=False):
    plan=json.loads(Path(plan_path).read_text());out=ROOT/plan['output_dir'];worst=0.;fit_count=0;release_count=0;refits=0;max_refit=0.
    for world in plan['world_ids']:
        p=out/f'w{world}';done=json.loads((p/'complete.json').read_text());assert done['plan_sha256']==sha(plan_path)
        assert done['lock_sha256']==sha(p/'selection_locks.json');states=json.loads((p/'selection_locks.json').read_text());validate_fixed_actions(states,plan['experiment'])
        z=np.load(p/'raw.npz');a={k:z[k] for k in z.files};fits=json.loads((p/'fits.json').read_text())
        lrmap={int(fid):i for i,fid in enumerate(a['lr_fit_id'])};xmap={int(fid):i for i,fid in enumerate(a['xgb_fit_id'])};risks={}
        assert np.array_equal(a['pT'],probability(a['T']))
        for hist in ['original_gap','broad_independent']:assert np.array_equal(a['yD_'+hist],(a['uD']<probability(a['D_'+hist])).astype(np.uint8))
        for rec in fits:
            fid=rec['fit_id'];state=states[rec['state']];hist=state['history'];direction=state['direction'];rep=rec['rep'];no=state['O_n'];selected=np.array(rec['selected'],int)
            assert selected.tolist() in state['actions'].values()
            D=a['D_'+hist];O=a['O_'+direction][:no];C=a['C'];yD=a['yD_'+hist]
            yo=(a['uO'][rep,:no]<probability(O)).astype(np.uint8);yc=(a['uC'][rep]<probability(C)).astype(np.uint8)
            X=np.vstack([D,O,C[selected]]);Y=np.r_[yD,yo,yc[selected]]
            assert hashlib.sha256(X.tobytes()+Y.tobytes()).hexdigest()==rec['training_sha256']
            assert sha(p/'selection_locks.json')==done['lock_sha256']
            if rec['learner']=='LR':pred=expit(a['T']@a['lrcoef'][lrmap[fid]])
            else:pred=a['xgbpred'][xmap[fid]]
            r=float(np.mean((pred-a['pT'])**2));sample=float(np.mean((a['yT']-pred)**2))
            worst=max(worst,abs(r-rec['excess_Brier']),abs(sample-rec['sampled_Brier']));risks[fid]=r;fit_count+=1
            if refit_first and world==plan['world_ids'][0] and rep==0 and rec['state']==0:
                other,_=fit(X,Y,a['T'],rec['learner'],world+7000);err=float(np.max(np.abs(other-pred)));max_refit=max(max_refit,err);refits+=1
        for release in json.loads((p/'release_log.json').read_text()):
            assert release['lock_sha256']==done['lock_sha256'];state=states[release['state']];s=np.array(release['selected_indices'],int);rep=release['rep'];no=state['O_n']
            assert s.tolist() in state['actions'].values() and no==release['O_prefix_n']
            yo=(a['uO'][rep,:no]<probability(a['O_'+state['direction']][:no])).astype(np.uint8)
            yc=(a['uC'][rep,s]<probability(C[s])).astype(np.uint8)
            assert hashlib.sha256(np.r_[yo,yc].tobytes()).hexdigest()==release['future_y_sha256'];release_count+=1
        frame=pd.read_csv(p/'risks.csv',float_precision='round_trip')
        for row in frame.itertuples():assert abs(row.excess_Brier-risks[row.fit_id])<1e-14
    assert worst<1e-12 and max_refit<1e-10
    result={'passed':True,'worlds':len(plan['world_ids']),'risk_fits_reconstructed':fit_count,'authorized_releases_checked':release_count,
        'max_risk_reconstruction_error':worst,'independent_refits':refits,'max_refit_prediction_error':max_refit,
        'training_and_future_label_hashes_verified':True,'fixed_actions_verified':True,'plan_sha256':sha(plan_path)}
    write(out/'audit.json',result);print(json.dumps(result),flush=True);return result

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('plan',type=Path);p.add_argument('--refit-first',action='store_true');a=p.parse_args();audit(a.plan,a.refit_first)
