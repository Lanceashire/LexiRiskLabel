from pathlib import Path
import argparse,json,math
import numpy as np
import pandas as pd
from scipy.stats import t,chi2
from study import ROOT,write,sha

def vectors(plan,part):
    sums={};extra={};groups=None;deltas=[];resource=[]
    custodian=np.load(ROOT/'private/e3_cohort/custodian.npz')
    for seed in plan['seeds']:
        dest=ROOT/'e3/runs'/f'LC2012_{seed}';done=json.loads((dest/'complete.json').read_text());deltas.append(done['delta'])
        commit=json.loads((dest/'prediction_commitment.json').read_text());assert sha(dest/'predictions.npz')==commit['predictions_sha256']
        z=np.load(dest/'predictions.npz');dev=z['development'];test=z['test'];ids=dev if part=='development' else test
        section=slice(0,len(dev)) if part=='development' else slice(len(dev),None);y=custodian['y'][ids]
        group=z['group'][ids]
        if groups is None:groups=group.copy()
        else:assert np.array_equal(group,groups)
        rec=pd.read_csv(dest/'round_records.csv');resource.append(rec)
        for learner in ['LR','XGB']:
            current={}
            for method in ['OrdinaryOnly','MinRisk','Pending-aware']:
                rows=rec[(rec.kind=='main')&(rec.learner==learner)&(rec.history==method)].sort_values('round')
                assert len(rows)==10
                pred=z['main'][rows['index'].to_numpy(),section]
                current[method]=np.mean((y[None,:]-pred)**2,axis=0)
            j=current['MinRisk']-current['Pending-aware'];byhistory={}
            for history in ['MinRisk','Pending-aware']:
                losses={}
                for action in ['MinRisk','Pending-aware']:
                    rows=rec[(rec.kind=='cross')&(rec.learner==learner)&(rec.history==history)&(rec.action==action)].sort_values('round')
                    assert rows['round'].tolist()==[2,5,8]
                    pred=z['cross'][rows['index'].to_numpy(),section];losses[action]=np.mean((y[None,:]-pred)**2,axis=0)
                byhistory[history]=losses['MinRisk']-losses['Pending-aware']
            h=byhistory['Pending-aware']-byhistory['MinRisk']
            for endpoint,val in [('J10',j),('H',h)]:sums.setdefault((learner,endpoint),[]).append(val)
            extra.setdefault(learner,[]).append(current['OrdinaryOnly']-current['Pending-aware'])
    unique=np.unique(groups)
    result={key:np.array([np.mean(np.mean(v,axis=0)[groups==g]) for g in unique]) for key,v in sums.items()}
    additional={key:np.array([np.mean(np.mean(v,axis=0)[groups==g]) for g in unique]) for key,v in extra.items()}
    return result,additional,float(np.mean(deltas)),unique,pd.concat(resource,ignore_index=True)

def development(plan_path):
    plan=json.loads(Path(plan_path).read_text());v,extra,delta,groups,resource=vectors(plan,'development');n=len(groups);sd=[];required=[]
    for key in [('LR','J10'),('LR','H')]:
        s=float(np.std(v[key],ddof=1));upper=s*np.sqrt((n-1)/chi2.ppf(.025,n-1));sd.append(upper)
        needed=max(2,int(math.ceil((t.ppf(1-.01/4,n-1)*upper/(delta/2))**2)));required.append(needed)
    first=np.load(ROOT/f'e3/runs/LC2012_{plan["seeds"][0]}/predictions.npz');available=len(np.unique(first['group'][first['test']]))
    result={'plan_sha256':sha(plan_path),'development_entity_groups':n,'delta':delta,'halfwidth_target':delta/2,'sd_conservative_upper':sd,
        'required_test_groups_approx':required,'fixed_available_test_groups':available,'precision_limited':max(required)>available,
        'test_risks_evaluated':False,'test_predictions_committed':True,'no_test_or_seed_expansion':True,
        'scope':'conditional fixed-cohort effect estimates and falsifiable boundary predictions; no guaranteed target precision',
        'candidate_truncations':int(resource[resource.kind=='main'].candidate_truncation.sum())}
    write(ROOT/'e3/development_precision_before_T.json',result);print(json.dumps(result),flush=True)

def final(plan_path):
    plan=json.loads(Path(plan_path).read_text());dev=json.loads((ROOT/'e3/development_precision_before_T.json').read_text());assert not dev['test_risks_evaluated']
    for f,h in plan['source_hashes'].items():assert sha(ROOT/f)==h
    v,extra,delta,groups,resource=vectors(plan,'test');assert delta==dev['delta'];n=len(groups)
    keys=[('LR','J10'),('LR','H'),('XGB','J10'),('XGB','H')];matrix=np.array([v[k] for k in keys]);point=matrix.mean(axis=1)
    rng=np.random.default_rng(52099);boot=[]
    for start in range(0,19999,256):
        m=min(256,19999-start);weights=rng.multinomial(n,np.full(n,1/n),size=m);boot.append(weights@matrix.T/n)
    draws=np.vstack(boot);low,high=np.quantile(draws,[.01/4,1-.01/4],axis=0)
    results=[]
    for i,(learner,endpoint) in enumerate(keys):
        lo,hi=float(low[i]),float(high[i]);band=lo> -delta and hi<delta
        if lo>delta:verdict='supports_practical_positive'
        elif hi< -delta:verdict='supports_practical_negative'
        elif band:verdict='within_practical_band'
        elif hi<delta:verdict='excludes_practical_positive'
        else:verdict='unresolved'
        prediction_supported=(hi<delta) if endpoint=='J10' else band
        results.append({'learner':learner,'endpoint':endpoint,'point':float(point[i]),'low':lo,'high':hi,'delta':delta,'n_entity_groups':n,
            'verdict':verdict,'primary':learner=='LR','predeclared_boundary_prediction_supported':prediction_supported if learner=='LR' else None})
    np.savez_compressed(ROOT/'e3/private_test_paired_contrasts.npz',entity_group=groups,paired_contrasts=matrix,bootstrap=draws)
    # Public bootstrap distribution contains no individual identifiers or predictions.
    np.savez_compressed(ROOT/'e3/public_bootstrap_draws.npz',bootstrap=draws,point=point,low=low,high=high)
    pd.DataFrame(results).to_csv(ROOT/'e3/primary_and_secondary.csv',index=False)
    resource.groupby(['kind','learner','history','action']).agg({'selected_count':'mean','spend':'mean','budget':'mean'}).to_csv(ROOT/'e3/resource_summary.csv')
    write(ROOT/'e3/results.json',{'cohort':'previously unused LC2012 term36, fixed 6000 rows','results':results,'alpha_LR_family':.01,
        'methods_and_rounds_not_independent_n':True,'fixed_test_groups':n,'bootstrap_draws':19999,'bootstrap_seed':52099,
        'conditioning':'test entity uncertainty, conditional on fixed trained models and replay seeds, not across training populations',
        'secondary_E_means':{k:float(np.mean(x)) for k,x in extra.items()},'development_precision':dev,
        'not_new_institution_or_future_calendar_transfer':True,'test_risks_evaluated':True})
    print(json.dumps(results),flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('plan',type=Path);p.add_argument('--development',action='store_true');a=p.parse_args()
    development(a.plan) if a.development else final(a.plan)
