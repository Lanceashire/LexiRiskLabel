"""Finite cost/count-matched controls. No outcomes or feature arrays accepted."""
import time
import numpy as np
from scipy.optimize import milp, Bounds, LinearConstraint

def alternatives(cost,budget,pa,seed,targets=8,tolerance=.005,time_limit=2.):
    cost=np.asarray(cost,float);pa=np.sort(np.asarray(pa,int));k=len(pa);n=len(cost);start=time.monotonic()
    assert np.all(np.isfinite(cost)) and np.all(cost>0) and budget>=0
    if k==0 or k==n:
        return {'sets':[],'calls':[],'status':'proven_infeasible','reason':'equal_count_has_only_PA','seconds':time.monotonic()-start}
    assert budget>0
    scale=cost/budget;spend=float(scale[pa].sum());seen=[pa];found=[];calls=[]
    for j in range(targets):
        # Fixed random objective; no test risk used to choose among alternatives.
        rng=np.random.default_rng(np.random.SeedSequence([seed,8927,j]));obj=rng.normal(size=n)
        constraints=[LinearConstraint(np.ones((1,n)),k,k),LinearConstraint(scale[None,:],max(0,spend-tolerance),min(1.,spend+tolerance))]
        for s in seen:
            v=np.zeros(n);v[s]=1;constraints.append(LinearConstraint(v[None,:],-np.inf,k-1))
        tick=time.monotonic()
        result=milp(obj,integrality=np.ones(n),bounds=Bounds(np.zeros(n),np.ones(n)),constraints=constraints,
            options={'time_limit':time_limit,'mip_rel_gap':0.,'presolve':True})
        rec={'target':j,'solver_status':int(result.status),'message':result.message,'seconds':time.monotonic()-tick,
            'optimal':result.status==0,'proven_infeasible':result.status==2,'timeout_unknown':result.status==1}
        if result.x is not None:
            s=np.flatnonzero(result.x>.5)
            valid=(len(s)==k and not any(np.array_equal(s,t) for t in seen) and cost[s].sum()<=budget+1e-9 and abs(cost[s].sum()-cost[pa].sum())<=tolerance*budget+1e-9)
            rec['valid_incumbent']=bool(valid)
            if valid:
                seen.append(s);found.append(s.tolist());rec.update({'set':s.tolist(),'cost_gap_over_B':float((cost[s].sum()-cost[pa].sum())/budget),
                    'PA_overlap_fraction':float(len(np.intersect1d(s,pa))/k)})
        calls.append(rec)
        if result.status==2:break
    status='matched' if found else ('proven_infeasible' if any(c['proven_infeasible'] for c in calls) else 'unknown')
    return {'sets':found,'calls':calls,'status':status,'seconds':time.monotonic()-start}

def quantity_controls(cost,budget,pa):
    cost=np.asarray(cost,float);pa=np.asarray(pa,int);order=np.lexsort((np.arange(len(cost)),cost));k=len(pa)
    kstar=int(np.searchsorted(np.cumsum(cost[order]),budget+1e-10,side='right'))
    cap=float(cost[pa].sum());kcap=int(np.searchsorted(np.cumsum(cost[order]),cap+1e-10,side='right'))
    return {'MinRisk':np.sort(order[:kstar]),'MinRisk-k':np.sort(order[:k]),'MinRisk-spendcap':np.sort(order[:kcap])}
