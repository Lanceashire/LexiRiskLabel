"""Prospective E1/E2 joint-history intervention with frozen historical selectors."""
from pathlib import Path
from dataclasses import replace
import hashlib,json,sys,time
import numpy as np
import pandas as pd
from scipy.special import expit
from xgboost import XGBClassifier
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'vendor'))
from common import core,exact,four,sha,write,digest
from matched_controls import alternatives,quantity_controls
HISTORIES=['original_gap','broad_independent']
METHODS=['OrdinaryOnly','MinRisk','D-only','Pending-aware']
TRUTH=np.array([-1.,.8,1.4,0,0])
DIRECTIONS={'target':np.array([1.,0,0]),'unlock':np.array([1.,-2.,0])/np.sqrt(5.)}

def rng(w,tag,rep=None):return np.random.default_rng(np.random.SeedSequence([w,tag] if rep is None else [w,tag,rep]))
def probability(x):return expit(x@TRUTH)

def covariates(w,experiment):
    nd,nc,no=(800,400,4000) if experiment=='E1' else (269,50,110)
    a=rng(w,1).uniform(-2,.8,nd);z1=rng(w,2).normal(size=nd);z2=rng(w,3).normal(size=nd);z3=rng(w,4).normal(size=nd)
    D={}
    for hist in HISTORIES:
        d=np.ones((nd,5));d[:,1]=a;d[:,4]=z3
        if hist=='original_gap':d[:,2]=.12*z1;d[:,3]=d[:,2]+.05*z2
        else:d[:,2]=1.2*z1;d[:,3]=z2
        D[hist]=d
    C=np.ones((nc,5));C[:,1]=1+np.log(3);C[:,2]=rng(w,5).normal(0,1.2,nc);C[:,3:]=rng(w,6).normal(size=(nc,2))
    def target(n,tag):
        x=np.zeros((n,5));x[:,0]=1;x[:,1]=rng(w,tag).uniform(-2,2.2,n);x[:,2]=rng(w,tag+1).normal(0,1.2,n);return x
    Q=target(1024,10);T=target(8192,20)
    aO=rng(w,40).uniform(-2,.8,no);rad=rng(w,41).normal(0,1.2,no)
    O={}
    for direction,d in DIRECTIONS.items():O[direction]=np.c_[np.ones(no),aO,rad[:,None]*d]
    raw_price=.75*(rng(w,50).uniform(.5,1.5,nc) if experiment=='E1' else np.linspace(.5,1.5,nc))
    cost=rng(w,51).permutation(raw_price)
    ud=rng(w,30).random(nd);yD={h:(ud<probability(d)).astype(np.uint8) for h,d in D.items()}
    return {'D':D,'yD':yD,'C':C,'Q':Q,'T':T,'O':O,'cost':cost,'ud':ud,'ids':np.arange(nd+no,nd+no+nc),
        'B':.1*float(raw_price.sum())}

def choose_all(e,w,experiment):
    # The visible State is the selector's entire interface: no truth/T/future y.
    states=[];mr_cache={};d_cache={}
    for hist in HISTORIES:
        theta=core.fit_logistic(e['D'][hist],e['yD'][hist],1.)
        specs=[(d,n,None,e['B']) for d in ['target','unlock'] for n in [110,4000]] if experiment=='E1' else [
            ('unlock',110,k,float(np.sort(e['cost'])[:k].sum()+.5*np.sort(e['cost'])[k])) for k in [3,15]]
        for direction,no,capacity,B in specs:
            s=core.State(e['D'][hist],e['yD'][hist],e['O'][direction][:no],e['C'],e['Q'],e['cost'],B,theta,w,ridge=1.,exchanges=0)
            key=(capacity,B)
            if key not in mr_cache:
                order=np.lexsort((e['ids'],s.cost));k=core.kstar(s.cost,B)
                if capacity is not None:assert k==capacity
                mr_cache[key]=np.sort(order[:k])
            dk=(hist,capacity,B)
            if dk not in d_cache:
                h,g,u=core.geometry(s,False);d_cache[dk]=np.sort(exact.greedy(h,g,u,s.cost,B,e['ids']))
            h,g,u=core.geometry(s,True);pa=np.sort(exact.greedy(h,g,u,s.cost,B,e['ids']))
            acts={'OrdinaryOnly':np.empty(0,int),'MinRisk':mr_cache[key],'D-only':d_cache[dk],'Pending-aware':pa}
            match=None
            if experiment=='E2':
                qc=quantity_controls(s.cost,B,pa);acts.update(qc)
                match=alternatives(s.cost,B,pa,w+(0 if hist=='original_gap' else 100000),targets=8,tolerance=.005,time_limit=2.)
                acts.update({f'Match{i}':np.array(v,int) for i,v in enumerate(match['sets'])})
            inv=core.inverse(core.geometry(s,False)[0]);coverage=float(np.trace(g@(inv-core.inverse(h))))/max(float(np.trace(g@inv)),1e-15)
            record={'history':hist,'direction':direction,'O_n':no,'capacity':capacity,'budget':B,'coverage':coverage,
                'actions':{name:a.tolist() for name,a in acts.items()},'matching':match,
                'visible_covariates_hash':digest([s.visible_x,s.ordinary_x,s.candidate_x,s.reference_x]),'visible_labels_hash':digest(s.visible_y),
                'cost_sha256':hashlib.sha256(e['cost'].tobytes()).hexdigest()}
            for name,a in acts.items():assert s.cost[a].sum()<=B+1e-8 and len(a)==len(set(a))
            states.append(record)
    return states

def validate_fixed_actions(states,experiment):
    for a in states:
        for b in states:
            if a['budget']!=b['budget']:continue
            assert a['actions']['MinRisk']==b['actions']['MinRisk']
            if a['history']==b['history']:assert a['actions']['D-only']==b['actions']['D-only']

def fit(xt,yt,T,learner,seed):
    if learner=='LR':
        coef=core.fit_logistic(xt,yt,1.);return expit(T@coef),coef
    model=XGBClassifier(n_estimators=100,max_depth=3,learning_rate=.1,max_bin=256,tree_method='hist',device='cpu',n_jobs=1,
        random_state=seed,objective='binary:logistic',eval_metric='logloss')
    model.fit(xt[:,1:].astype(np.float32),yt)
    assert json.loads(model.get_booster().save_config())['learner']['generic_param']['device']=='cpu'
    return model.predict_proba(T[:,1:].astype(np.float32))[:,1],None

def run_world(w,plan_path):
    plan_path=Path(plan_path);plan=json.loads(plan_path.read_text());assert w in plan['world_ids']
    for file,h in plan['source_hashes'].items():assert sha(ROOT/file)==h,('frozen source drift',file)
    dest=ROOT/plan['output_dir']/f'w{w}';identity=sha(plan_path)
    if (dest/'complete.json').exists():
        prior=json.loads((dest/'complete.json').read_text());assert prior['plan_sha256']==identity;return prior
    if dest.exists() and any(dest.iterdir()):dest.rename(dest.with_name(dest.name+'_interrupted_'+str(time.time_ns())))
    dest.mkdir(parents=True,exist_ok=True)
    started=time.monotonic();experiment=plan['experiment'];e=covariates(w,experiment);states=choose_all(e,w,experiment)
    validate_fixed_actions(states,experiment)
    write(dest/'selection_locks.json',states);lock_hash=sha(dest/'selection_locks.json')
    write(dest/'lock_commitment.json',{'sha256':lock_hash,'plan_sha256':identity,'world':w,'all_future_labels_unreleased':True,
        'selector_truth_or_T_arguments':False,'created_ns':time.time_ns()})
    # Future random numbers and all future labels are produced only AFTER all state locks.
    target=e['T'];pT=probability(target);yT=(rng(w,32).random(len(target))<pT).astype(np.uint8)
    records=[];fits=[];lrcoef=[];xgbpred=[];lrindex=[];xgbindex=[];uniform_O=[];uniform_C=[];releases=[]
    for rep in range(plan['label_repeats']):
        uo=rng(w,61001,rep).random(max(len(x) for x in e['O'].values()));uc=rng(w,61002,rep).random(len(e['C']))
        uniform_O.append(uo);uniform_C.append(uc);yc=(uc<probability(e['C'])).astype(np.uint8)
        assert sha(dest/'selection_locks.json')==lock_hash
        for si,state in enumerate(states):
            hist,direction,no=state['history'],state['direction'],state['O_n'];D=e['D'][hist];O=e['O'][direction][:no]
            yo=(uo[:no]<probability(O)).astype(np.uint8);cache={}
            for method,selected in state['actions'].items():
                selected=np.array(selected,int);key=tuple(selected.tolist())
                if key not in cache:
                    X=np.vstack([D,O,e['C'][selected]]);Y=np.r_[e['yD'][hist],yo,yc[selected]];pair={}
                    releases.append({'rep':rep,'state':si,'selected_indices':selected.tolist(),'O_prefix_n':no,'lock_sha256':lock_hash,
                        'future_y_sha256':hashlib.sha256(np.r_[yo,yc[selected]].tobytes()).hexdigest()})
                    for learner in ['LR','XGB']:
                        fid=len(fits);pred,coef=fit(X,Y,target,learner,w+7000)
                        actual={'fit_id':fid,'rep':rep,'state':si,'learner':learner,'selected':selected.tolist(),
                            'training_sha256':hashlib.sha256(X.tobytes()+Y.tobytes()).hexdigest(),
                            'excess_Brier':float(np.mean((pred-pT)**2)),'sampled_Brier':float(np.mean((yT-pred)**2))}
                        fits.append(actual);pair[learner]=actual
                        if learner=='LR':lrcoef.append(coef);lrindex.append(fid)
                        else:xgbpred.append(pred);xgbindex.append(fid)
                    cache[key]=pair
                for learner,actual in cache[key].items():
                    records.append({'world':w,'rep':rep,'state':si,'history':hist,'direction':direction,'O_n':no,'capacity':state['capacity'],
                        'learner':learner,'method':method,'fit_id':actual['fit_id'],'excess_Brier':actual['excess_Brier'],
                        'sampled_Brier':actual['sampled_Brier'],'selected_count':len(selected),'spend':float(e['cost'][selected].sum()),
                        'budget':state['budget'],'coverage':state['coverage']})
    pd.DataFrame(records).to_csv(dest/'risks.csv',index=False);write(dest/'fits.json',fits);write(dest/'release_log.json',releases)
    arrays={'C':e['C'],'Q':e['Q'],'T':target,'pT':pT,'yT':yT,'cost':e['cost'],'uD':e['ud'],'uO':np.array(uniform_O),'uC':np.array(uniform_C),
        'lrcoef':np.array(lrcoef),'lr_fit_id':np.array(lrindex),'xgbpred':np.array(xgbpred),'xgb_fit_id':np.array(xgbindex)}
    arrays.update({f'D_{h}':e['D'][h] for h in HISTORIES});arrays.update({f'yD_{h}':e['yD'][h] for h in HISTORIES})
    arrays.update({f'O_{d}':x for d,x in e['O'].items()});np.savez_compressed(dest/'raw.npz',**arrays)
    assert sha(dest/'selection_locks.json')==lock_hash
    summary={'world':w,'plan_sha256':identity,'experiment':experiment,'role':plan['role'],'complete':True,'states':len(states),
        'risk_records':len(records),'actual_model_fits':len(fits),'lock_sha256':lock_hash,'seconds':time.monotonic()-started,
        'future_labels_after_locks':True,'fixed_actions_verified':True,'CPU_explicit':True}
    write(dest/'complete.json',summary);return summary
