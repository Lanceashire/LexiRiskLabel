"""Portable E3 input reconstruction; preserve frozen original identity separately."""
from pathlib import Path
import argparse,hashlib,json,shutil,sys,urllib.request,subprocess
import numpy as np
import pandas as pd

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def main():
    here=Path(__file__).resolve().parent;default_root=here if (here/'src').exists() else here.parent
    p=argparse.ArgumentParser();p.add_argument('--study-root',type=Path,default=default_root);p.add_argument('--output',type=Path,required=True)
    p.add_argument('--source-file',type=Path);p.add_argument('--proxy');p.add_argument('--train-and-evaluate',action='store_true');a=p.parse_args()
    runtime=a.output;runtime.mkdir(parents=True,exist_ok=True)
    for f in ['src','vendor','protocols']:shutil.copytree(a.study_root/f,runtime/f,dirs_exist_ok=True)
    sys.path.insert(0,str(runtime/'vendor'));from data import LC_COLS,groups
    identity_path=a.study_root/'reports/e3_eligibility.json';identity=json.loads(identity_path.read_text())
    src=a.source_file
    if src is None:
        src=runtime/'private/e3_source/LendingClub_2007_to_2018Q4.csv';src.parent.mkdir(parents=True,exist_ok=True)
        op=urllib.request.build_opener(urllib.request.ProxyHandler({'http':a.proxy,'https':a.proxy} if a.proxy else {}))
        if not src.exists():
            with op.open(identity['source']['url'],timeout=90) as response,src.open('wb') as out:shutil.copyfileobj(response,out)
    assert sha(src)==identity['source']['sha256'],'source identity mismatch'
    pieces=[];offset=0
    for chunk in pd.read_csv(src,usecols=LC_COLS+['id','member_id','issue_d','loan_status'],chunksize=100000,low_memory=False):
        keep=chunk.issue_d.astype(str).str.endswith('2012')&chunk.term.astype(str).str.contains('36')&(pd.to_numeric(chunk.loan_amnt,errors='coerce')>0)
        part=chunk.loc[keep].copy();part['source_row']=np.flatnonzero(keep)+offset;offset+=len(chunk);pieces.append(part)
    df=pd.concat(pieces,ignore_index=True);df=df[df.loan_status.isin(['Fully Paid','Charged Off'])].reset_index(drop=True)
    df=df.iloc[np.sort(np.random.default_rng(52000).choice(len(df),6000,replace=False))].reset_index(drop=True)
    raw=df[LC_COLS].copy()
    for c in ['int_rate','revol_util']:raw[c]=pd.to_numeric(raw[c].astype(str).str.rstrip('%'),errors='coerce')
    group=groups(raw,{c:df[c].to_numpy() for c in ['id','member_id']})
    target=runtime/'private/e3_cohort';target.mkdir(parents=True,exist_ok=True);raw.to_pickle(target/'features.pkl')
    np.savez_compressed(target/'custodian.npz',y=(df.loan_status=='Charged Off').to_numpy(np.uint8),exposure=df.loan_amnt.to_numpy(float),
        group=group,source_row=df.source_row.to_numpy(),loan_id=df.id.astype(str).to_numpy(dtype='str'))
    assert sha(target/'features.pkl')==identity['features_sha256']
    assert sha(target/'custodian.npz')==identity['custodian_sha256']
    shutil.copy2(identity_path,target/'identity.json')
    frozen=json.loads((runtime/'protocols/e3_confirmation.json').read_text())
    assert sha(target/'identity.json')==frozen['source_identity_sha256']
    record={'public_wrapper_sha256':sha(__file__),'features_and_custodian_match_historical_bytes':True,
        'no_old_absolute_workspace_required':True,'historical_old_cohort_overlap_audit_retained_as_prior_provenance':True,
        'prior_overlap_audit_not_rerun_without_old_source_inputs':True,'test_risk_evaluated':False,
        'original_identity_sha256':sha(identity_path),'new_runtime':str(runtime.resolve())}
    (runtime/'PUBLIC_RERUN_IDENTITY.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True)
    if a.train_and_evaluate:
        for args in [('e3_controller.py',[]),('e3_audit.py',[]),('e3_analyze.py',['--development']),('e3_analyze.py',[])]:
            subprocess.run([sys.executable,str(runtime/'src'/args[0]),str(runtime/'protocols/e3_confirmation.json'),*args[1]],check=True)
if __name__=='__main__':main()
