"""Independent reconstruction of seven primary estimates and their intervals."""
from pathlib import Path
import json,hashlib
import numpy as np
import pandas as pd
from scipy.stats import t

def verify(root):
    root=Path(root);checks=[];worst=0.
    if (root/'MANIFEST_SHA256.json').exists():
        for f,rec in json.loads((root/'MANIFEST_SHA256.json').read_text()).items():
            p=root/f;assert hashlib.sha256(p.read_bytes()).hexdigest()==rec['sha256'] and p.stat().st_size==rec['bytes']
    for experiment,alpha,names in [('E1',.025,['anchor_J','history_by_O_ThetaJ','broad_J']),('E2',.015,['all_world_QM','complete_match_world_CM'])]:
        frame=pd.read_csv(root/f'synthetic/{experiment}/world_mean_risks.csv',float_precision='round_trip')
        result=json.loads((root/f'synthetic/{experiment}/results.json').read_text())['results'];values={}
        for (world,learner),group in frame.groupby(['world','learner']):
            states=[];j={}
            for (history,direction,no,capacity),g in group.groupby(['history','direction','O_n','capacity'],dropna=False):
                a=g.set_index('method').excess_Brier;J=float(a['MinRisk']-a['Pending-aware']);j[(history,direction,no)]=J
                if experiment=='E2':
                    matches=[k for k in a.index if k.startswith('Match')]
                    states.append((float(a['MinRisk-k']-a['MinRisk']),float(a[matches].mean()-a['Pending-aware']) if matches else None))
            if experiment=='E1':
                anchor=j[('original_gap','unlock',4000)];broad=j[('broad_independent','unlock',4000)]
                vector=[anchor,anchor-j[('original_gap','unlock',110)]-broad+j[('broad_independent','unlock',110)],broad]
            else:vector=[float(np.mean([s[0] for s in states])),float(np.mean([s[1] for s in states])) if all(s[1] is not None for s in states) else None]
            for name,v in zip(names,vector):
                if v is not None:values.setdefault((learner,name),[]).append(v)
        for row in result:
            v=np.array(values[(row['learner'],row['endpoint'])]);n=len(v);point=float(v.mean());half=float(t.ppf(1-alpha/(2*len(names)),n-1)*v.std(ddof=1)/np.sqrt(n))
            assert n==row['n']
            error=max(abs(point-row['point']),abs(point-half-row['low']),abs(point+half-row['high']));worst=max(worst,error)
            checks.append({'study':experiment,'learner':row['learner'],'endpoint':row['endpoint'],'n':n,'error':error})
    result=json.loads((root/'E3/results.json').read_text());z=np.load(root/'E3/public_bootstrap_draws.npz');moments=json.loads((root/'E3/paired_moments.json').read_text())
    low,high=np.quantile(z['bootstrap'],[.01/4,1-.01/4],axis=0)
    for i,row in enumerate(result['results']):
        point=moments[i]['sum']/moments[i]['n'];error=max(abs(point-row['point']),abs(low[i]-row['low']),abs(high[i]-row['high']));worst=max(worst,float(error))
        checks.append({'study':'E3','learner':row['learner'],'endpoint':row['endpoint'],'n':moments[i]['n'],'error':float(error)})
    assert worst<1e-12
    output={'passed':True,'primary_LR_endpoints':7,'all_primary_and_secondary_endpoints':len(checks),'max_statistic_reconstruction_error':worst,
        'source':'synthetic world-level risk tables; E3 aggregate paired moments and bootstrap draws','checks':checks}
    print(json.dumps(output,indent=2));return output
if __name__=='__main__':verify(Path(__file__).resolve().parent)
