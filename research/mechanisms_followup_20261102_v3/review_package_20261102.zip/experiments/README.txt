LexiRiskLabel E0-E3 completed mechanism study, explicit generator v2
2026-11-02

Start with E0_E3_完整研究报告.txt. Seven LR primary endpoints: 3 practical
positive, 2 within practical bands, 2 unresolved. Completion means execution
and audits are complete, not all scientific hypotheses succeeded.

Version identity
The external 16-world bridge implementation was unavailable. The user authorized
filling the missing definitions and continuing. The prospective numeric joint
history intervention and the precision-budget amendment were both saved before
fresh confirmation. Original M1-M5 files and registrations remain unchanged.
The amendment does not claim recovery of the external bridge code.
E1/E2: 512 independent confirmation worlds EACH; 32 pilots each excluded.
E3: previously unused mature LC2012 term36 cohort, 20 fixed seeds, 1200 test
groups; older historical-cohort test, not new institution or future-calendar test.

Read-only aggregate verification
Create an isolated Python3.14 environment and install the pinned requirements:
python -m venv .venv
.venv/bin/python -m pip install -r e0_full_public/requirements.lock.txt
export OPENBLAS_NUM_THREADS=1
export OMP_NUM_THREADS=1
export MPLCONFIGDIR=/tmp/m5-matplotlib
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 .venv/bin/python verify_portable.py

This independently reconstructs synthetic estimates and intervals from world
mean risks, and E3 estimates/intervals from aggregate paired moments and saved
bootstrap distributions. It does not reconstruct real individual losses from
the aggregate ZIP. Original local individual losses and predictions were audited
separately and are excluded from this review package.

E0 full training reproduction
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MPLCONFIGDIR=/tmp/m5-matplotlib \
 .venv/bin/python e0_full_public/run_full.py --data-dir ./local_inputs \
 --output ./e0_runtime --seed 51001

Missing input files are downloaded from the registered university/UCI URLs and
checked against the original SHA256. --proxy http://127.0.0.1:7897 is OPTIONAL;
no proxy is required by default. This runs original unmodified M5 code including
all ten main rounds and common-state branches for both tasks. Original gates
remain intact. The fresh-venv, fresh-download execution passed for one complete
seed per task; the original 40 tasks were not all rerun in the new environment.
The 202 checked NPZ files comprise 2 splits and 200 prediction files, all
bitwise identical to original records. Another physical machine was not tested.

Full synthetic regeneration
For each of e1 and e2:
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MPLCONFIGDIR=/tmp/m5-matplotlib \
 .venv/bin/python src/controller.py protocols/e1_confirmation.json --workers 4
.venv/bin/python src/audit_worlds.py protocols/e1_confirmation.json --refit-first
.venv/bin/python src/analyze.py protocols/e1_confirmation.json

Substitute e2_confirmation.json for E2. These regenerate raw synthetic arrays,
locks, releases and risk records under confirmation/, distinct from the read-only
delivered tables under synthetic/. Do not edit frozen code or protocol files.

E3 portable source reconstruction and optional full replay
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MPLCONFIGDIR=/tmp/m5-matplotlib \
 .venv/bin/python public_e3.py --output ./e3_public_runtime \
 --source-file /path/to/LendingClub_2007_to_2018Q4.csv

Without --source-file, the 1.675GB public university source is downloaded and
its exact SHA checked. Proxy is optional. The wrapper reconstructs the exact
6000-row cohort without the author's old absolute layout, and verifies both
feature and custodian file hashes. The original old-cohort overlap audit is
retained as historical provenance; it is not falsely labelled as rerun without
the old files. New public runtime identity is recorded separately.
Add --train-and-evaluate to execute all 20 frozen replays, full prediction audit,
development-only precision record, and then final T evaluation. Test results
cannot be used to extend seed, sample, cohort or endpoint choices.

Evidence and privacy
synthetic/: world-level risk tables, fixed-action gains, matching feasibility,
same-subgroup accounting, endpoint results and raw audit receipts.
engineering/: one completely synthetic raw engineering example per experiment.
E3/: aggregate bootstrap, moments, metadata, results and independent audits.
E0_clean_reproduction/: complete clean-rerun receipt and aggregate round risks.
protocols/: original drafts' resolved v2 design, source and precision amendments.
claim_evidence.csv: primary claims mapped to scope and independent units.

No real applicant feature rows, true individual labels, individual predictions,
private test IDs or private paired-loss arrays are included. Synthetic generated
labels and predictions in the engineering examples are explicitly synthetic.
Third-party raw data are not redistributed or relicensed by this package.
No new GitHub commit was published this turn.
