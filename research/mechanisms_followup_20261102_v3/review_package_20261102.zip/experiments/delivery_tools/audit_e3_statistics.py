from pathlib import Path
import sys,json
import numpy as np
import pandas as pd
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from study import ROOT,core,write
from data import preprocess
from scipy.special import expit

def main():
    cust=np.load(ROOT/'private/e3_cohort/custodian.npz');raw=pd.read_pickle(ROOT/'private/e3_cohort/features.pkl')
    vectors=[];deltas=[];groups=None
    for seed in range(51001,51021):
        p=ROOT/'e3/runs'/f'LC2012_{seed}';z=np.load(p/'predictions.npz');T=z['test'];dev=z['development'];n=len(dev);group=z['group'][T]
        if groups is None:groups=group
        else:assert np.array_equal(groups,group)
        assert len(np.unique(group))==len(group)
        y=cust['y'][T];main=z['main'].reshape(2,5,10,-1)[:,:,:,n:]
        cross=z['cross'].reshape(2,2,3,2,-1)[:,:,:,:,n:]
        lm=(y-main)**2;lc=(y-cross)**2
        J=np.mean(lm[:,1]-lm[:,3],axis=1)
        H=np.mean((lc[:,1,:,0]-lc[:,1,:,1])-(lc[:,0,:,0]-lc[:,0,:,1]),axis=1)
        vectors.append(np.array([J[0],H[0],J[1],H[1]]))
        x,_=preprocess(raw,z['initial']);theta=core.fit_logistic(x[z['initial']],cust['y'][z['initial']],1.)
        deltas.append(.005*float(np.mean((cust['y'][dev]-expit(x[dev]@theta))**2)))
    expected=np.mean(vectors,axis=0);stored=np.load(ROOT/'e3/private_test_paired_contrasts.npz');error=float(np.max(np.abs(expected-stored['paired_contrasts'])))
    assert error<1e-14
    n=expected.shape[1];rng=np.random.default_rng(52099);draws=[]
    for start in range(0,19999,512):
        m=min(512,19999-start);weights=rng.multinomial(n,np.full(n,1/n),size=m);draws.append(weights@expected.T/n)
    draws=np.vstack(draws);booterror=float(np.max(np.abs(draws-stored['bootstrap'])));assert booterror<1e-14
    result=json.loads((ROOT/'e3/results.json').read_text());low,high=np.quantile(draws,[.0025,.9975],axis=0)
    maxstat=0.
    for i,r in enumerate(result['results']):
        maxstat=max(maxstat,abs(expected[i].mean()-r['point']),abs(low[i]-r['low']),abs(high[i]-r['high']),abs(np.mean(deltas)-r['delta']))
    assert maxstat<1e-14
    audit={'passed':True,'independent_array_reshape_reconstruction':True,'test_entity_groups':n,'all_four_endpoints_rebuilt':True,
        'paired_entity_contrast_max_error':error,'bootstrap_draws_independently_regenerated':19999,'bootstrap_max_error':booterror,
        'delta_and_interval_max_error':maxstat,'development_delta_recomputed_from_all_20_D0_models':True}
    write(ROOT/'e3/independent_statistics_audit.json',audit);print(json.dumps(audit),flush=True)
if __name__=='__main__':main()
