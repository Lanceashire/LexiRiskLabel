"""Transparent postprocessing of frozen M2 diagnostics; never a new primary test."""
from pathlib import Path
import sys, json, hashlib
import numpy as np
import pandas as pd
from scipy.stats import t

OLD=Path('LOCAL_WORKSPACE/2026-10-31/ji-x')
D=OLD/'work/M2_mechanism_bridge'

def ci(x, family):
    x=np.asarray(x); n=len(x); se=x.std(ddof=1)/np.sqrt(n)
    radius=t.ppf(1-.05/(2*family),n-1)*se
    return dict(n_worlds=n,mean=float(x.mean()),low=float(x.mean()-radius),high=float(x.mean()+radius))

def main():
    # Exact matrix statements, checked independently of classifier outcomes.
    H=np.eye(2); A=np.diag([0.,1.]); G=np.diag([1.,0.]); J=np.ones((2,2))
    def gain(j,s):
        return float(np.trace(G@(np.linalg.inv(H+s*j)-np.linalg.inv(H+s*j+A))))
    grid=np.r_[0.,np.logspace(-4,4,101)]
    closed=lambda s:s*s/((1+2*s)*(2+3*s))
    maxerr=max(abs(gain(J,s)-closed(s)) for s in grid)
    assert maxerr<1e-10 and all(gain(J,b)>=gain(J,a)-1e-12 for a,b in zip(grid[:-1],grid[1:]))
    # Full-rank ordinary information: value vanishes at both zero and infinity,
    # and is positive in between. A direction alone cannot specify an interval sign.
    full=J+.1*np.eye(2)
    assert gain(full,0)==0 and gain(full,1)>gain(full,.001) and gain(full,1)>gain(full,1e6)
    rng=np.random.default_rng(2601031)
    for _ in range(100):
        h=rng.uniform(.1,3,5); a=rng.uniform(0,3,5); j=rng.uniform(0,3,5); g=rng.uniform(0,3,5)
        values=[np.sum(g*a/((h+s*j)*(h+s*j+a))) for s in [0,.01,.1,1,10,100]]
        assert np.all(np.diff(values)<=1e-12)
    proof='''M2固定选集的可检验条件（本轮补充推导，非新增主检验）

设H正定，普通信息J、选集信息A、目标权重G均半正定。
F(t)=tr G[(H+tJ)^(-1)-(H+tJ+A)^(-1)]。
F'(t)=tr G[(H+tJ+A)^(-1)J(H+tJ+A)^(-1)
                 -(H+tJ)^(-1)J(H+tJ)^(-1)]。
因此区间内价值变化是该导数的积分；unlock方向名称不能保证导数或差之差为正。

充分替代条件：若四个实对称矩阵可同时正交对角化，
F(t)=sum_i g_i a_i/[(h_i+t j_i)(h_i+t j_i+a_i)]，每项非增。
所以在这组条件下不存在绝对价值随信息强度增加的解锁；此结论并不保证
相对于另一方向的差之差K也为正。违反可交换条件只提供解锁可能性，不保证解锁。

明确解锁例：H=I2，A=diag(0,1)，G=diag(1,0)，J=[[1,1],[1,1]]。
直接求逆可得F(t)=t^2/[(1+2t)(2+3t)]，t>0时严格增加。
若J改为上述J+0.1I，则F(0)=0、t>0时F(t)>0、t趋于无穷时F(t)趋于0，
因此同一斜向信息存在先解锁、后替代的区间，不能把某一有限区间的负结果泛化为不存在解锁。
本例是矩阵模型中的构造性结果，不是新分类实验的正向证据。

分类桥：固定D标签后，一阶logistic风险R_cond=B+V=tr(G H_total^-1)
 + tr[G H_total^-1(b_D b_D^T-H_D)H_total^-1]。
此恒等式只对线性化误差模型精确；实际重训还包含非线性与近似余项。
完整风险对比可写成K_actual=K_estimated_proxy
 +(K_true_proxy-K_estimated_proxy)+K_D_correction+K_linearization_residual。
最后三项不能因为具有解释名称而预设为零；诊断的恒等分解不等于因果归因。
'''
    (D/'M2_MECHANISM_CONDITIONS_AND_LIMITS.txt').write_text(proof)
    cc=pd.read_csv(D/'independent_component_world_contrasts.csv')
    aa=pd.read_csv(D/'independent_analytic_world_contrasts.csv')
    actual=cc[cc.component=='total_gain'].rename(columns={'value':'actual'})
    p=aa.pivot(index=['variant','world_id','contrast'],columns='component',values='value').reset_index()
    joined=actual.merge(p,on=['variant','world_id','contrast'],validate='many_to_one')
    joined['Fisher_estimation_gap']=joined.true_Bayes_proxy-joined.estimated_Bayes_proxy
    joined['local_approximation_residual']=joined.actual-joined.local_conditional_total_gain
    joined['reconstructed']=joined.estimated_Bayes_proxy+joined.Fisher_estimation_gap+joined.D_anchor_correction_gain+joined.local_approximation_residual
    maxbridge=float(np.abs(joined.actual-joined.reconstructed).max());assert maxbridge<1e-12
    joined.to_csv(D/'posthoc_full_risk_bridge_worlds.csv',index=False)
    rows=[]
    for key,q in joined.groupby(['variant','learner','contrast']):
        for component in ['estimated_Bayes_proxy','Fisher_estimation_gap','D_anchor_correction_gain','local_approximation_residual','actual']:
            rows.append(dict(zip(['variant','learner','contrast'],key))|{'component':component}|ci(q[component],40))
    pd.DataFrame(rows).to_csv(D/'posthoc_full_risk_bridge_summary.csv',index=False)
    weak=pd.read_csv(D/'five_count_adjacent_contrast_summary.csv')
    # Report every registered adjacent interval, including unresolved diagnostics.
    weak['interval_sign']=np.where(weak.simultaneous_low>0,'positive',np.where(weak.simultaneous_high<0,'negative','includes_zero'))
    weak.to_csv(D/'weak_all_adjacent_interval_signs.csv',index=False)
    diag=json.loads((D/'diagnostic_completion.json').read_text())
    wd=json.loads((D/'weak_diagnostic_completion.json').read_text())
    assert diag['passed'] and wd['passed']
    report={'completed':True,'all_registered_diagnostics_reported':True,
      'primary_hypotheses_unchanged':True,'exact_matrix_example_max_error':maxerr,
      'risk_bridge_accounting_max_error':maxbridge,'posthoc_residual_summary_scope':'40 descriptive simultaneous t intervals; separate from primary and prospective component families; no new primary promotion',
      'diagnostic_cells_with_total_interval_crossing_zero':int(((pd.read_csv(D/'independent_component_summary.csv').query("component == 'total_gain'").simultaneous_low<=0)&(pd.read_csv(D/'independent_component_summary.csv').query("component == 'total_gain'").simultaneous_high>=0)).sum()),
      'mechanism_explanation_status':'geometry conditions and conditional risk object distinction established; D-anchor correction alone does not reproduce original substitution reversal; finite-M bias estimates remain uncertain; no universal classifier unlocking mechanism established',
      'all_32_adjacent_intervals_reported':len(weak)==32,
      'mathematical_proof_file':'M2_MECHANISM_CONDITIONS_AND_LIMITS.txt'}
    assert report['all_32_adjacent_intervals_reported']
    (D/'boundary_analysis_completion.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(report,ensure_ascii=False,indent=2))

if __name__=='__main__':main()
