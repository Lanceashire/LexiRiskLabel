from pathlib import Path
import subprocess,sys,time,json,os
HERE=Path(__file__).resolve().parent
OLD=Path('LOCAL_WORKSPACE/2026-10-31/ji-x')
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MPLCONFIGDIR=str(OLD/'work/mpl'))

def run(name,script,cwd):
    print('START',name,time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),flush=True)
    with (HERE/(name+'.log')).open('w') as log:
        p=subprocess.run([sys.executable,str(script)],cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT)
    if p.returncode:raise RuntimeError(f'{name} failed, inspect {HERE/(name+".log")}')
    print('PASS',name,flush=True)

def main():
    complete=OLD/'work/M2_weak_boundary_confirmation/completion.json'
    while not complete.exists():time.sleep(5)
    assert json.loads(complete.read_text())['completed']
    run('M2_weak_analysis_final',OLD/'work/analyze_m2_weak_response.py',OLD)
    run('M2_weak_recovery_check',HERE/'verify_weak_recovery.py',HERE.parent)
    run('M2_mechanism_boundary_final',HERE/'complete_m2_boundary.py',HERE.parent)
    run('M2_supplemental_acceptance_final',OLD/'work/accept_m2_serious_completion.py',OLD)
    assert json.loads((OLD/'work/M2_mechanism_bridge/M2_FINAL_ACCEPTANCE.json').read_text())['M2_complete']
    run('M2_final_figures',OLD/'work/plot_m2_serious.py',OLD)
    print('ANALYSIS_AND_ACCEPTANCE_COMPLETE',flush=True)

if __name__=='__main__':main()
