from pathlib import Path
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
D=Path('LOCAL_WORKSPACE/2026-10-31/ji-x/work/M2_mechanism_bridge')
f=pd.read_csv(D/'five_count_adjacent_contrast_summary.csv')
fig,axes=plt.subplots(1,2,figsize=(12,4.8))
for ax,variant,contrast,title in [(axes[0],'isospectral','K_unlock','Zero-target-signal control / LR: unlocking'),(axes[1],'original','K_sub','Original signal / LR: substitution')]:
    q=f[(f.variant==variant)&(f.learner=='LR')&(f.contrast==contrast)].sort_values('ordinary_low')
    for y,r in enumerate(q.itertuples()):
        color='#b2182b' if r.simultaneous_low>0 else '#2166ac' if r.simultaneous_high<0 else '#777777'
        ax.errorbar(r.mean,y,xerr=[[r.mean-r.simultaneous_low],[r.simultaneous_high-r.mean]],fmt='o',color=color,capsize=4,ms=6)
    ax.set_yticks(range(4),[f'{int(r.ordinary_low):,} to {int(r.ordinary_high):,}' for r in q.itertuples()])
    ax.invert_yaxis();ax.axvline(0,color='black',lw=.8,ls='--');ax.set_title(title,fontsize=11)
    ax.set_ylabel('Ordinary feedback count interval');ax.set_xlabel(f'{contrast} (excess Brier interaction)');ax.grid(axis='x',alpha=.2)
    ax.spines[['top','right']].set_visible(False)
fig.suptitle('Mechanism direction depends on the feedback interval\nSame 64 independent worlds and fixed exploration sets; 16 paired label draws',fontsize=13)
fig.text(.5,.015,'Descriptive simultaneous intervals across all 32 adjacent contrasts. These do not replace the original 500-to-4,000 primary tests.',ha='center',fontsize=9)
fig.tight_layout(rect=[0,.055,1,.90])
fig.savefig(D/'figures/M2_feedback_interval_boundaries.png',dpi=180)
print('saved M2_feedback_interval_boundaries.png')
