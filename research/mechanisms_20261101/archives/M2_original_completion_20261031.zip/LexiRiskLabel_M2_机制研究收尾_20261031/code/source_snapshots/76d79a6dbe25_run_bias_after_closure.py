"""One-shot dependency queue: independent M2 diagnostics after primary GPU study."""
from pathlib import Path
import json,hashlib,time,subprocess,concurrent.futures,sys
TASK=Path('LOCAL_WORKSPACE/2026-10-31/ji-x')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,q):
    t=p.with_suffix('.tmp');t.write_text(json.dumps(q,ensure_ascii=False,indent=2)+'\n');t.replace(p)
def main():
    out=TASK/'work/M2_conditional_bridge_confirmation';out.mkdir(exist_ok=True)
    protocols=sorted((TASK/'work/m2_bias_protocols').glob('batch_*.json'))
    paths=[Path(__file__),TASK/'work/m2_bias_confirmation.py',TASK/'work/m2_bias_confirmation_protocol.json']+protocols
    sources={str(p):sha(p) for p in paths}
    write(out/'registration.json',{'sources':sources,'main_protocol':json.loads((TASK/'work/m2_bias_confirmation_protocol.json').read_text()),'role':'independent diagnostic validation; no replacement of original primary family','queued_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())})
    primary=TASK/'work/M2_independent_closure_20261031/execution_complete.json'
    while not primary.exists():
        status=subprocess.run(['systemctl','--user','is-active','lexirisk-m2-close-20261031.service'],capture_output=True,text=True)
        if status.returncode:raise RuntimeError('Primary M2 execution ended without completion; diagnostic queue stops')
        time.sleep(10)
    assert all(sha(Path(p))==h for p,h in sources.items())
    def run(p):
        child=out/p.stem
        if not (child/'completion.json').exists():
            if child.exists():child.rename(out/f'{p.stem}_interrupted_{time.time_ns()}')
            with (out/f'{p.stem}.log').open('w') as log:
                q=subprocess.run([sys.executable,str(TASK/'work/m2_bias_confirmation.py'),'--protocol',str(p),'--out',str(child)],stdout=log,stderr=subprocess.STDOUT)
            if q.returncode:raise RuntimeError(f'diagnostic batch {p} failed')
        complete=json.loads((child/'completion.json').read_text());assert complete['completed'] and complete['saved_prediction_max_error']==0
        return {'path':str(child),'protocol':str(p),'completion':complete}
    results=[]
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        futures=[pool.submit(run,p) for p in protocols]
        for future in futures:
            results.append(future.result());write(out/'batch_index.json',results);print('diagnostic complete batches',len(results),flush=True)
    assert sum(x['completion']['worlds'] for x in results)==64 and all(sha(Path(p))==h for p,h in sources.items())
    write(out/'completion.json',{'completed':True,'worlds':64,'label_M':32,'nominal_slots':98304,'actual_CUDA_fits':sum(x['completion']['actual_fits']['XGB'] for x in results),'actual_LR_fits':sum(x['completion']['actual_fits']['LR'] for x in results),'sources_unchanged':True,'no_later_stages':True,'M2_complete':False,'pending':'independent audit, bias/variance and theory-bridge analysis'})
if __name__=='__main__':main()
