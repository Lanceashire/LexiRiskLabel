import sys,unittest,itertools
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent/'m2_closure'))
from common import *
from scipy.special import expit
import pandas as pd

class CompletionMathTests(unittest.TestCase):
    def test_historical_family_keeps_exactly_one_pending_cell(self):
        run=Path(json.loads((Path(__file__).parent/'m2_closure/protocol.json').read_text())['historical_run'])
        f=pd.read_csv(run/'look_4096/world_interactions.csv');pending=[]
        for key,q in f.groupby(['variant','learner','contrast']):
            if interval(q.value,.025,8,4)['verdict']=='unresolved':pending.append(key)
        self.assertEqual(pending,[('isospectral','XGB','K_unlock')])

    def test_alpha_and_world_ranges(self):
        p=json.loads((Path(__file__).parent/'m2_closure/protocol.json').read_text())
        self.assertEqual(p['historical_family_alpha']+p['supplemental_family_alpha'],.05)
        self.assertEqual(p['delta'],.0001);self.assertEqual(p['look_world_counts'],[8192,32768])
        self.assertTrue(max(p['engineering_world_ids'])<p['first_world_id'])
        self.assertGreater(p['first_world_id'],40096)

    def test_multirank_information_derivative(self):
        rng=np.random.default_rng(992001)
        for _ in range(20):
            x=rng.normal(size=(5,5));h=x.T@x+np.eye(5);x=rng.normal(size=(3,5));a=x.T@x;x=rng.normal(size=(4,5));o=x.T@x;x=rng.normal(size=(5,5));g=x.T@x
            def value(t):return np.trace(g@(np.linalg.inv(h+t*o)-np.linalg.inv(h+t*o+a)))
            for t0 in [.25,1.,8.]:
                inv=np.linalg.inv(h+t0*o);after=np.linalg.inv(h+t0*o+a);analytic=np.trace(g@(after@o@after-inv@o@inv));numeric=(value(t0+1e-5)-value(t0-1e-5))/2e-5
                self.assertAlmostEqual(float(analytic),float(numeric),places=7)

    def test_conditional_expansion_exact_finite_bernoulli_noise(self):
        rng=np.random.default_rng(992002);xd=rng.normal(size=(7,3));xf=rng.normal(size=(5,3));beta=np.array([.4,-.6,.2]);pd0=expit(xd@beta);pf=expit(xf@beta);yd=np.array([0,1,0,1,1,0,1]);ridge=.7
        ID=xd.T@((pd0*(1-pd0))[:,None]*xd);IF=xf.T@((pf*(1-pf))[:,None]*xf);H0=ID+ridge*np.eye(3);H=H0+IF;inv=np.linalg.inv(H);bD=xd.T@(yd-pd0)-ridge*beta;x=rng.normal(size=(4,3));G=x.T@x/4
        bias=float(bD@inv@G@inv@bD);variance=float(np.trace(G@inv@IF@inv));exact=0.
        for bits in itertools.product([0,1],repeat=5):
            y=np.array(bits);weight=np.prod(np.where(y,pf,1-pf));error=inv@(bD+xf.T@(y-pf));exact+=weight*float(error@G@error)
        self.assertAlmostEqual(exact,bias+variance,places=12)
        correction=np.trace(G@inv@(np.outer(bD,bD)-H0)@inv)
        self.assertAlmostEqual(exact,float(np.trace(G@inv)+correction),places=12)

    def test_targeted_four_endpoints_equal_registered_full_contrast(self):
        rng=np.random.default_rng(992003)
        for _ in range(20):
            R={(d,n,m):rng.random() for d in ['target','irrelevant','unlock'] for n in [500,4000] for m in ['OrdinaryOnly','MinRisk','D-only','Pending-aware']}
            I={d:(R[d,4000,'OrdinaryOnly']-R[d,4000,'D-only'])-(R[d,500,'OrdinaryOnly']-R[d,500,'D-only']) for d in ['target','irrelevant','unlock']}
            direct=(R['unlock',4000,'OrdinaryOnly']-R['unlock',4000,'D-only'])-(R['unlock',500,'OrdinaryOnly']-R['unlock',500,'D-only'])-(R['irrelevant',4000,'OrdinaryOnly']-R['irrelevant',4000,'D-only'])+(R['irrelevant',500,'OrdinaryOnly']-R['irrelevant',500,'D-only'])
            self.assertAlmostEqual(direct,I['unlock']-I['irrelevant'],places=14)

if __name__=='__main__':unittest.main(verbosity=2)
