from pathlib import Path
import sys, json
ROOT=Path('LOCAL_WORKSPACE/2026-10-31/zhe/work/LexiRiskLabel')
HERE=ROOT/'experiments/mechanism_v2'
TASK=Path('LOCAL_WORKSPACE/2026-10-31/ji-x')
sys.path.insert(0,str(HERE))
from run_paired_mechanism_states import sha,digest,write_json,write_jsonl,frozen,FeedbackService,generate,action_family,visible_hash
from evaluate_frozen_family import target,hidden_draw
from stage_gate import require_stage,validate_acceptance
from scipy.stats import t
import numpy as np

def verdict(low,high,delta=.0001):
    if low>delta:return 'supports_meaningful_registered_direction'
    if high<0:return 'opposite_direction'
    if low>=-delta and high<=delta:return 'approximately_equivalent_at_registered_margin'
    if high<delta:return 'meaningful_registered_positive_excluded'
    return 'unresolved'

def interval(values,alpha,family=1,looks=1):
    x=np.asarray(values);n=len(x);mean=float(x.mean());se=float(x.std(ddof=1)/np.sqrt(n));radius=float(t.ppf(1-alpha/(2*family*looks),n-1)*se)
    return {'n_worlds':n,'mean':mean,'world_SE':se,'simultaneous_low':mean-radius,'simultaneous_high':mean+radius,'verdict':verdict(mean-radius,mean+radius)}

def sources():
    paths=[HERE/x for x in ['run_paired_mechanism_states.py','evaluate_frozen_family.py','run_exact_geometry.py','mechanism_protocol.json','stage_gate.py','stage_governance.json']]
    paths += [ROOT/'experiments/protocol_next/runtime.py', ROOT/'experiments/research_v2/core.py']
    paths += list(Path(__file__).parent.glob('*.py'))+[Path(__file__).parent/'protocol.json']
    return {str(p):sha(p) for p in sorted(paths)}

def check_sources(mapping):
    assert all(sha(Path(p))==h for p,h in mapping.items()),'source drift'
