import sys
sys.path.insert(0, 'LOCAL_WORKSPACE/2026-10-31/zhe/work/LexiRiskLabel/experiments/mechanism_v2')
"""Stage-guarded complete M2 matrices, including the isospectral control."""
from pathlib import Path
from dataclasses import replace
import argparse,json,time,platform,subprocess,copy
import numpy as np
import pandas as pd
from scipy.special import expit
from xgboost import XGBClassifier
from stage_gate import require_stage,GOVERNANCE
from run_paired_mechanism_states import generate,action_family,visible_hash,FeedbackService,frozen,sha,digest,write_json,write_jsonl
from evaluate_frozen_family import target,hidden_draw

HERE=Path('LOCAL_WORKSPACE/2026-10-31/zhe/work/LexiRiskLabel/experiments/mechanism_v2');ROOT=HERE.parents[1]

def variant_config(base,variant):
    cfg=copy.deepcopy(base)
    if variant=='isospectral':cfg['truth_theta'][2]=0.
    elif variant!='original':raise ValueError(variant)
    return cfg

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--protocol',type=Path,required=True);ap.add_argument('--out',type=Path,required=True);a=ap.parse_args()
    policy=require_stage('M2');plan=json.loads(a.protocol.read_text());assert plan['stage']=='M2' and plan['no_later_stage_execution']
    out=a.out;out.mkdir(parents=True,exist_ok=False);private=out/'private';private.mkdir()
    base=json.loads((HERE/'mechanism_protocol.json').read_text())['pilot'];worlds=plan['world_ids']
    assert plan['cost_condition']=='neutral','M2 must use the literal neutral condition ID'
    assert set(plan['directions'])==set(base['directions']) and plan['ordinary_sizes']==base['ordinary_sizes']
    assert set(plan['variants'])=={'original','isospectral'}
    expected_states=len(worlds)*len(plan['variants'])*len(plan['directions'])*len(plan['ordinary_sizes'])
    assert plan['max_nominal_fit_slots']==expected_states*len(plan['methods'])*len(plan['learners'])*plan['label_replicates']
    paths=[Path(__file__),a.protocol,HERE/'stage_gate.py',GOVERNANCE,HERE/'mechanism_protocol.json',HERE/'run_paired_mechanism_states.py',HERE/'evaluate_frozen_family.py',HERE/'run_exact_geometry.py',ROOT/'experiments/protocol_next/runtime.py',ROOT/'experiments/research_v2/core.py']
    sources={str(p):sha(p) for p in paths}
    gpu=subprocess.run(['nvidia-smi','--query-gpu=name,driver_version','--format=csv,noheader'],capture_output=True,text=True);assert gpu.returncode==0
    import importlib.metadata
    reg={'plan':plan,'base_configuration':base,'stage':'M2','governance':policy,'sources':sources,'hardware':gpu.stdout.strip(),'environment':{'python':platform.python_version(),**{k:importlib.metadata.version(k) for k in ['numpy','pandas','scipy','scikit-learn','xgboost']}},'started_utc':pd.Timestamp.now(tz='UTC').isoformat()}
    write_json(out/'registration.json',reg);contexts=[];locks=[];manifests=[];audits=[];started=time.perf_counter()
    for world in worlds:
        for variant in plan['variants']:
            cfg=variant_config(base,variant);states=generate(world,cfg)[0];ev=target(world,plan['evaluation_rng_tag'],plan['evaluation_n'],cfg)
            np.savez_compressed(private/f'{variant}_w{world}_evaluation.npz',X=ev[0],p=ev[1],y=ev[2]);shared=None;fixed_do=None;spectrum_reference={};nesting={}
            for original_id,direction,on,assoc,s,_,_,cid,did,oid,_ in states:
                if assoc!=plan['cost_condition']:continue
                sid=f'{variant}_{original_id}';state_private=private/sid;state_private.mkdir()
                actions={k:v for k,v in action_family(s,cid).items() if k in plan['methods']};assert list(actions)==plan['methods']
                common={k:digest(v) for k,v in {'D':s.visible_x,'yD':s.visible_y,'C':s.candidate_x,'Q':s.reference_x,'cost':s.cost,'T':ev[0]}.items()}|{'B':s.budget}
                if shared is None:shared=common
                assert shared==common
                if fixed_do is None:fixed_do=actions['D-only']
                assert np.array_equal(fixed_do,actions['D-only'])
                if on==min(plan['ordinary_sizes']):nesting[direction]=s.ordinary_x.copy()
                else:assert np.array_equal(nesting[direction],s.ordinary_x[:len(nesting[direction])])
                ptrue=expit(s.ordinary_x@np.array(cfg['truth_theta']));wtrue=ptrue*(1-ptrue);true_info=s.ordinary_x.T@(wtrue[:,None]*s.ordinary_x);true_spec=np.linalg.eigvalsh(true_info)
                if variant=='isospectral':
                    if on not in spectrum_reference:spectrum_reference[on]=(true_spec,ptrue)
                    reference,pp=spectrum_reference[on];assert np.array_equal(pp,ptrue)
                    assert np.max(np.abs(reference-true_spec))/max(1.,true_spec.max())<1e-12
                h,g,u=frozen.geometry(s,True);hd,_,_=frozen.geometry(s,False);estimated_info=h-hd
                vh=visible_hash(s);full_y=np.zeros(int(cid.max())+1,int);full_y[did]=s.visible_y
                service=FeedbackService(did,oid,cid,s.visible_x,s.ordinary_x,s.candidate_x,full_y,state_private,sid+'_'+vh)
                for method,idx in actions.items():
                    key=service.lock(idx,method,world);assert s.cost[idx].sum()<=s.budget+1e-10
                    locks.append({'variant':variant,'world_id':world,'condition_id':sid,'direction':direction,'ordinary_n':on,'method':method,'selected_ids':cid[idx],'selected_indices':idx,'select_hash':digest(cid[idx]),'visible_hash':vh,'lock_key':key,
                        'count':len(idx),'cost':float(s.cost[idx].sum()),'budget':s.budget,'Kstar':frozen.kstar(s.cost,s.budget),'proxy_score':frozen.set_value(h,g,u,idx)})
                if on==min(plan['ordinary_sizes']):
                    empty=action_family(replace(s,ordinary_x=s.ordinary_x[:0]),cid);assert np.array_equal(empty['D-only'],empty['Pending-aware'])
                    zero=action_family(replace(s,budget=0.),cid);assert all(len(idx)==0 for idx in zero.values())
                    perm=np.random.default_rng(world+19001).permutation(len(cid));permuted=action_family(replace(s,candidate_x=s.candidate_x[perm],cost=s.cost[perm]),cid[perm])
                    for method in actions:assert np.array_equal(np.sort(cid[actions[method]]),np.sort(cid[perm][permuted[method]]))
                    selected=action_family(s,cid)['MinRisk'];token=service.lock(selected,'boundary',world);wrong=np.setdiff1d(np.arange(len(cid)),selected)[:1]
                    try:service.reveal(wrong,token)
                    except RuntimeError:pass
                    else:raise AssertionError('A lock revealed B')
                    changed=replace(service,_y=1-service._y);again=action_family(s,cid)
                    assert all(np.array_equal(actions[m],again[m]) for m in actions)
                    audits.append({'variant':variant,'world_id':world,'direction':direction,'emptyO':True,'zeroBudget':True,'stableID':True,'mismatch_rejected':True,'hidden_OC_labels_not_selection_arguments':True})
                manifests.append({'variant':variant,'world_id':world,'condition_id':sid,'direction':direction,'ordinary_n':on,'visible_hash':vh,'common_inputs':common,'O_hash':digest(s.ordinary_x),
                    'true_Fisher_trace':float(np.trace(true_info)),'true_Fisher_spectrum':true_spec,'estimated_Fisher_trace':float(np.trace(estimated_info)),'estimated_Fisher_spectrum':np.linalg.eigvalsh(estimated_info),
                    'true_ordinary_positive_probability':float(ptrue.mean()),'D_positive_fraction':float(s.visible_y.mean()),'ordinary_feature_min':s.ordinary_x.min(axis=0),'ordinary_feature_max':s.ordinary_x.max(axis=0)})
                np.savez_compressed(state_private/'state.npz',D=s.visible_x,yD=s.visible_y,O=s.ordinary_x,C=s.candidate_x,Q=s.reference_x,cost=s.cost,B=s.budget,candidate_ids=cid)
                contexts.append((variant,world,sid,direction,on,s,cid,service,actions,ev,cfg))
    assert len(contexts)==expected_states and len(locks)==expected_states*len(plan['methods'])
    write_jsonl(out/'selection_locks.jsonl',locks);write_jsonl(out/'state_manifest.jsonl',manifests);write_json(out/'boundary_audit.json',{'passed':True,'checks':audits,'true_isospectral_geometry_verified':True,'Donly_fixed_across_all_six_conditions':True,'nested_O':True,'common_D_C_Q_T_cost_B':True})
    lockhash=sha(out/'selection_locks.jsonl');write_json(out/'selection_commitment.json',{'sha256':lockhash,'sets':len(locks),'all_before_feedback_label_draws':True})
    rows=[];labelrows=[];counts={'LR':0,'XGB':0};hits=0;maxerror=0.
    for variant,world,sid,direction,on,s,cid,service,actions,ev,cfg in contexts:
        xref,pt,yt=ev;predictions=[];keys=[]
        for rep in range(plan['label_replicate_start'],plan['label_replicate_start']+plan['label_replicates']):
            yo,yc=hidden_draw(world,rep,s,cfg,plan['label_rng_tag']);y=service._y.copy();y[service.o_ids]=yo;y[cid]=yc;feedback=replace(service,_y=y);cache={}
            labelrows.append({'variant':variant,'world_id':world,'condition_id':sid,'direction':direction,'ordinary_n':on,'replicate':rep,'O_y_hash':digest(yo),'C_y_hash':digest(yc),'O_positive_fraction':float(yo.mean())})
            for method,idx in actions.items():
                token=service.lock(idx,method,world);train_ids,x,yy=feedback.reveal(idx,token)
                for learner in plan['learners']:
                    key=digest({'X':digest(x),'y':digest(yy),'learner':learner,'learning_seed':world+7000,'params':cfg['xgb'] if learner=='XGB' else cfg['lr_ridge'],'sources':sources});tick=time.perf_counter();hit=key in cache
                    if hit:pred,backend=cache[key];hits+=1
                    else:
                        if learner=='LR':model=frozen.fit_logistic(x,yy,cfg['lr_ridge']);pred=expit(xref@model);backend='cpu'
                        else:
                            model=XGBClassifier(**cfg['xgb'],random_state=world+7000,objective='binary:logistic',eval_metric='logloss');model.fit(x[:,1:].astype(np.float32),yy)
                            backend=json.loads(model.get_booster().save_config())['learner']['generic_param']['device'];assert backend.startswith('cuda')
                            pred=model.predict_proba(xref[:,1:].astype(np.float32))[:,1].astype(float)
                        counts[learner]+=1;cache[key]=(pred,backend)
                    predictions.append(pred);keys.append(f'{rep}_{learner}_{method}')
                    rows.append({'variant':variant,'world_id':world,'condition_id':sid,'direction':direction,'ordinary_n':on,'method':method,'learner':learner,'replicate':rep,'select_hash':digest(cid[idx]),'fit_key':key,'cache_hit':hit,'actual_backend':backend,
                        'excess_brier':float(np.square(pred-pt).mean()),'sampled_brier':float(np.square(pred-yt).mean()),'expected_brier':float(np.square(pred-pt).mean()+np.mean(pt*(1-pt))),
                        'count':len(idx),'cost':float(s.cost[idx].sum()),'budget':s.budget,'Kstar':frozen.kstar(s.cost,s.budget),'realized_exploration_loss':float(np.dot(yc[idx],s.cost[idx]/cfg['business_PD_candidate'])),
                        'ordinary_default_count':int(yo.sum()),'train_n':len(yy),'train_ids_hash':digest(train_ids),'learning_seed':world+7000,'fit_predict_seconds':time.perf_counter()-tick})
        p=private/sid/'predictions.npz';np.savez_compressed(p,prediction=np.array(predictions),keys=np.array(keys),p=pt,y=yt)
        with np.load(p) as saved:check=saved['prediction'];pp=saved['p'];kk=saved['keys']
        assert np.array_equal(kk,np.array(keys));maxerror=max(maxerror,float(np.max(np.abs(np.square(check-pp).mean(axis=1)-np.square(np.array(predictions)-pt).mean(axis=1)))))
        pd.DataFrame(rows[-len(predictions):]).to_csv(out/'fit_outcomes.csv',index=False,mode='a',header=not (out/'fit_outcomes.csv').exists());write_json(out/'progress.json',{'last_state':sid,'completed_states':len(rows)//(len(plan['methods'])*len(plan['learners'])*plan['label_replicates']),'total_states':len(contexts),'nominal_slots':len(rows),'actual_fits':counts,'seconds':time.perf_counter()-started,'current_stage':'M2','later_stages_blocked':True})
        print(sid,'slots',len(rows),'actual',counts,flush=True)
    write_jsonl(out/'label_world_manifest.jsonl',labelrows)
    assert len(rows)==plan['max_nominal_fit_slots'] and maxerror==0 and sha(out/'selection_locks.jsonl')==lockhash
    assert all(sha(Path(p))==h for p,h in sources.items())
    result={'completed':True,'stage':'M2','stage_acceptance':False,'role':plan['role'],'worlds':len(worlds),'variants':len(plan['variants']),'states':len(contexts),'nominal_fit_slots':len(rows),'actual_fits':counts,'cache_hits':hits,
        'additional_D_acquisition_LR_fits':len(worlds)*len(plan['variants']),'label_M':plan['label_replicates'],'saved_prediction_max_error':maxerror,'sources_unchanged':True,'selection_commitment_unchanged':True,'seconds':time.perf_counter()-started,'later_stages_started':False}
    write_json(out/'completion.json',result);print(json.dumps(result),flush=True)

if __name__=='__main__':main()
