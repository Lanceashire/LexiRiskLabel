"""Audit prospective conditional-feedback data and evaluate frozen risk bridges."""
from pathlib import Path
import sys,json,copy,math
sys.path.insert(0,str(Path(__file__).parent/'m2_closure'))
from common import *
import pandas as pd
from scipy.special import expit
from decompose_label_bias_variance import components

RUN=TASK/'work/M2_conditional_bridge_confirmation'

def process(child):
    reg=json.loads((child/'registration.json').read_text());plan=reg['plan'];base=reg['base_configuration'];complete=json.loads((child/'completion.json').read_text());assert complete['completed']
    for p,h in reg['sources'].items():assert sha(Path(p))==h
    assert sha(child/'selection_locks.jsonl')==json.loads((child/'selection_commitment.json').read_text())['sha256']
    locks=[json.loads(x) for x in (child/'selection_locks.jsonl').read_text().splitlines()];lookup={(x['condition_id'],x['method']):x for x in locks}
    states=[json.loads(x) for x in (child/'state_manifest.jsonl').read_text().splitlines()]
    label_index={(x['condition_id'],x['replicate']):x for x in map(json.loads,(child/'label_world_manifest.jsonl').read_text().splitlines())}
    frame=pd.read_csv(child/'fit_outcomes.csv');assert len(frame)==plan['max_nominal_fit_slots'];fits=frame.set_index(['condition_id','replicate','learner','method']);assert fits.index.is_unique
    for learner in ['LR','XGB']:assert int(((frame.learner==learner)&~frame.cache_hit).sum())==complete['actual_fits'][learner]
    assert set(frame.loc[frame.learner=='XGB','actual_backend'])=={'cuda:0'}
    anchors={};evaluations={};rows=[];approx=[];curves=[];maxrisk=0.;maxidentity=0.;maxproxy=0.
    for state in states:
        sid=state['condition_id'];world=state['world_id'];variant=state['variant'];direction=state['direction'];on=state['ordinary_n'];cfg=copy.deepcopy(base)
        if variant=='isospectral':cfg['truth_theta'][2]=0.
        theta=np.asarray(cfg['truth_theta']);key=(variant,world)
        with np.load(child/'private'/sid/'state.npz') as z:a={k:z[k] for k in z.files}
        if key not in anchors:anchors[key]=frozen.fit_logistic(a['D'],a['yD'],cfg['lr_ridge'])
        if key not in evaluations:
            with np.load(child/'private'/f'{variant}_w{world}_evaluation.npz') as z:evaluations[key]=tuple(z[k] for k in ['X','p','y'])
            reconstructed=target(world,plan['evaluation_rng_tag'],plan['evaluation_n'],cfg);assert all(np.array_equal(x,y) for x,y in zip(evaluations[key],reconstructed))
        X,p,y=evaluations[key]
        common={k:digest(v) for k,v in {'D':a['D'],'yD':a['yD'],'C':a['C'],'Q':a['Q'],'cost':a['cost'],'T':X}.items()}|{'B':float(a['B'])}
        assert state['common_inputs']==common and digest(a['O'])==state['O_hash']
        s=frozen.State(a['D'],a['yD'],a['O'],a['C'],a['Q'],a['cost'],float(a['B']),anchors[key],world,ridge=cfg['lr_ridge'],exchanges=0)
        h,g,u=frozen.geometry(s,True);selected=np.asarray(lookup[sid,'D-only']['selected_indices'],int)
        proxy=frozen.set_value(h,g,u,selected);maxproxy=max(maxproxy,abs(proxy-lookup[sid,'D-only']['proxy_score']));assert maxproxy<1e-10
        with np.load(child/'private'/sid/'predictions.npz') as z:pred=z['prediction'];keys=[str(v).split('_',2) for v in z['keys']];assert np.array_equal(z['p'],p) and np.array_equal(z['y'],y)
        for rep in range(plan['label_replicate_start'],plan['label_replicate_start']+plan['label_replicates']):
            yo,yc=hidden_draw(world,rep,s,cfg,plan['label_rng_tag']);record=label_index[sid,rep];assert digest(yo)==record['O_y_hash'] and digest(yc)==record['C_y_hash']
            for method in plan['methods']:
                idx=np.asarray(lookup[sid,method]['selected_indices'],int);cid=a['candidate_ids'];assert np.array_equal(cid[idx],lookup[sid,method]['selected_ids']) and a['cost'][idx].sum()<=float(a['B'])+1e-10
                ids=np.r_[np.arange(len(a['D'])),np.arange(len(a['D']),len(a['D'])+len(a['O'])),cid[idx]];xx=np.vstack([a['D'],a['O'],a['C'][idx]]);yy=np.r_[a['yD'],yo,yc[idx]];order=np.argsort(ids,kind='stable');ids,xx,yy=ids[order],xx[order],yy[order]
                for learner in plan['learners']:
                    row=fits.loc[sid,rep,learner,method];assert digest(ids)==row.train_ids_hash and digest(cid[idx])==row.select_hash
                    expected=digest({'X':digest(xx),'y':digest(yy),'learner':learner,'learning_seed':world+7000,'params':cfg['xgb'] if learner=='XGB' else cfg['lr_ridge'],'sources':reg['sources']});assert expected==row.fit_key
        for i,(rep,learner,method) in enumerate(keys):
            row=fits.loc[sid,int(rep),learner,method];excess=float(np.square(pred[i]-p).mean());sampled=float(np.square(pred[i]-y).mean());expected=excess+float(np.mean(p*(1-p)))
            maxrisk=max(maxrisk,abs(excess-row.excess_brier),abs(sampled-row.sampled_brier),abs(expected-row.expected_brier));assert maxrisk<1e-14
        for learner in plan['learners']:
            comp={}
            for method in plan['methods']:
                indices=[i for i,k in enumerate(keys) if k[1]==learner and k[2]==method];assert len(indices)==plan['label_replicates'];comp[method]=components(pred[indices],p)
            b=comp['OrdinaryOnly'];d=comp['D-only'];total=b['total_excess']-d['total_excess'];bias=b['conditional_squared_bias_unbiased']-d['conditional_squared_bias_unbiased'];variance=b['conditional_prediction_variance']-d['conditional_prediction_variance'];maxidentity=max(maxidentity,abs(total-bias-variance))
            rows.append({'variant':variant,'world_id':world,'direction':direction,'ordinary_n':on,'learner':learner,'total_gain':total,'bias_gain':bias,'variance_gain':variance})
        # Frozen local frequentist expansion, conditioning on actual D labels.
        def info(x):
            pp=expit(x@theta);return x.T@((pp*(1-pp))[:,None]*x)
        ID=info(a['D']);IO=info(a['O']);IS=info(a['C'][selected]);GT=X.T@((np.square(p*(1-p)))[:,None]*X)/len(X);ridge=cfg['lr_ridge'];H0=ID+ridge*np.eye(len(theta));bD=a['D'].T@(a['yD']-expit(a['D']@theta))-ridge*theta
        parts={};corrections={};ED=np.outer(bD,bD)-H0
        for method,extra in [('OrdinaryOnly',np.zeros_like(IS)),('D-only',IS)]:
            inv=np.linalg.inv(H0+IO+extra);bias=float(bD@inv@GT@inv@bD);var=float(np.trace(GT@inv@(IO+extra)@inv));parts[method]=(bias,var)
            corrections[method]=float(np.trace(GT@inv@ED@inv));assert abs(bias+var-float(np.trace(GT@inv))-corrections[method])<1e-12
        cb=parts['OrdinaryOnly'][0]-parts['D-only'][0];cv=parts['OrdinaryOnly'][1]-parts['D-only'][1]
        bayes=float(np.trace(GT@(np.linalg.inv(H0+IO)-np.linalg.inv(H0+IO+IS))))
        correction=corrections['OrdinaryOnly']-corrections['D-only'];assert abs(cb+cv-bayes-correction)<1e-12
        approx.append({'variant':variant,'world_id':world,'direction':direction,'ordinary_n':on,'estimated_Bayes_proxy':proxy,'true_Bayes_proxy':bayes,'local_conditional_bias_gain':cb,'local_conditional_variance_gain':cv,'local_conditional_total_gain':cb+cv,'D_anchor_correction_gain':correction})
        if on==500:
            for scale in [0,.03125,.0625,.125,.25,.5,1,2,4,8,16]:
                inv=np.linalg.inv(H0+scale*IO);after=np.linalg.inv(H0+scale*IO+IS);F=float(np.trace(GT@(inv-after)));derivative=float(np.trace(GT@(after@IO@after-inv@IO@inv)))
                curves.append({'variant':variant,'world_id':world,'direction':direction,'information_scale':scale,'true_Bayes_fixed_set_gain':F,'analytic_derivative':derivative})
    report={'passed':True,'path':str(child),'worlds':len(plan['world_ids']),'states':len(states),'prediction_rows_recomputed':len(frame),'label_M':plan['label_replicates'],'maximum_risk_error':maxrisk,'maximum_bias_variance_identity_error':maxidentity,'maximum_saved_proxy_error':maxproxy,'sources_training_labels_selections_verified':True}
    return pd.DataFrame(rows),pd.DataFrame(approx),pd.DataFrame(curves),report

def contrasts(frame,columns,learner=True):
    ids=['variant','world_id']+(['learner'] if learner else []);result=[]
    for key,q in frame.groupby(ids):
        key=key if isinstance(key,tuple) else (key,);base=dict(zip(ids,key));v=q.set_index(['direction','ordinary_n'])
        for name in columns:
            I={d:float(v.loc[(d,4000),name]-v.loc[(d,500),name]) for d in ['target','irrelevant','unlock']}
            for contrast,value in [('K_sub',I['irrelevant']-I['target']),('K_unlock',I['unlock']-I['irrelevant'])]:result.append(base|{'component':name,'contrast':contrast,'value':value})
    return pd.DataFrame(result)

def main():
    assert json.loads((RUN/'completion.json').read_text())['completed'];out=TASK/'work/M2_mechanism_bridge';out.mkdir(exist_ok=True)
    allrows=[];allapprox=[];allcurves=[];audits=[]
    for batch in json.loads((RUN/'batch_index.json').read_text()):
        rows,approx,curves,audit=process(Path(batch['path']));allrows.append(rows);allapprox.append(approx);allcurves.append(curves);audits.append(audit);write_json(out/'independent_diagnostic_audits.json',audits);print('diagnostic audited',len(audits),'of4',flush=True)
    gains=pd.concat(allrows,ignore_index=True);approx=pd.concat(allapprox,ignore_index=True);curves=pd.concat(allcurves,ignore_index=True)
    gains.to_csv(out/'independent_bias_variance_condition_gains.csv',index=False);approx.to_csv(out/'independent_local_risk_bridge_condition_gains.csv',index=False);curves.to_csv(out/'independent_information_scale_curves.csv',index=False)
    cc=contrasts(gains,['total_gain','bias_gain','variance_gain']);aa=contrasts(approx,[x for x in approx.columns if x.endswith('_gain') or x.endswith('_proxy')],False);cc.to_csv(out/'independent_component_world_contrasts.csv',index=False);aa.to_csv(out/'independent_analytic_world_contrasts.csv',index=False)
    summary=[]
    for key,q in cc.groupby(['variant','learner','contrast','component']):summary.append(dict(zip(['variant','learner','contrast','component'],key))|interval(q.value,.05,24,1))
    pd.DataFrame(summary).to_csv(out/'independent_component_summary.csv',index=False)
    aa.groupby(['variant','contrast','component'],as_index=False).value.mean().to_csv(out/'independent_analytic_summary.csv',index=False)
    pivot=cc.pivot(index=['variant','world_id','learner','contrast'],columns='component',values='value');assert np.max(np.abs(pivot.total_gain-pivot.bias_gain-pivot.variance_gain))<1e-12
    joined=cc[cc.component=='total_gain'].merge(aa,on=['variant','world_id','contrast'],suffixes=('_observed','_analytic'));joined['same_sign']=(joined.value_observed>0)==(joined.value_analytic>0)
    joined.groupby(['variant','learner','contrast','component_analytic'],as_index=False).agg(observed_mean=('value_observed','mean'),analytic_mean=('value_analytic','mean'),sign_agreement=('same_sign','mean')).to_csv(out/'independent_bridge_comparison.csv',index=False)
    curve_summary=curves.groupby(['variant','direction','information_scale'],as_index=False)[['true_Bayes_fixed_set_gain','analytic_derivative']].mean();curve_summary.to_csv(out/'information_scale_curve_means.csv',index=False)
    report={'passed':True,'worlds':64,'label_M':32,'new_states':sum(x['states'] for x in audits),'prediction_rows_recomputed':sum(x['prediction_rows_recomputed'] for x in audits),'maximum_risk_error':max(x['maximum_risk_error'] for x in audits),'maximum_bias_variance_identity_error':float(np.max(np.abs(pivot.total_gain-pivot.bias_gain-pivot.variance_gain))),'conditional_decomposition_not_causal_attribution':True,'local_model_scope':'first-order correctly specified logistic expansion; fixed D; no XGB approximation guarantee','retrospective_proxy_analysis_scope':'descriptive on old worlds, never independent confirmation','component_intervals':'24 descriptive component intervals, separate from primary alpha-budgeted mechanism family'}
    write_json(out/'diagnostic_completion.json',report);print(json.dumps(report),flush=True)
if __name__=='__main__':main()
