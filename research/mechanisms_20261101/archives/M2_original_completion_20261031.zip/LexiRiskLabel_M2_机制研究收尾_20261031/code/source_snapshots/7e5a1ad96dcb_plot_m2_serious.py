from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
BASE=Path(__file__).resolve().parent
D=BASE/'M2_mechanism_bridge'
OUT=D/'figures'
COLORS={'target':'#2166ac','irrelevant':'#777777','unlock':'#b2182b'}

def main():
    OUT.mkdir(exist_ok=True)
    plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False})
    primary=D/'M2_final_all_eight_mechanisms.csv'
    if primary.exists():
        f=pd.read_csv(primary);fig,axes=plt.subplots(1,2,figsize=(13,5.5))
        for ax,variant in zip(axes,['original','isospectral']):
            z=f[f.variant==variant].sort_values(['learner','contrast']);labels=[]
            for i,r in enumerate(z.itertuples()):
                ax.errorbar(r.mean,i,xerr=[[r.mean-r.simultaneous_low],[r.simultaneous_high-r.mean]],fmt='o',color='#2166ac' if r.learner=='LR' else '#b2182b',capsize=3)
                labels.append(f'{r.learner} {r.contrast} (n={int(r.n_worlds):,})')
            ax.axvline(0,color='gray',ls='--',lw=1,label='zero');ax.axvline(.0001,color='gray',ls=':',lw=1,label='margin = 0.0001');ax.set_yticks(range(len(z)),labels);ax.invert_yaxis();ax.set_title(variant);ax.set_xlabel('Excess Brier interaction');ax.grid(axis='x',alpha=.2);ax.legend(fontsize=8,loc='lower right')
        fig.suptitle('M2 primary evidence: original matrix and independent precision supplement\nHistorical simultaneous envelope + alpha-spending future-world envelope');fig.tight_layout();fig.savefig(OUT/'M2_primary_final.png',dpi=180);plt.close(fig)
    s=pd.read_csv(D/'independent_component_summary.csv');fig,axes=plt.subplots(2,2,figsize=(12,8))
    for row,variant in enumerate(['original','isospectral']):
        for col,learner in enumerate(['LR','XGB']):
            ax=axes[row,col];q=s[(s.variant==variant)&(s.learner==learner)]
            for k,(component,color,label) in enumerate([('bias_gain','#2166ac','conditional bias'),('variance_gain','#b2182b','feedback variance'),('total_gain','#444444','total')]):
                z=q[q.component==component].set_index('contrast').loc[['K_sub','K_unlock']];x=np.arange(2)+(k-1)*.23
                ax.bar(x,z['mean'],width=.22,color=color,label=label,alpha=.8);ax.errorbar(x,z['mean'],yerr=[z['mean']-z.simultaneous_low,z.simultaneous_high-z['mean']],fmt='none',ecolor=color,capsize=2)
            ax.axhline(0,color='gray',ls='--',lw=1);ax.set_xticks([0,1],['K_sub','K_unlock']);ax.set_title(f'{variant} / {learner}');ax.set_ylabel('Contribution to registered interaction');ax.grid(axis='y',alpha=.2)
    handles,labels=axes[0,0].get_legend_handles_labels();fig.legend(handles,labels,loc='lower center',ncol=3);fig.suptitle('Independent conditional bias/variance diagnosis: 64 worlds, 32 label draws\nUnbiased components; simultaneous descriptive intervals across 24 component means');fig.tight_layout(rect=[0,.05,1,1]);fig.savefig(OUT/'M2_conditional_bias_variance.png',dpi=180);plt.close(fig)
    a=pd.read_csv(D/'independent_analytic_summary.csv');actual=s[s.component=='total_gain'];fig,axes=plt.subplots(2,2,figsize=(12,8))
    methods=[('estimated_Bayes_proxy','estimated proxy'),('true_Bayes_proxy','true-param Bayes'),('local_conditional_total_gain','conditional local')]
    for row,variant in enumerate(['original','isospectral']):
        for col,contrast in enumerate(['K_sub','K_unlock']):
            ax=axes[row,col];q=a[(a.variant==variant)&(a.contrast==contrast)].set_index('component');values=[float(q.loc[k,'value']) for k,_ in methods];names=[v for _,v in methods]
            for learner in ['LR','XGB']:
                z=actual[(actual.variant==variant)&(actual.contrast==contrast)&(actual.learner==learner)];values.append(float(z['mean'].iloc[0]));names.append('actual '+learner)
            ax.bar(range(5),values,color=['#bdbdbd','#969696','#2166ac','#4393c3','#b2182b']);ax.axhline(0,color='gray',ls='--',lw=1);ax.set_xticks(range(5),names,rotation=25,ha='right');ax.set_title(f'{variant} / {contrast}');ax.set_ylabel('Mean interaction');ax.grid(axis='y',alpha=.2)
    fig.suptitle('Frozen risk bridges versus classifier outcomes on the same 64 new worlds\nDescriptive means; local logistic expansion is not an XGB theorem');fig.tight_layout();fig.savefig(OUT/'M2_risk_object_bridge.png',dpi=180);plt.close(fig)
    f=pd.read_csv(D/'information_scale_curve_means.csv');fig,axes=plt.subplots(1,2,figsize=(12,4.8))
    for ax,variant in zip(axes,['original','isospectral']):
        for direction in ['target','irrelevant','unlock']:
            q=f[(f.variant==variant)&(f.direction==direction)].sort_values('information_scale');ax.plot(q.information_scale,q.true_Bayes_fixed_set_gain,'o-',color=COLORS[direction],label=direction,markersize=3)
        ax.set_xscale('symlog',linthresh=.125);ax.axvline(1,color='gray',ls=':',lw=1);ax.axvline(8,color='gray',ls=':',lw=1);ax.set_title(variant);ax.set_xlabel('Multiplier of fixed O500 information matrix');ax.set_ylabel('True-parameter Bayes proxy gain');ax.legend();ax.grid(alpha=.2)
    fig.suptitle('Actual selected sets under controlled information strength\nMatrix intervention only; this curve is not a fitted classifier response curve');fig.tight_layout();fig.savefig(OUT/'M2_information_geometry_curve.png',dpi=180);plt.close(fig)
    weak=D/'five_count_gain_curve_summary.csv'
    if weak.exists():
        f=pd.read_csv(weak);fig,axes=plt.subplots(2,2,figsize=(12,8))
        for row,variant in enumerate(['original','isospectral']):
            for col,learner in enumerate(['LR','XGB']):
                ax=axes[row,col]
                for direction in ['target','irrelevant','unlock']:
                    q=f[(f.variant==variant)&(f.learner==learner)&(f.direction==direction)].sort_values('ordinary_n');ax.plot(q.ordinary_n,q['mean'],'o-',color=COLORS[direction],label=direction,markersize=4);ax.fill_between(q.ordinary_n,q.simultaneous_low,q.simultaneous_high,color=COLORS[direction],alpha=.1)
                ax.axhline(0,color='gray',ls='--',lw=1);ax.set_xscale('symlog',linthresh=32);ax.set_xticks([0,32,128,500,4000],['0','32','128','500','4000']);ax.set_title(f'{variant} / {learner}');ax.set_xlabel('Ordinary feedback count');ax.set_ylabel('R(OrdinaryOnly) - R(D-only)');ax.grid(alpha=.2);ax.legend(fontsize=8)
        fig.suptitle('Independent five-count classifier response: same 64 worlds and 16 paired label draws\nDescriptive simultaneous bands over all 60 curve points; original primary tests unchanged');fig.tight_layout();fig.savefig(OUT/'M2_independent_feedback_response.png',dpi=180);plt.close(fig)
    print('Figures generated:',len(list(OUT.glob('*.png'))))
if __name__=='__main__':main()
