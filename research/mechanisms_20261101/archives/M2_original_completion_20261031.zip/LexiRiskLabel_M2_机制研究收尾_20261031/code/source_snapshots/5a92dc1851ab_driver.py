"""Conservative precision continuation on the same future-world estimand."""
from pathlib import Path
import sys,json,time,subprocess,concurrent.futures
sys.path.insert(0,str(Path(__file__).parent.parent/'m2_closure'))
from common import *
from driver import audit
import pandas as pd

def main():
    require_stage('M2');home=Path(__file__).parent;plan=json.loads((home/'protocol.json').read_text());out=TASK/'work/M2_precision_continuation_20261031';out.mkdir(exist_ok=True)
    src=sources()|{str(p):sha(p) for p in [Path(__file__),home/'target_batch.py',home/'protocol.json']}
    write_json(out/'registration.json',{'plan':plan,'sources':src,'registered_utc':pd.Timestamp.now(tz='UTC').isoformat(),'old_two_look_data_unmodified':True})
    old=TASK/'work/M2_independent_closure_20261031'
    while not (old/'execution_complete.json').exists():
        status=subprocess.run(['systemctl','--user','is-active','lexirisk-m2-close-20261031.service'],capture_output=True,text=True)
        if status.returncode:raise RuntimeError('original supplement failed before completion')
        time.sleep(10)
    check_sources(src)
    frames=[pd.read_csv(old/f'batch_{end:05d}/world_contrasts.csv') for end in range(128,32769,128)];audits=[];closed=False;last=32768
    def assess(n):
        frame=pd.concat(frames,ignore_index=True);assert len(frame)==n and sorted(frame.world_id)==list(range(100001,100001+n))
        k=plan['look_world_counts'].index(n);alpha=.025/(2**(k+1));r={'variant':'isospectral','learner':'XGB','contrast':'K_unlock',**interval(frame.value,alpha,1,1),'alpha_for_this_interval':alpha,'look_index':k,'source':'unified conservative precision envelope'}
        look=out/f'look_{n:06d}';look.mkdir(exist_ok=True);frame.to_csv(look/'world_contrasts.csv',index=False);write_json(look/'result.json',r);write_json(out/'latest_result.json',r);print('PRECISION LOOK',json.dumps(r),flush=True);return r['verdict']!='unresolved'
    closed=assess(32768)
    if not closed:
        def run(end):
            child=out/f'batch_{end:06d}'
            if not (child/'completion.json').exists():
                if child.exists():child.rename(out/f'incomplete_{end:06d}_{time.time_ns()}')
                with (out/f'batch_{end:06d}.log').open('w') as log:
                    result=subprocess.run([sys.executable,str(home/'target_batch.py'),'--start',str(100001+end-128),'--count','128','--out',str(child)],stdout=log,stderr=subprocess.STDOUT)
                if result.returncode:raise RuntimeError(f'precision batch {end} failed')
            return audit(child)
        with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
            futures={end:pool.submit(run,end) for end in range(32896,131073,128)}
            for end,f in futures.items():
                data,check=f.result();frames.append(data);audits.append(check);write_json(out/'progress.json',{'completed_and_audited_worlds':end,'next_registered_look':131072,'new_CUDA_fits':(end-32768)*8,'later_stages_started':False});write_json(out/'batch_audits.json',audits);print('precision audited',end,flush=True)
        last=131072;closed=assess(last)
    check_sources(src);write_json(out/'execution_complete.json',{'completed_worlds':last,'statistical_closure':closed,'M2_complete':False,'sources_unchanged':True,'new_CUDA_fits':(last-32768)*8,'later_stages_started':False,'status':'target terminal under unified envelope' if closed else 'further precision work required; do not advance'})
if __name__=='__main__':main()
