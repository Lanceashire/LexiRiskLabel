"""Supplement-specific M2 acceptance; original preregistration is never edited."""
from pathlib import Path
import sys,json
sys.path.insert(0,str(Path(__file__).parent/'m2_closure'))
from common import *
import pandas as pd
from scipy.stats import t
TASK=Path(__file__).resolve().parent.parent
NEW=TASK/'work/M2_independent_closure_20261031'
PRECISION=TASK/'work/M2_precision_continuation_20261031'
DIAG=TASK/'work/M2_mechanism_bridge'
TARGET=('isospectral','XGB','K_unlock')
EXPECTED={(v,l,k) for v in ['original','isospectral'] for l in ['LR','XGB'] for k in ['K_sub','K_unlock']}
TERMINAL={'supports_meaningful_registered_direction','opposite_direction','approximately_equivalent_at_registered_margin','meaningful_registered_positive_excluded'}

def validate_payload(e):
    if e.get('stage')!='M2':raise RuntimeError('wrong stage')
    cells=e.get('mandatory_mechanisms',[])
    if len(cells)!=8 or {(r['variant'],r['learner'],r['contrast']) for r in cells}!=EXPECTED:raise RuntimeError('all eight original cells required')
    if any(r['verdict'] not in TERMINAL for r in cells):raise RuntimeError('unresolved mechanism remains')
    if e.get('delta')!=.0001 or e.get('historical_alpha')!=.025 or e.get('supplemental_alpha')!=.025:raise RuntimeError('unregistered margin or error budget')
    for r in cells:
        if (r['variant'],r['learner'],r['contrast'])==TARGET:
            if r['n_worlds'] not in [8192,32768,131072] or r.get('evidence_source')!='fresh_independent_supplement':raise RuntimeError('target needs registered independent confirmation')
            k=[8192,32768,131072].index(r['n_worlds'])
            if r.get('look_index')!=k or r.get('alpha_this_interval')!=.025/(2**(k+1)):raise RuntimeError('target interval bypasses unified alpha spending')
        elif r['n_worlds']!=4096 or r.get('evidence_source')!='historical_conservative_simultaneous_envelope':raise RuntimeError('historical matrix cannot be replaced')
        if r['verdict']!=verdict(r['simultaneous_low'],r['simultaneous_high']):raise RuntimeError('verdict inconsistent with interval')
    for key in ['original_full_matrix_audited','new_primary_independently_audited','new_diagnostics_independently_audited','weak_feedback_boundary_independently_audited','prospective_diagnostic_formulas_frozen','mechanism_boundary_analysis_complete']:
        if e.get(key) is not True:raise RuntimeError('missing evidence: '+key)
    validate_acceptance('M2',e)
    return True

def main():
    policy=require_stage('M2');reg=json.loads((NEW/'registration.json').read_text());plan=reg['plan'];check_sources(reg['sources']);completed=json.loads((PRECISION/'execution_complete.json').read_text());n=completed['completed_worlds']
    precision_reg=json.loads((PRECISION/'registration.json').read_text());precision_plan=precision_reg['plan'];check_sources(precision_reg['sources'])
    assert completed['sources_unchanged'] and n in precision_plan['look_world_counts']
    history_run=Path(plan['historical_run']);old_state=json.loads((history_run/'latest_stage_status.json').read_text());old_audit=json.loads((TASK/'work/M2_saved_states_audit_final.json').read_text());assert len(old_audit['batches'])==64 and sum(x['saved_states_recomputed'] for x in old_audit['batches'])==49152
    for key,value in old_state['items'].items():
        if key not in ['original_K_sub_and_K_unlock_all_learner_verdicts_with_valid_multiplicity','isospectral_control_full_matrix_and_mechanism_verdicts']:assert value is True
    historical=pd.read_csv(history_run/'look_4096/world_interactions.csv');cells=[]
    for key,q in historical.groupby(['variant','learner','contrast']):
        if key==TARGET:continue
        r=dict(zip(['variant','learner','contrast'],key));r.update(interval(q.value,.025,8,4));r['evidence_source']='historical_conservative_simultaneous_envelope';cells.append(r)
    audits=json.loads((NEW/'batch_audits.json').read_text())
    if n>32768:audits+=json.loads((PRECISION/'batch_audits.json').read_text())
    assert len(audits)==n//plan['batch_worlds'] and all(r['passed'] for r in audits)
    frames=[]
    for end in range(plan['batch_worlds'],n+1,plan['batch_worlds']):
        child=NEW/f'batch_{end:05d}' if end<=32768 else PRECISION/f'batch_{end:06d}';a=json.loads((child/'independent_audit.json').read_text());assert a['passed'] and a['worlds']==plan['batch_worlds'] and a['maximum_risk_error']<1e-14
        frames.append(pd.read_csv(child/'fit_outcomes.csv'))
    frame=pd.concat(frames,ignore_index=True);assert len(frame)==n*8 and sorted(frame.world_id.unique())==list(range(plan['first_world_id'],plan['first_world_id']+n))
    pivot=frame.pivot(index='world_id',columns=['direction','ordinary_n','method'],values='excess_brier');I={d:(pivot[d,4000,'OrdinaryOnly']-pivot[d,4000,'D-only'])-(pivot[d,500,'OrdinaryOnly']-pivot[d,500,'D-only']) for d in plan['directions']};values=I['unlock']-I['irrelevant']
    # Independent direct t calculation from fit ledgers, not driver summaries.
    look_index=precision_plan['look_world_counts'].index(n);alpha_this=.025/(2**(look_index+1))
    mean=float(values.mean());se=float(values.std(ddof=1)/np.sqrt(n));radius=float(t.ppf(1-alpha_this/2,n-1)*se);new_result={'variant':'isospectral','learner':'XGB','contrast':'K_unlock','n_worlds':n,'mean':mean,'world_SE':se,'simultaneous_low':mean-radius,'simultaneous_high':mean+radius,'verdict':verdict(mean-radius,mean+radius),'evidence_source':'fresh_independent_supplement','look_index':look_index,'alpha_this_interval':alpha_this}
    saved=json.loads((PRECISION/f'look_{n:06d}/result.json').read_text());assert max(abs(saved[k]-new_result[k]) for k in ['mean','world_SE','simultaneous_low','simultaneous_high'])<1e-14 and saved['verdict']==new_result['verdict'];cells.append(new_result)
    assert json.loads((NEW/'look_08192/result.json').read_text())['verdict']=='unresolved'
    if n>32768:assert json.loads((PRECISION/'look_032768/result.json').read_text())['verdict']=='unresolved'
    diag=json.loads((DIAG/'diagnostic_completion.json').read_text());assert diag['passed'] and diag['worlds']==64 and diag['label_M']==32 and diag['new_states']==768 and diag['prediction_rows_recomputed']==98304
    assert diag['maximum_risk_error']<1e-14 and diag['maximum_bias_variance_identity_error']<1e-12
    weak=json.loads((DIAG/'weak_diagnostic_completion.json').read_text());assert weak['passed'] and weak['shared_independent_worlds']==64 and weak['weak_states']==1152 and weak['weak_prediction_rows_recomputed']==73728 and weak['maximum_risk_error']<1e-14 and weak['all_paired_prefixes_and_selections_verified']
    frozen_analysis=json.loads((DIAG/'analysis_registration.json').read_text());assert all(sha(Path(p))==h for p,h in frozen_analysis['source_sha256'].items())
    boundary=json.loads((DIAG/'boundary_analysis_completion.json').read_text());assert boundary['completed'] and boundary['all_registered_diagnostics_reported']
    items={key:True for key in policy['M2_acceptance_items']}
    evidence={'stage':'M2','acceptance_version':'original_full_matrix_plus_precision_envelope_and_independent_diagnostics_20261031','delta':.0001,'historical_alpha':.025,'supplemental_alpha':.025,'precision_alpha_rule':'.025/2^(look_index+1), N=8192*4^look_index','mandatory_mechanisms':cells,'items':items,'original_full_matrix_audited':True,'new_primary_independently_audited':True,'new_diagnostics_independently_audited':True,'weak_feedback_boundary_independently_audited':True,'prospective_diagnostic_formulas_frozen':True,'mechanism_boundary_analysis_complete':True,'original_confirmation_status_unchanged':True,'M2_complete':False,'later_stages_started':False,'later_stages_allowed':False,'sources':{'supplement_protocol':sha(Path(__file__).parent/'m2_closure/protocol.json'),'precision_protocol':sha(Path(__file__).parent/'m2_precision_extension/protocol.json'),'acceptance_code':sha(Path(__file__))}}
    try:validate_payload(evidence)
    except RuntimeError as error:evidence['gate_message']=str(error)
    else:evidence['M2_complete']=True;evidence['gate_message']='All eight mechanisms resolved with provenance-bound joint error accounting; full original and new diagnostic evidence audited. No later stage started.'
    write_json(DIAG/'M2_FINAL_ACCEPTANCE.json',evidence);pd.DataFrame(cells).to_csv(DIAG/'M2_final_all_eight_mechanisms.csv',index=False);print(json.dumps(evidence,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
