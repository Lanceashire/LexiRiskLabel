"""Two-look independent M2 completion experiment, never M3."""
from common import *
import concurrent.futures,subprocess,time,sys
import pandas as pd
from types import SimpleNamespace

def audit(child):
    reg=json.loads((child/'registration.json').read_text());plan=reg['plan'];check_sources(reg['sources'])
    comp=json.loads((child/'completion.json').read_text());assert comp['completed'] and comp['actual_CUDA_fits']==8*comp['worlds']
    assert sha(child/'selection_locks.jsonl')==json.loads((child/'selection_commitment.json').read_text())['sha256']
    f=pd.read_csv(child/'fit_outcomes.csv').set_index(['world_id','direction','ordinary_n','method']);assert len(f)==8*comp['worlds'] and set(f.actual_backend)=={'cuda:0'}
    locks=[json.loads(x) for x in (child/'selection_locks.jsonl').read_text().splitlines()]
    lookup={(x['world_id'],x['direction'],x['ordinary_n'],x['method']):x for x in locks}
    maxerror=0.;data=[];cfg=reg['configuration']
    for world in reg['world_ids']:
        with np.load(child/'private'/f'w{world}.npz') as z:
            a={k:z[k] for k in z.files}
        ev=target(world,plan['evaluation_rng_tag'],plan['evaluation_n'],cfg)
        assert all(np.array_equal(a[k],v) for k,v in zip(['X_eval','p','y'],ev))
        risk={};idx=a['selected_indices'];cid=a['candidate_ids'];assert a['cost'][idx].sum()<=float(a['B'])+1e-10
        for i,name in enumerate(a['keys']):
            direction,on,method=str(name).split('_',2);on=int(on);row=f.loc[world,direction,on,method];lock=lookup[world,direction,on,method]
            O=a[f'O_{direction}_{on}'];s=SimpleNamespace(ordinary_x=O,candidate_x=a['C']);yo,yc=hidden_draw(world,plan['label_replicate'],s,cfg,plan['label_rng_tag'])
            assert np.array_equal(yo,a[f'yo_{direction}_{on}']) and np.array_equal(yc,a['yc'])
            assert np.array_equal(a[f'O_{direction}_500'],a[f'O_{direction}_4000'][:500])
            selected=np.empty(0,int) if method=='OrdinaryOnly' else idx
            assert digest(cid[selected])==row.select_hash==lock['select_hash']
            ids=np.r_[np.arange(len(a['D'])),np.arange(len(a['D']),len(a['D'])+on),cid[selected]];x=np.vstack([a['D'],O,a['C'][selected]]);y=np.r_[a['yD'],yo,yc[selected]];order=np.argsort(ids,kind='stable');ids,x,y=ids[order],x[order],y[order]
            assert digest(ids)==row.train_ids_hash and len(ids)==row.train_n
            fitkey=digest({'X':digest(x),'y':digest(y),'learning_seed':world+7000,'params':cfg['xgb'],'sources':reg['sources']});assert fitkey==row.fit_key
            pred=a['prediction'][i];r=float(np.square(pred-a['p']).mean());risk[direction,on,method]=r
            errors=[abs(r-row.excess_brier),abs(float(np.square(pred-a['y']).mean())-row.sampled_brier),abs(r+float(np.mean(a['p']*(1-a['p'])))-row.expected_brier)];maxerror=max(maxerror,*errors);assert max(errors)<1e-14
        I={d:(risk[d,4000,'OrdinaryOnly']-risk[d,4000,'D-only'])-(risk[d,500,'OrdinaryOnly']-risk[d,500,'D-only']) for d in plan['directions']}
        data.append({'world_id':world,'value':I['unlock']-I['irrelevant'],'I_irrelevant':I['irrelevant'],'I_unlock':I['unlock']})
    expected=pd.read_csv(child/'world_contrasts.csv');recomputed=pd.DataFrame(data);assert np.allclose(expected.value,recomputed.value,rtol=0,atol=1e-14)
    report={'passed':True,'worlds':len(data),'rows':len(f),'maximum_risk_error':maxerror,'sources_labels_training_and_prediction_bindings_verified':True,'file_hashes':{p.name:sha(p) for p in child.iterdir() if p.is_file() and p.name!='independent_audit.json'}}
    write_json(child/'independent_audit.json',report);return recomputed,report

def main():
    require_stage('M2');home=Path(__file__).parent;plan=json.loads((home/'protocol.json').read_text());out=TASK/'work/M2_independent_closure_20261031';out.mkdir(exist_ok=True);src=sources()
    if (out/'registration.json').exists():assert json.loads((out/'registration.json').read_text())['sources']==src
    else:write_json(out/'registration.json',{'plan':plan,'sources':src,'started_utc':pd.Timestamp.now(tz='UTC').isoformat(),'role':'new prospective supplement; original confirmation unchanged'})
    original=pd.read_csv(Path(plan['historical_run'])/'look_4096/world_interactions.csv')
    historic=[]
    for (variant,learner,contrast),q in original.groupby(['variant','learner','contrast']):historic.append({'variant':variant,'learner':learner,'contrast':contrast,**interval(q.value,.025,8,4)})
    history=pd.DataFrame(historic);history.to_csv(out/'historical_conservative_reanalysis.csv',index=False)
    target_key=('isospectral','XGB','K_unlock');assert all(r.verdict!='unresolved' for r in history.itertuples() if (r.variant,r.learner,r.contrast)!=target_key)
    accumulated=[];audits=[];last=0;started=time.perf_counter()
    def run(end):
        child=out/f'batch_{end:05d}'
        if not (child/'completion.json').exists():
            if child.exists():
                retained=out/f'incomplete_{end:05d}_{time.time_ns()}';child.rename(retained)
            with (out/f'batch_{end:05d}.log').open('w') as log:
                proc=subprocess.run([sys.executable,str(home/'target_batch.py'),'--start',str(plan['first_world_id']+end-plan['batch_worlds']),'--count',str(plan['batch_worlds']),'--out',str(child)],stdout=log,stderr=subprocess.STDOUT)
            if proc.returncode:raise RuntimeError(f'batch {end} failed: {proc.returncode}')
        return audit(child)
    for look_n in plan['look_world_counts']:
        with concurrent.futures.ThreadPoolExecutor(max_workers=plan['workers']) as pool:
            futures={end:pool.submit(run,end) for end in range(last+plan['batch_worlds'],look_n+1,plan['batch_worlds'])}
            for end,future in futures.items():
                values,check=future.result();accumulated.append(values);audits.append(check)
                write_json(out/'progress.json',{'completed_and_audited_worlds':end,'next_registered_look':look_n,'maximum_worlds':plan['maximum_worlds'],'actual_CUDA_fits':end*8,'seconds':time.perf_counter()-started,'later_stages_started':False});print('audited',end,flush=True)
        last=look_n;frame=pd.concat(accumulated,ignore_index=True);assert len(frame)==look_n and frame.world_id.nunique()==look_n
        result={'variant':'isospectral','learner':'XGB','contrast':'K_unlock',**interval(frame.value,.025,1,len(plan['look_world_counts'])),'evidence_source':'new_independent_supplement'}
        look=out/f'look_{look_n:05d}';look.mkdir(exist_ok=True);frame.to_csv(look/'world_contrasts.csv',index=False);write_json(look/'result.json',result);write_json(out/'batch_audits.json',audits)
        combined=history.copy();mask=(combined.variant=='isospectral')&(combined.learner=='XGB')&(combined.contrast=='K_unlock')
        for k,v in result.items():
            if k in combined.columns:combined.loc[mask,k]=v
        combined.to_csv(look/'all_eight_mechanisms.csv',index=False);closed=bool(combined.verdict.ne('unresolved').all());write_json(out/'statistical_closure.json',{'all_eight_mechanisms_terminal':closed,'target_result':result,'historical_alpha':.025,'supplemental_alpha':.025,'original_M2_status_unchanged':True,'M2_complete':False,'reason':'mechanism diagnostics, all batch audits and full final acceptance still required'})
        print('REGISTERED LOOK',json.dumps(result),flush=True)
        if closed:break
    check_sources(src);write_json(out/'execution_complete.json',{'completed_worlds':last,'statistical_closure':closed,'M2_complete':False,'sources_unchanged':True,'later_stages_started':False,'seconds':time.perf_counter()-started})

if __name__=='__main__':main()
