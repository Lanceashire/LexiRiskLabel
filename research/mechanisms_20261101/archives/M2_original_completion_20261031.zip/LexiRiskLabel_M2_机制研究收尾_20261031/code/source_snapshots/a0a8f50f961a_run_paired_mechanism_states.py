"""Frozen paired M2/M3 variance pilot. XGB must actually fit on CUDA.

Acquisition arguments are only State and stable candidate IDs. Synthetic truth,
hidden labels and target test features exist solely in feedback/evaluation code.
"""
from pathlib import Path
from dataclasses import replace
import argparse, hashlib, json, platform, sys, time, subprocess
import numpy as np
import pandas as pd
from scipy.special import expit
from xgboost import XGBClassifier
import sklearn,xgboost,scipy

HERE=Path(__file__).resolve().parent; ROOT=HERE.parents[1]
sys.path.insert(0,str(ROOT/'experiments/protocol_next'))
from runtime import FeedbackService, digest, write_json, write_jsonl, sha, frozen
from run_exact_geometry import greedy

def action_family(s,stable_ids):
    """No feedback service, hidden labels, truth, or T accepted by this API."""
    order=np.lexsort((stable_ids,s.cost));k=frozen.kstar(s.cost,s.budget)
    out={'OrdinaryOnly':np.empty(0,int),'MinRisk':np.sort(order[:k])}
    for conditional,name in [(False,'D-only'),(True,'Pending-aware')]:
        h,g,u=frozen.geometry(s,conditional)
        out[name]=np.sort(greedy(h,g,u,s.cost,s.budget,stable_ids))
    return out

def generate(world,cfg):
    def rng(tag):return np.random.default_rng(np.random.SeedSequence([world,tag]))
    nd,no,nc=cfg['D'],max(cfg['ordinary_sizes']),cfg['C'];rad=cfg['direction_radius_sd']
    d=np.ones((nd,5));d[:,1]=rng(1).uniform(-2,.8,nd);d[:,2]=rng(2).normal(0,.12,nd)
    d[:,3]=d[:,2]+rng(3).normal(0,.05,nd);d[:,4]=rng(4).normal(size=nd)
    c=np.ones((nc,5));c[:,1]=cfg['candidate_a'];c[:,2]=rng(5).normal(0,rad,nc);c[:,3:]=rng(6).normal(size=(nc,2))
    def target(n,tag):
        x=np.zeros((n,5));x[:,0]=1;x[:,1]=rng(tag).uniform(-2,2.2,n);x[:,2]=rng(tag+1).normal(0,rad,n);return x
    q=target(cfg['Q_ref'],10);test=target(cfg['T'],20);truth=np.array(cfg['truth_theta'])
    yd=(rng(30).random(nd)<expit(d@truth)).astype(int);yc=(rng(31).random(nc)<expit(c@truth)).astype(int)
    pt=expit(test@truth);yt=(rng(32).random(len(test))<pt).astype(int)
    a=rng(40).uniform(-2,.8,no);r=rng(41).normal(0,rad,no);uniform=rng(42).random(no)
    exposure=rng(50).uniform(*cfg['EAD_uniform'],nc);prices=cfg['business_PD_candidate']*exposure
    neutral=rng(51).permutation(prices);rank=np.argsort(np.abs(c[:,2]),kind='stable');sorted_cost=np.sort(prices)
    cheap=np.empty(nc);cheap[rank]=sorted_cost[::-1];expensive=np.empty(nc);expensive[rank]=sorted_cost
    costs={'neutral':neutral,'information_cheap':cheap,'information_expensive':expensive}
    for cost in costs.values():assert np.array_equal(np.sort(cost),np.sort(prices))
    b=cfg['rho']*prices.sum();theta=frozen.fit_logistic(d,yd,cfg['lr_ridge'])
    assert np.all(expit(-1+d[:,1])<=cfg['approval_threshold'])
    assert np.all(expit(-1+c[:,1])>cfg['approval_threshold'])
    states=[];cid=np.arange(nd+no,nd+no+nc)
    for name,axis in cfg['directions'].items():
        oo=np.c_[np.ones(no),a,r[:,None]*np.array(axis)]
        yo=(uniform<expit(oo@truth)).astype(int)
        assert np.all(expit(-1+oo[:,1])<=cfg['approval_threshold'])
        for on in cfg['ordinary_sizes']:
            associations=['neutral']
            if name==cfg['M3_condition']['direction'] and on==cfg['M3_condition']['ordinary_n']:
                associations+=['information_cheap','information_expensive']
            for assoc in associations:
                s=frozen.State(d,yd,oo[:on],c,q,costs[assoc],b,theta,world,ridge=cfg['lr_ridge'],exchanges=0)
                state_id=f'w{world}_{name}_O{on}_{assoc}'
                did=np.arange(nd);oid=np.arange(nd,nd+on);y=np.r_[yd,yo,yc]
                states.append((state_id,name,on,assoc,s,yo[:on],yc,cid,did,oid,y))
    return states,test,yt,pt,exposure

def visible_hash(s):
    return digest({k:digest(v) for k,v in {'D':s.visible_x,'yD':s.visible_y,'O':s.ordinary_x,'C':s.candidate_x,'Q_ref':s.reference_x,'cost':s.cost,'theta':s.theta}.items()}|{'B':s.budget,'ridge':s.ridge})

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--out',type=Path,required=True);a=ap.parse_args()
    out=a.out;out.mkdir(parents=True,exist_ok=False);private=out/'private';private.mkdir()
    cfg=json.loads((HERE/'mechanism_protocol.json').read_text())['pilot']
    sources={str(p.relative_to(ROOT)):sha(p) for p in [Path(__file__),HERE/'run_exact_geometry.py',HERE/'mechanism_protocol.json',ROOT/'experiments/protocol_next/runtime.py',ROOT/'experiments/research_v2/core.py']}
    gpu=subprocess.run(['nvidia-smi','--query-gpu=name,driver_version,memory.total','--format=csv,noheader'],capture_output=True,text=True)
    assert gpu.returncode==0,gpu.stderr
    registration={'config':cfg,'sources':sources,'started_utc':pd.Timestamp.now(tz='UTC').isoformat(),'hardware':gpu.stdout.strip(),
                  'environment':{'python':platform.python_version(),'numpy':np.__version__,'scipy':scipy.__version__,'sklearn':sklearn.__version__,'xgboost':xgboost.__version__},
                  'confirmation':False,'nominal_outcome_fit_slots':cfg['nominal_fit_slots'],'additional_acquisition_LR_fits':len(cfg['world_ids'])}
    write_json(out/'registration.json',registration);started=time.perf_counter();all_states=[];state_rows=[];locks=[];audits=[]
    # Persist every world and all method actions before any outcome fitting.
    for world in cfg['world_ids']:
        generated,test,yt,pt,exposure=generate(world,cfg)
        world_private=private/str(world);world_private.mkdir()
        np.savez_compressed(world_private/'evaluation.npz',T=test,yT=yt,pT=pt)
        fixed_D_action=None;shared=None
        for state_id,direction,on,assoc,s,yo,yc,cid,did,oid,y in generated:
            vhash=visible_hash(s);service=FeedbackService(did,oid,cid,s.visible_x,s.ordinary_x,s.candidate_x,y,world_private,state_id+'_'+vhash)
            tick=time.perf_counter();actions=action_family(s,cid);selection_seconds=time.perf_counter()-tick
            common={k:digest(v) for k,v in {'D':s.visible_x,'yD':s.visible_y,'C':s.candidate_x,'Q':s.reference_x,'T':test,'pT':pt,'yT':yt}.items()}|{'B':s.budget}
            if shared is None:shared=common
            assert shared==common
            if assoc=='neutral':
                if fixed_D_action is None:fixed_D_action=actions['D-only']
                assert np.array_equal(fixed_D_action,actions['D-only'])
            h,g,u=frozen.geometry(s,True);hd,_,_=frozen.geometry(s,False);ordinary=h-hd
            row={'world_id':world,'condition_id':state_id,'direction':direction,'ordinary_n':on,'cost_condition':assoc,'visible_state_hash':vhash,
                 'D_hash':digest(s.visible_x),'D_y_hash':digest(s.visible_y),'O_hash':digest(s.ordinary_x),'O_y_hash':digest(yo),'C_hash':digest(s.candidate_x),
                 'C_y_hash':digest(yc),'Q_hash':digest(s.reference_x),'T_hash':digest(test),'T_y_hash':digest(yt),'cost_hash':digest(s.cost),
                 'cost_multiset_hash':digest(np.sort(s.cost)),'budget':s.budget,'candidate_n':len(cid),'Kstar':frozen.kstar(s.cost,s.budget),
                 'ordinary_fisher_trace':float(np.trace(ordinary)),'ordinary_fisher_eigenvalues':np.linalg.eigvalsh(ordinary),
                 'ordinary_positive_fraction':float(yo.mean()),'ordinary_feature_sqnorm':float(np.square(s.ordinary_x[:,2:]).sum()),
                 'selection_seconds_all_methods':selection_seconds,'all_ordinary_approved':True,'all_candidates_rejected':True}
            state_rows.append(row);action_records=[]
            for method,selected in actions.items():
                assert s.cost[selected].sum()<=s.budget+1e-10
                token=service.lock(selected,method,world)
                rec={'world_id':world,'condition_id':state_id,'direction':direction,'ordinary_n':on,'cost_condition':assoc,'method':method,
                     'selected_ids':cid[selected],'selected_indices':selected,'select_hash':digest(np.sort(cid[selected])),'lock_key':token,'visible_state_hash':vhash,
                     'count':len(selected),'cost':float(s.cost[selected].sum()),'budget':s.budget,'slack':float(s.budget-s.cost[selected].sum()),'Kstar':row['Kstar'],
                     'proxy_score_conditional':frozen.set_value(h,g,u,selected),'selection_seconds_family':selection_seconds}
                locks.append(rec);action_records.append((rec,selected,token))
            # Null, infeasible-budget, candidate permutation and hidden-label controls.
            if on==500 and assoc=='neutral':
                empty=replace(s,ordinary_x=s.ordinary_x[:0]);ea=action_family(empty,cid)
                assert np.array_equal(ea['D-only'],ea['Pending-aware'])
                zero=action_family(replace(s,budget=0.),cid);assert all(len(x)==0 for x in zero.values())
                perm=np.random.default_rng(world+999).permutation(len(cid));ps=replace(s,candidate_x=s.candidate_x[perm],cost=s.cost[perm])
                pa=action_family(ps,cid[perm])
                for m in actions:assert np.array_equal(np.sort(cid[actions[m]]),np.sort(cid[perm][pa[m]])),m
                # Build alternate feedback labels, keeping the acquisition state unchanged.
                altered=y.copy();altered[np.r_[oid,cid]]=1-altered[np.r_[oid,cid]]
                other=replace(service,_y=altered);aa=action_family(s,cid)
                for m in actions:assert np.array_equal(actions[m],aa[m])
                valid=actions['MinRisk'];key=service.lock(valid,'audit',world)
                wrong=np.setdiff1d(np.arange(len(cid)),valid)[:1]
                try:other.reveal(wrong,key)
                except RuntimeError:pass
                else:raise AssertionError('A lock revealed B labels')
                audits.append({'world_id':world,'direction':direction,'empty_O':True,'Kstar_zero':True,'stable_ID_permutation':True,'hidden_O_C_label_selector_invariance':True,'mismatched_lock_rejected':True})
            np.savez_compressed(world_private/f'{state_id}_environment.npz',D=s.visible_x,yD=s.visible_y,O=s.ordinary_x,yO=yo,C=s.candidate_x,yC=yc,Q=s.reference_x,cost=s.cost,B=s.budget,candidate_ids=cid)
            all_states.append((world,state_id,s,service,action_records,test,yt,pt,yc,exposure))
    write_jsonl(out/'state_manifest.jsonl',state_rows);write_jsonl(out/'selection_locks.jsonl',locks)
    lock_sha=sha(out/'selection_locks.jsonl');write_json(out/'selection_commitment.json',{'sha256':lock_sha,'actions':len(locks),'all_locked_before_outcome_training':True})
    write_json(out/'boundary_audit.json',{'passed':True,'states':audits,'outer_T_not_an_acquisition_argument':True,
        'hidden_T_labels_not_an_acquisition_argument':True,'scope':'API separation and perturbation controls, not an OS security boundary'})
    cache={};rows=[];fit_counts={'LR':0,'XGB':0};devices=set();hits=0;max_error=0.;pred_dir=private/'predictions';pred_dir.mkdir()
    for world,state_id,s,service,actions,test,yt,pt,yc,exposure in all_states:
        for rec,selected,token in actions:
            ids,x,y=service.reveal(selected,token)
            for learner in ['LR','XGB']:
                params={'ridge':cfg['lr_ridge'],'loss':'sum'} if learner=='LR' else cfg['xgb']
                fitkey=digest({'learner':learner,'ids':digest(ids),'x':digest(x),'y':digest(y),'params':params,'learning_seed':world+7000,'source':sources})
                cache_hit=fitkey in cache;tick=time.perf_counter()
                if cache_hit:prediction,backend=cache[fitkey];hits+=1
                else:
                    if learner=='LR':model=frozen.fit_logistic(x,y,cfg['lr_ridge']);prediction=expit(test@model);backend='cpu'
                    else:
                        model=XGBClassifier(**cfg['xgb'],random_state=world+7000,objective='binary:logistic',eval_metric='logloss')
                        model.fit(x[:,1:].astype(np.float32),y)
                        actual=json.loads(model.get_booster().save_config())['learner'];backend=actual['generic_param']['device']
                        assert backend.startswith('cuda'),'No silent CPU fallback: '+backend
                        prediction=model.predict_proba(test[:,1:].astype(np.float32))[:,1].astype(float);devices.add(backend)
                    cache[fitkey]=(prediction,backend);fit_counts[learner]+=1
                seconds=time.perf_counter()-tick;excess=(prediction-pt)**2;loss=(prediction-yt)**2
                path=pred_dir/f'{fitkey}.npz'
                if not path.exists():np.savez_compressed(path,prediction=prediction,pT=pt,yT=yt,squared_error=loss,excess_squared_error=excess,selected_ids=np.sort(service.c_ids[selected]),train_ids=ids)
                with np.load(path) as saved:
                    max_error=max(max_error,abs(float(excess.mean())-float(((saved['prediction']-saved['pT'])**2).mean())),abs(float(loss.mean())-float(((saved['prediction']-saved['yT'])**2).mean())))
                rows.append({k:v for k,v in rec.items() if k not in ['selected_ids','selected_indices']}|{'learner':learner,'fit_key':fitkey,'cache_hit':cache_hit,'actual_backend':backend,
                    'learning_seed':world+7000,'train_n':len(y),'train_ids_hash':digest(ids),'excess_brier':float(excess.mean()),'brier':float(loss.mean()),
                    'realized_selected_loss':float(np.dot(yc[selected],s.cost[selected]/cfg['business_PD_candidate'])),'fit_predict_seconds':seconds})
        pd.DataFrame(rows).to_csv(out/'branch_outcomes.csv',index=False)
        write_json(out/'progress.json',{'last_state':state_id,'completed_slots':len(rows),'total_slots':cfg['nominal_fit_slots'],'unique_fits':fit_counts,'cache_hits':hits})
        print(state_id,'slots',len(rows),'unique',fit_counts,'hits',hits,flush=True)
    assert len(rows)==cfg['nominal_fit_slots'] and len(state_rows)==48 and len(locks)==192
    assert sha(out/'selection_locks.jsonl')==lock_sha and max_error<1e-12
    assert all(sha(ROOT/k)==v for k,v in sources.items())
    result={'completed':True,'confirmation':False,'independent_worlds':len(cfg['world_ids']),'states':len(state_rows),'selector_slots':len(locks),'nominal_fit_slots':len(rows),
            'unique_outcome_fits':fit_counts,'additional_acquisition_LR_fits':len(cfg['world_ids']),'cache_hits':hits,'actual_XGB_devices':sorted(devices),'saved_prediction_max_error':max_error,
            'source_unchanged':True,'selection_commitment_unchanged':True,'seconds':time.perf_counter()-started,'all_conditions_retained':True}
    write_json(out/'completion.json',result);print(json.dumps(result),flush=True)

if __name__=='__main__':main()
