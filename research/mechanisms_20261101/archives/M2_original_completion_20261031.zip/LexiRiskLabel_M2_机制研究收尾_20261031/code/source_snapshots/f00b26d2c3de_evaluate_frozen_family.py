"""Independent-label-world evaluation of a frozen, feature-only finite family."""
from pathlib import Path
from dataclasses import replace
import argparse,json,sys,time,subprocess,platform
import numpy as np
import pandas as pd
from scipy.special import expit
from xgboost import XGBClassifier
from run_paired_mechanism_states import generate,action_family,visible_hash
from runtime import frozen,sha,digest,write_json,write_jsonl

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]

def static_select(s,conditional,stable_ids):
    h,g,u=frozen.geometry(s,conditional);v=frozen.marginal(frozen.inverse(h),g,u)
    order=np.lexsort((stable_ids,-v/s.cost));selected=[];remaining=s.budget
    for i in order:
        if s.cost[i]<=remaining+1e-12 and v[i]>1e-15:selected.append(i);remaining-=s.cost[i]
    return np.sort(np.array(selected,int))

def family(s,stable_ids,world):
    proposals=action_family(s,stable_ids);order=np.lexsort((stable_ids,s.cost));k=frozen.kstar(s.cost,s.budget)
    for percent in [25,50,75]:proposals[f'MinRisk-k{percent}']=np.sort(order[:int(k*percent/100)])
    proposals['D-static']=static_select(s,False,stable_ids);proposals['Pending-static']=static_select(s,True,stable_ids)
    for draw in range(4):
        rng=np.random.default_rng(np.random.SeedSequence([world,87001,draw]));remaining=s.budget;chosen=[]
        for i in np.argsort(stable_ids,kind='stable')[rng.permutation(len(stable_ids))]:
            if s.cost[i]<=remaining+1e-12:chosen.append(i);remaining-=s.cost[i]
        proposals[f'Random-{draw}']=np.sort(np.array(chosen,int))
    unique=[];lookup={}
    for method,selected in proposals.items():
        key=digest(np.sort(stable_ids[selected]));lookup[method]=key
        if key not in {x['select_hash'] for x in unique}:unique.append({'select_hash':key,'primary_name':method,'selected':selected,'proposal_names':[method]})
        else:next(x for x in unique if x['select_hash']==key)['proposal_names'].append(method)
    return unique,lookup

def target(world,tag,n,cfg):
    rng=np.random.default_rng(np.random.SeedSequence([world,tag]));x=np.zeros((n,5));x[:,0]=1;x[:,1]=rng.uniform(-2,2.2,n);x[:,2]=rng.normal(0,cfg['direction_radius_sd'],n)
    p=expit(x@np.array(cfg['truth_theta']));y=(rng.random(n)<p).astype(int);return x,p,y

def hidden_draw(world,rep,s,cfg,tag):
    # Same Uniform arrays are used across fixed sets and across paired directions.
    rng=np.random.default_rng(np.random.SeedSequence([world,tag,rep]));truth=np.array(cfg['truth_theta'])
    yo=(rng.random(max(cfg['ordinary_sizes']))[:len(s.ordinary_x)]<expit(s.ordinary_x@truth)).astype(int)
    yc=(rng.random(cfg['C'])<expit(s.candidate_x@truth)).astype(int)
    return yo,yc

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--out',type=Path,required=True);a=ap.parse_args();out=a.out;out.mkdir(parents=True,exist_ok=False)
    private=out/'private';private.mkdir();cfg=json.loads((HERE/'mechanism_protocol.json').read_text())['pilot'];plan=json.loads((HERE/'family_protocol.json').read_text())
    paths=[Path(__file__),HERE/'family_protocol.json',HERE/'mechanism_protocol.json',HERE/'run_paired_mechanism_states.py',HERE/'run_exact_geometry.py',ROOT/'experiments/protocol_next/runtime.py',ROOT/'experiments/research_v2/core.py']
    sources={str(p.relative_to(ROOT)):sha(p) for p in paths}
    gpu=subprocess.run(['nvidia-smi','--query-gpu=name,driver_version','--format=csv,noheader'],capture_output=True,text=True);assert gpu.returncode==0
    write_json(out/'registration.json',{'plan':plan,'generator':cfg,'sources':sources,'hardware':gpu.stdout.strip(),'started_utc':pd.Timestamp.now(tz='UTC').isoformat(),'python':platform.python_version(),'confirmation':False})
    started=time.perf_counter();contexts=[];locks=[];manifests=[]
    for world in plan['world_ids']:
        states,_,_,_,_=generate(world,cfg)
        for condition in plan['conditions']:
            state_id,direction,on,assoc,s,_,_,cid,did,oid,_=next(x for x in states if x[1]==condition['direction'] and x[2]==condition['ordinary_n'] and x[3]==condition['cost_condition'])
            unique,lookup=family(s,cid,world);assert len(unique)<=plan['family_limit']
            for entry in unique:
                idx=entry['selected'];assert len(idx)==len(np.unique(idx)) and s.cost[idx].sum()<=s.budget+1e-10
                locks.append({'world_id':world,'condition_id':state_id,'visible_hash':visible_hash(s),'select_hash':entry['select_hash'],'proposal_names':entry['proposal_names'],'selected_ids':cid[idx],'selected_indices':idx,'count':len(idx),'cost':float(s.cost[idx].sum()),'budget':s.budget})
            vsets={split:target(world,tag,plan['reference_n_per_split'],cfg) for split,tag in plan['reference_rng_tags'].items()}
            assert not np.array_equal(vsets['search'][0],vsets['eval'][0])
            np.savez_compressed(private/f'{state_id}_state.npz',D=s.visible_x,yD=s.visible_y,O=s.ordinary_x,C=s.candidate_x,Q_ref=s.reference_x,cost=s.cost,B=s.budget,candidate_ids=cid)
            if not (private/f'{world}_evaluation.npz').exists():np.savez_compressed(private/f'{world}_evaluation.npz',**{split+'_'+field:values[i] for split,values in vsets.items() for i,field in enumerate(['X','p','y'])})
            h,g,u=frozen.geometry(s,True)
            manifests.append({'world_id':world,'condition_id':state_id,'direction':direction,'ordinary_n':on,'visible_hash':visible_hash(s),'family_size':len(unique),'lookup':lookup,
                'D_hash':digest(s.visible_x),'D_y_hash':digest(s.visible_y),'O_hash':digest(s.ordinary_x),'C_hash':digest(s.candidate_x),'cost_hash':digest(s.cost),'Q_hash':digest(s.reference_x),
                'search_X_hash':digest(vsets['search'][0]),'eval_X_hash':digest(vsets['eval'][0]),'budget':s.budget,
                'conditional_proxy':{e['select_hash']:frozen.set_value(h,g,u,e['selected']) for e in unique}})
            contexts.append((world,state_id,direction,s,cid,unique,lookup,vsets))
    write_jsonl(out/'frozen_family.jsonl',locks);write_jsonl(out/'state_manifest.jsonl',manifests)
    lock_hash=sha(out/'frozen_family.jsonl');write_json(out/'family_commitment.json',{'sha256':lock_hash,'families':len(contexts),'sets':len(locks),'all_frozen_before_label_worlds':True})
    rows=[];cache={};counts={'LR':0,'XGB':0};backends=set();nominal=0;max_error=0.;mc_locks=[];winners=[]
    for split in ['search','eval']:
        reps=plan['search_replicate_ids'] if split=='search' else list(range(plan['eval_replicate_start'],plan['eval_replicate_start']+plan['eval_replicates']))
        # Every eval split winner is physically saved after search and before eval.
        if split=='eval':
            frame=pd.DataFrame(rows)
            for world,state_id,direction,s,cid,unique,lookup,vsets in contexts:
                for learner in plan['learners']:
                    means=frame[(frame.condition_id==state_id)&(frame.learner==learner)].groupby('select_hash').excess_brier.mean()
                    winner=min(unique,key=lambda e:(means[e['select_hash']],list(lookup).index(e['primary_name'])))
                    winners.append({'world_id':world,'condition_id':state_id,'direction':direction,'learner':learner,'winner_select_hash':winner['select_hash'],'winner_name':winner['primary_name'],'search_mean':float(means[winner['select_hash']]),'MinRisk_select_hash':lookup['MinRisk']})
            write_jsonl(out/'search_winners.jsonl',winners);winner_hash=sha(out/'search_winners.jsonl')
        for world,state_id,direction,s,cid,unique,lookup,vsets in contexts:
            xref,pref,yref=vsets[split];saved_predictions=[];prediction_keys=[]
            for rep in reps:
                yo,yc=hidden_draw(world,rep,s,cfg,plan['label_rng_tag'])
                mc_locks.append({'condition_id':state_id,'split':split,'replicate':rep,'O_y_hash':digest(yo),'C_y_hash':digest(yc)})
                for entry in unique:
                    idx=entry['selected'];x=np.vstack([s.visible_x,s.ordinary_x,s.candidate_x[idx]]);y=np.r_[s.visible_y,yo,yc[idx]]
                    for learner in plan['learners']:
                        nominal+=1;fitkey=digest({'X':digest(x),'y':digest(y),'learner':learner,'seed':world+7000,'params':cfg['xgb'] if learner=='XGB' else cfg['lr_ridge'],'sources':sources})
                        tick=time.perf_counter()
                        # Key includes labels and observed features; prices do not alter training.
                        if fitkey in cache:model,backend=cache[fitkey];hit=True
                        else:
                            hit=False
                            if learner=='LR':model=frozen.fit_logistic(x,y,cfg['lr_ridge']);backend='cpu'
                            else:
                                model=XGBClassifier(**cfg['xgb'],random_state=world+7000,objective='binary:logistic',eval_metric='logloss');model.fit(x[:,1:].astype(np.float32),y)
                                backend=json.loads(model.get_booster().save_config())['learner']['generic_param']['device'];assert backend.startswith('cuda');backends.add(backend)
                            counts[learner]+=1
                            # No model cache across replicates: bounded memory, duplicates already removed per family.
                        pred=expit(xref@model) if learner=='LR' else model.predict_proba(xref[:,1:].astype(np.float32))[:,1].astype(float)
                        excess=float(np.square(pred-pref).mean());brier=float(np.square(pred-yref).mean())
                        prediction_key=f'{rep}_{learner}_{entry["select_hash"]}';prediction_keys.append(prediction_key);saved_predictions.append(pred)
                        rows.append({'world_id':world,'condition_id':state_id,'direction':direction,'split':split,'replicate':rep,'learner':learner,'primary_name':entry['primary_name'],'select_hash':entry['select_hash'],
                            'fit_key':fitkey,'excess_brier':excess,'sampled_brier':brier,'expected_brier':excess+float(np.mean(pref*(1-pref))),'actual_backend':backend,'seconds':time.perf_counter()-tick,'cache_hit':hit,'count':len(idx),'cost':float(s.cost[idx].sum()),'budget':s.budget,'train_n':len(y)})
            # Compact matrix preserves every per-person prediction, one file per condition and split.
            p=private/f'{state_id}_{split}_predictions.npz';np.savez_compressed(p,prediction=np.array(saved_predictions),keys=np.array(prediction_keys),p=pref,y=yref)
            with np.load(p) as saved:
                for key,pred in zip(prediction_keys,saved_predictions):
                    i=prediction_keys.index(key);max_error=max(max_error,abs(float(np.square(saved['prediction'][i]-saved['p']).mean())-float(np.square(pred-pref).mean())))
            pd.DataFrame(rows).to_csv(out/'fit_outcomes.csv',index=False)
            write_json(out/'progress.json',{'split':split,'last_state':state_id,'nominal_fit_slots':nominal,'actual_fits':counts,'seconds':time.perf_counter()-started})
            print(split,state_id,'fits',nominal,counts,flush=True)
    write_jsonl(out/'label_world_manifest.jsonl',mc_locks)
    assert sha(out/'frozen_family.jsonl')==lock_hash and sha(out/'search_winners.jsonl')==winner_hash and max_error==0
    assert all(sha(ROOT/k)==v for k,v in sources.items()) and nominal<=plan['max_nominal_fit_slots']
    write_json(out/'completion.json',{'completed':True,'confirmation':False,'independent_worlds':len(plan['world_ids']),'states':len(contexts),'unique_frozen_sets':len(locks),'nominal_fit_slots':nominal,'actual_fits':counts,
        'additional_generator_acquisition_LR_fits':len(plan['world_ids']),'actual_XGB_devices':sorted(backends),'search_replicates':len(plan['search_replicate_ids']),'eval_replicates':plan['eval_replicates'],
        'saved_prediction_max_error':max_error,'sources_unchanged':True,'frozen_family_unchanged':True,'winner_frozen_before_eval':True,'seconds':time.perf_counter()-started})
    print(json.dumps(json.loads((out/'completion.json').read_text())),flush=True)

if __name__=='__main__':main()
