"""Fresh-world confirmation of the one unresolved original M2 contrast."""
from common import *
from dataclasses import replace
import argparse,copy,time,platform,subprocess,importlib.metadata
import pandas as pd
from scipy.special import expit
from xgboost import XGBClassifier

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--start',type=int,required=True);ap.add_argument('--count',type=int,required=True);ap.add_argument('--out',type=Path,required=True);ap.add_argument('--engineering-smoke',action='store_true');a=ap.parse_args()
    require_stage('M2');plan=json.loads((Path(__file__).parent/'protocol.json').read_text())
    if a.engineering_smoke:assert set(range(a.start,a.start+a.count))<=set(plan['engineering_world_ids'])
    else:assert a.start>=plan['first_world_id'] and a.start+a.count<=plan['first_world_id']+plan['maximum_worlds']
    out=a.out;out.mkdir(parents=True,exist_ok=False);private=out/'private';private.mkdir();src=sources();cfg=copy.deepcopy(json.loads((HERE/'mechanism_protocol.json').read_text())['pilot']);cfg['truth_theta'][2]=0.
    gpu=subprocess.run(['nvidia-smi','--query-gpu=name,driver_version','--format=csv,noheader'],capture_output=True,text=True);assert gpu.returncode==0
    reg={'stage':'M2','plan':plan,'world_ids':list(range(a.start,a.start+a.count)),'configuration':cfg,'sources':src,'hardware':gpu.stdout.strip(),'started_utc':pd.Timestamp.now(tz='UTC').isoformat(),'environment':{'python':platform.python_version(),**{k:importlib.metadata.version(k) for k in ['numpy','pandas','scipy','scikit-learn','xgboost']}}};write_json(out/'registration.json',reg)
    locks=[];contexts=[];started=time.perf_counter();boundary=[]
    for world in reg['world_ids']:
        generated=generate(world,cfg)[0];states=[x for x in generated if x[1] in plan['directions'] and x[3]=='neutral'];assert len(states)==4
        first=states[0];fixed=action_family(first[4],first[7])['D-only'];ev=target(world,plan['evaluation_rng_tag'],plan['evaluation_n'],cfg)
        common=None;small={};spectra={};world_context=[]
        for sid,direction,on,assoc,s,_,_,cid,did,oid,_ in states:
            state_dir=private/sid;state_dir.mkdir();vh=visible_hash(s);yall=np.zeros(int(cid.max())+1,int);yall[did]=s.visible_y
            service=FeedbackService(did,oid,cid,s.visible_x,s.ordinary_x,s.candidate_x,yall,state_dir,sid+'_'+vh)
            inputs={k:digest(v) for k,v in {'D':s.visible_x,'yD':s.visible_y,'C':s.candidate_x,'Q':s.reference_x,'cost':s.cost,'T':ev[0]}.items()}|{'B':s.budget}
            if common is None:common=inputs
            assert common==inputs
            if on==500:small[direction]=s.ordinary_x
            else:assert np.array_equal(small[direction],s.ordinary_x[:500])
            pp=expit(s.ordinary_x@np.asarray(cfg['truth_theta']));info=s.ordinary_x.T@((pp*(1-pp))[:,None]*s.ordinary_x);spec=np.linalg.eigvalsh(info)
            if on in spectra:assert np.array_equal(pp,spectra[on][1]) and np.max(np.abs(spec-spectra[on][0]))/max(1.,spec.max())<1e-12
            spectra[on]=(spec,pp)
            methods={'OrdinaryOnly':np.empty(0,int),'D-only':fixed}
            for method,idx in methods.items():
                token=service.lock(idx,method,world);assert s.cost[idx].sum()<=s.budget+1e-10
                locks.append({'world_id':world,'condition_id':sid,'direction':direction,'ordinary_n':on,'method':method,'selected_indices':idx,'selected_ids':cid[idx],'select_hash':digest(cid[idx]),'lock_key':token,'visible_hash':vh,'common_inputs':inputs,'O_hash':digest(s.ordinary_x),'count':len(idx),'cost':float(s.cost[idx].sum()),'budget':s.budget})
            world_context.append((sid,direction,on,s,cid,service,methods))
        boundary.append({'world_id':world,'common_inputs':True,'nested_O':True,'same_fixed_Donly_set':True,'true_isospectral_geometry':True})
        contexts.append((world,world_context,ev))
    write_jsonl(out/'selection_locks.jsonl',locks);locksha=sha(out/'selection_locks.jsonl');write_json(out/'selection_commitment.json',{'sha256':locksha,'all_before_feedback':True,'sets':len(locks)})
    rows=[];worlds=[];labels=[];fit_count=0
    for world,states,ev in contexts:
        xref,pt,yt=ev;predictions=[];keys=[];save={};risk={};last_yc=None;yo_small={}
        for sid,direction,on,s,cid,service,methods in states:
            yo,yc=hidden_draw(world,plan['label_replicate'],s,cfg,plan['label_rng_tag'])
            if last_yc is not None:assert np.array_equal(yc,last_yc)
            last_yc=yc
            if on==500:yo_small[direction]=yo
            else:assert np.array_equal(yo_small[direction],yo[:500])
            full=service._y.copy();full[service.o_ids]=yo;full[cid]=yc;feedback=replace(service,_y=full)
            labels.append({'world_id':world,'condition_id':sid,'O_y_hash':digest(yo),'C_y_hash':digest(yc)})
            save[f'O_{direction}_{on}']=s.ordinary_x;save[f'yo_{direction}_{on}']=yo
            for method,idx in methods.items():
                token=service.lock(idx,method,world);train_ids,x,y=feedback.reveal(idx,token)
                model=XGBClassifier(**cfg['xgb'],random_state=world+7000,objective='binary:logistic',eval_metric='logloss');model.fit(x[:,1:].astype(np.float32),y)
                backend=json.loads(model.get_booster().save_config())['learner']['generic_param']['device'];assert backend.startswith('cuda')
                pred=model.predict_proba(xref[:,1:].astype(np.float32))[:,1].astype(float);fit_count+=1
                name=f'{direction}_{on}_{method}';keys.append(name);predictions.append(pred);r=float(np.square(pred-pt).mean());risk[direction,on,method]=r
                fitkey=digest({'X':digest(x),'y':digest(y),'learning_seed':world+7000,'params':cfg['xgb'],'sources':src})
                rows.append({'world_id':world,'direction':direction,'ordinary_n':on,'method':method,'learner':'XGB','select_hash':digest(cid[idx]),'train_ids_hash':digest(train_ids),'train_n':len(train_ids),'fit_key':fitkey,'actual_backend':backend,'excess_brier':r,'sampled_brier':float(np.square(pred-yt).mean()),'expected_brier':r+float(np.mean(pt*(1-pt))),'cost':float(s.cost[idx].sum()),'budget':s.budget})
        I={d:(risk[d,4000,'OrdinaryOnly']-risk[d,4000,'D-only'])-(risk[d,500,'OrdinaryOnly']-risk[d,500,'D-only']) for d in plan['directions']}
        worlds.append({'world_id':world,'I_irrelevant':I['irrelevant'],'I_unlock':I['unlock'],'value':I['unlock']-I['irrelevant']})
        s=states[0][3];cid=states[0][4];fixed=states[0][6]['D-only'];save.update(D=s.visible_x,yD=s.visible_y,C=s.candidate_x,Q=s.reference_x,cost=s.cost,B=s.budget,candidate_ids=cid,selected_indices=fixed,prediction=np.asarray(predictions),keys=np.asarray(keys),X_eval=xref,p=pt,y=yt,yc=last_yc)
        np.savez_compressed(private/f'w{world}.npz',**save)
        write_json(out/'progress.json',{'completed_worlds':len(worlds),'total_worlds':a.count,'actual_CUDA_fits':fit_count,'seconds':time.perf_counter()-started,'interim_tests':False})
        print('world',world,'completed',len(worlds),'CUDA fits',fit_count,flush=True)
    pd.DataFrame(rows).to_csv(out/'fit_outcomes.csv',index=False);pd.DataFrame(worlds).to_csv(out/'world_contrasts.csv',index=False);write_jsonl(out/'label_manifest.jsonl',labels);write_json(out/'boundary_audit.json',{'passed':True,'worlds':boundary})
    assert sha(out/'selection_locks.jsonl')==locksha and fit_count==a.count*8;check_sources(src)
    write_json(out/'completion.json',{'completed':True,'worlds':a.count,'actual_CUDA_fits':fit_count,'nominal_slots':len(rows),'sources_unchanged':True,'later_stages_started':False,'seconds':time.perf_counter()-started})

if __name__=='__main__':main()
