"""Independently audit paired weak-feedback extension, retaining all five counts."""
from pathlib import Path
import sys,json
sys.path.insert(0,str(Path(__file__).parent))
from analyze_m2_conditional_bridge import process
from m2_closure.common import TASK,write_json,sha,interval
import pandas as pd
import numpy as np
from decompose_label_bias_variance import components
WEAK=TASK/'work/M2_weak_boundary_confirmation'
STRONG=TASK/'work/M2_conditional_bridge_confirmation'
OUT=TASK/'work/M2_mechanism_bridge'

def first16(child):
    reg=json.loads((child/'registration.json').read_text());start=reg['plan']['label_replicate_start'];rows=[]
    for state in map(json.loads,(child/'state_manifest.jsonl').read_text().splitlines()):
        sid=state['condition_id']
        with np.load(child/'private'/sid/'predictions.npz') as z:pred=z['prediction'];p=z['p'];keys=[str(k).split('_',2) for k in z['keys']]
        for learner in ['LR','XGB']:
            parts={}
            for method in ['OrdinaryOnly','D-only']:
                idx=[i for i,k in enumerate(keys) if start<=int(k[0])<start+16 and k[1]==learner and k[2]==method];assert len(idx)==16;parts[method]=components(pred[idx],p)
            b,d=parts['OrdinaryOnly'],parts['D-only'];rows.append({k:state[k] for k in ['variant','world_id','direction','ordinary_n']}|{'learner':learner,'total_gain':b['total_excess']-d['total_excess'],'bias_gain':b['conditional_squared_bias_unbiased']-d['conditional_squared_bias_unbiased'],'variance_gain':b['conditional_prediction_variance']-d['conditional_prediction_variance']})
    return pd.DataFrame(rows)

def paired_audit(weak,strong):
    wr=json.loads((weak/'registration.json').read_text());sr=json.loads((strong/'registration.json').read_text());assert wr['plan']['world_ids']==sr['plan']['world_ids']
    for name in ['label_rng_tag','label_replicate_start','evaluation_rng_tag','evaluation_n']:assert wr['plan'][name]==sr['plan'][name]
    def locks(p):return {(r['condition_id'],r['method']):r for r in map(json.loads,(p/'selection_locks.jsonl').read_text().splitlines())}
    wl,sl=locks(weak),locks(strong);count=0;zero_cache={};max_zero_error=0.
    for state in map(json.loads,(weak/'state_manifest.jsonl').read_text().splitlines()):
        sid=state['condition_id'];variant=state['variant'];world=state['world_id'];direction=state['direction'];on=state['ordinary_n'];strong_id=f'{variant}_w{world}_{direction}_O500_neutral'
        with np.load(weak/'private'/sid/'state.npz') as z, np.load(strong/'private'/strong_id/'state.npz') as a:
            for name in ['D','yD','C','Q','cost','B','candidate_ids']:assert np.array_equal(z[name],a[name])
            assert np.array_equal(z['O'],a['O'][:on])
        assert wl[sid,'D-only']['select_hash']==sl[strong_id,'D-only']['select_hash']
        if on==0:
            key=(variant,world)
            if zero_cache.get('world')!=key:zero_cache={'world':key}
            with np.load(weak/'private'/sid/'predictions.npz') as z:keys=[str(k).split('_',2) for k in z['keys']];pred=z['prediction']
            for learner in ['LR','XGB']:
                for method in ['OrdinaryOnly','D-only']:
                    idx=[i for i,k in enumerate(keys) if k[1]==learner and k[2]==method];matrix=pred[idx];tag=(learner,method)
                    if tag in zero_cache:max_zero_error=max(max_zero_error,float(np.max(np.abs(matrix-zero_cache[tag]))))
                    zero_cache[tag]=matrix
                    if method=='OrdinaryOnly':assert np.array_equal(matrix,np.repeat(matrix[:1],len(matrix),axis=0))
        count+=1
    assert max_zero_error==0.
    return {'passed':True,'paired_state_prefixes_and_same_D_C_Q_cost_budget_sets':count,'zeroO_cross_direction_max_prediction_error':max_zero_error}

def main():
    assert json.loads((WEAK/'completion.json').read_text())['completed'];assert json.loads((STRONG/'completion.json').read_text())['completed'];audits=[];rows=[];pairs=[]
    windex=json.loads((WEAK/'batch_index.json').read_text());sindex=json.loads((STRONG/'batch_index.json').read_text())
    for w,s in zip(windex,sindex):
        wp,sp=Path(w['path']),Path(s['path']);g,_,_,a=process(wp);p=paired_audit(wp,sp);rows.extend([g,first16(sp)]);audits.append(a);pairs.append(p);write_json(OUT/'weak_independent_audits.json',{'audits':audits,'paired_audits':pairs});print('weak diagnostic audited',len(audits),'of4',flush=True)
    frame=pd.concat(rows,ignore_index=True);assert len(frame)==64*2*3*5*2 and not frame.duplicated(['variant','world_id','direction','ordinary_n','learner']).any()
    assert set(frame.ordinary_n)=={0,32,128,500,4000};frame.to_csv(OUT/'independent_five_count_paired_gains.csv',index=False)
    summaries=[]
    for key,q in frame.groupby(['variant','direction','ordinary_n','learner']):
        r=interval(q.total_gain,.05,60,1);r.pop('verdict');summaries.append(dict(zip(['variant','direction','ordinary_n','learner'],key))|r)
    pd.DataFrame(summaries).to_csv(OUT/'five_count_gain_curve_summary.csv',index=False)
    changes=[]
    for key,q in frame.groupby(['variant','world_id','learner']):
        v=q.set_index(['direction','ordinary_n']);base=dict(zip(['variant','world_id','learner'],key))
        for low,high in [(0,32),(32,128),(128,500),(500,4000)]:
            I={d:float(v.loc[(d,high),'total_gain']-v.loc[(d,low),'total_gain']) for d in ['target','irrelevant','unlock']}
            for name,value in [('K_sub',I['irrelevant']-I['target']),('K_unlock',I['unlock']-I['irrelevant'])]:changes.append(base|{'ordinary_low':low,'ordinary_high':high,'contrast':name,'value':value})
    cc=pd.DataFrame(changes);cc.to_csv(OUT/'five_count_adjacent_world_contrasts.csv',index=False);summary=[]
    for key,q in cc.groupby(['variant','learner','ordinary_low','ordinary_high','contrast']):
        r=interval(q.value,.05,32,1);r.pop('verdict');summary.append(dict(zip(['variant','learner','ordinary_low','ordinary_high','contrast'],key))|r)
    pd.DataFrame(summary).to_csv(OUT/'five_count_adjacent_contrast_summary.csv',index=False)
    report={'passed':True,'shared_independent_worlds':64,'weak_label_M':16,'strong_curve_label_M':16,'weak_states':sum(r['states'] for r in audits),'weak_prediction_rows_recomputed':sum(r['prediction_rows_recomputed'] for r in audits),'maximum_risk_error':max(r['maximum_risk_error'] for r in audits),'maximum_decomposition_error':max(r['maximum_bias_variance_identity_error'] for r in audits),'all_paired_prefixes_and_selections_verified':True,'zeroO_cross_direction_max_prediction_error':max(r['zeroO_cross_direction_max_prediction_error'] for r in pairs),'scope':'prospective paired response diagnosis on one64-world cohort, never128 worlds; 32 adjacent contrasts and60 curve points have separate descriptive simultaneous intervals, no replacement or promotion of original eight primary cells'}
    write_json(OUT/'weak_diagnostic_completion.json',report);print(json.dumps(report),flush=True)
if __name__=='__main__':main()
