import unittest
from accept_m2_serious_completion import validate_payload,EXPECTED,TARGET
from common import require_stage

class SupplementalGateTests(unittest.TestCase):
    def evidence(self):
        cells=[]
        for key in EXPECTED:
            cell=dict(zip(['variant','learner','contrast'],key))|{'n_worlds':8192 if key==TARGET else 4096,'mean':-.005,'simultaneous_low':-.01,'simultaneous_high':-.001,'verdict':'opposite_direction','evidence_source':'fresh_independent_supplement' if key==TARGET else 'historical_conservative_simultaneous_envelope'}
            if key==TARGET:cell.update(look_index=0,alpha_this_interval=.0125)
            cells.append(cell)
        e={'stage':'M2','delta':.0001,'historical_alpha':.025,'supplemental_alpha':.025,'mandatory_mechanisms':cells,'items':{k:True for k in require_stage('M2')['M2_acceptance_items']}}
        for k in ['original_full_matrix_audited','new_primary_independently_audited','new_diagnostics_independently_audited','weak_feedback_boundary_independently_audited','prospective_diagnostic_formulas_frozen','mechanism_boundary_analysis_complete']:e[k]=True
        return e
    def test_all_terminal_and_all_evidence_allows_acceptance(self):self.assertTrue(validate_payload(self.evidence()))
    def test_pending_target_blocks_stage(self):
        e=self.evidence();r=next(x for x in e['mandatory_mechanisms'] if (x['variant'],x['learner'],x['contrast'])==TARGET);r.update(simultaneous_low=-.001,simultaneous_high=.001,verdict='unresolved')
        with self.assertRaises(RuntimeError):validate_payload(e)
    def test_old_and_new_target_worlds_cannot_be_pooled(self):
        e=self.evidence();next(x for x in e['mandatory_mechanisms'] if (x['variant'],x['learner'],x['contrast'])==TARGET)['n_worlds']=12288
        with self.assertRaises(RuntimeError):validate_payload(e)
    def test_lowered_margin_cannot_pass(self):
        e=self.evidence();e['delta']=.00001
        with self.assertRaises(RuntimeError):validate_payload(e)
    def test_diagnostics_cannot_be_skipped(self):
        e=self.evidence();e['new_diagnostics_independently_audited']=False
        with self.assertRaises(RuntimeError):validate_payload(e)
    def test_narrow_J_cannot_replace_original_K(self):
        e=self.evidence();e['mandatory_mechanisms'][0]['contrast']='J'
        with self.assertRaises(RuntimeError):validate_payload(e)
    def test_positive_label_cannot_override_interval(self):
        e=self.evidence();e['mandatory_mechanisms'][0]['verdict']='supports_meaningful_registered_direction'
        with self.assertRaises(RuntimeError):validate_payload(e)
    def test_unbudgeted_later_look_cannot_pass(self):
        e=self.evidence();r=next(x for x in e['mandatory_mechanisms'] if (x['variant'],x['learner'],x['contrast'])==TARGET);r.update(n_worlds=32768,look_index=1,alpha_this_interval=.0125)
        with self.assertRaises(RuntimeError):validate_payload(e)
if __name__=='__main__':unittest.main(verbosity=2)
