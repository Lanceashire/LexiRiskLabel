"""Portable M2 verification. Run with Python + numpy/pandas/scipy, no GPU."""
from pathlib import Path
import json, hashlib
import numpy as np
import pandas as pd
from scipy.stats import t
ROOT=Path(__file__).resolve().parent.parent

def verdict(lo,hi):
    if lo>.0001:return 'supports_meaningful_registered_direction'
    if hi<0:return 'opposite_direction'
    if lo>=-.0001 and hi<=.0001:return 'approximately_equivalent_at_registered_margin'
    if hi<.0001:return 'meaningful_registered_positive_excluded'
    return 'unresolved'

def main():
    manifest=json.loads((ROOT/'SHA256_MANIFEST.json').read_text())
    for name,digest in manifest.items():assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest,name
    old=pd.read_csv(ROOT/'tables/historical_world_interactions.csv')
    new=pd.read_csv(ROOT/'tables/fresh_primary_world_contrasts.csv')
    final=pd.read_csv(ROOT/'tables/M2_final_all_eight_mechanisms.csv')
    assert len(new)==new.world_id.nunique()==32768
    assert set(new.world_id)==set(range(100001,132769))
    endpoints=pd.read_csv(ROOT/'tables/fresh_primary_endpoint_risks.csv')
    p=endpoints.pivot(index='world_id',columns=['direction','ordinary_n','method'],values='excess_brier')
    I={d:(p[d,4000,'OrdinaryOnly']-p[d,4000,'D-only'])-(p[d,500,'OrdinaryOnly']-p[d,500,'D-only']) for d in ['irrelevant','unlock']}
    direct=I['unlock']-I['irrelevant']
    assert np.max(np.abs(direct-new.set_index('world_id').value))<1e-14
    maxerr=0
    for r in final.itertuples():
        fresh=(r.variant,r.learner,r.contrast)==('isospectral','XGB','K_unlock')
        if fresh:x=new.value;alpha=.025/4
        else:x=old[(old.variant==r.variant)&(old.learner==r.learner)&(old.contrast==r.contrast)].value;alpha=.025/(8*4)
        n=len(x);mean=x.mean();se=x.std(ddof=1)/np.sqrt(n);radius=t.ppf(1-alpha/2,n-1)*se
        assert n==r.n_worlds and verdict(mean-radius,mean+radius)==r.verdict
        maxerr=max(maxerr,abs(mean-r.mean),abs(se-r.world_SE),abs(mean-radius-r.simultaneous_low),abs(mean+radius-r.simultaneous_high))
    assert maxerr<1e-14 and len(final)==8 and not final.verdict.eq('unresolved').any()
    cc=pd.read_csv(ROOT/'tables/independent_component_world_contrasts.csv')
    p=cc.pivot(index=['variant','world_id','learner','contrast'],columns='component',values='value')
    assert np.abs(p.total_gain-p.bias_gain-p.variance_gain).max()<1e-12
    f=pd.read_csv(ROOT/'tables/independent_five_count_paired_gains.csv')
    assert f.world_id.nunique()==64 and len(f)==3840 and set(f.ordinary_n)=={0,32,128,500,4000}
    assert not f.duplicated(['variant','world_id','learner','direction','ordinary_n']).any()
    assert np.abs(f.total_gain-f.bias_gain-f.variance_gain).max()<1e-12
    adjacent=[]
    for key,q in f.groupby(['variant','world_id','learner']):
        p=q.pivot(index='ordinary_n',columns='direction',values='total_gain')
        assert np.max(np.abs(p.loc[0]-p.loc[0,'target']))<1e-14
        for lo,hi in [(0,32),(32,128),(128,500),(500,4000)]:
            delta=p.loc[hi]-p.loc[lo]
            for contrast,value in [('K_sub',delta.irrelevant-delta.target),('K_unlock',delta.unlock-delta.irrelevant)]:
                adjacent.append(dict(zip(['variant','world_id','learner'],key))|{'ordinary_low':lo,'ordinary_high':hi,'contrast':contrast,'value':value})
    adjacent=pd.DataFrame(adjacent)
    summary=pd.read_csv(ROOT/'tables/five_count_adjacent_contrast_summary.csv')
    for r in summary.itertuples():
        x=adjacent[(adjacent.variant==r.variant)&(adjacent.learner==r.learner)&(adjacent.ordinary_low==r.ordinary_low)&(adjacent.ordinary_high==r.ordinary_high)&(adjacent.contrast==r.contrast)].value
        radius=t.ppf(1-.05/(2*32),63)*x.std(ddof=1)/8
        assert max(abs(x.mean()-r.mean),abs(x.mean()-radius-r.simultaneous_low),abs(x.mean()+radius-r.simultaneous_high))<1e-14
    e=json.loads((ROOT/'verification/M2_FINAL_ACCEPTANCE.json').read_text())
    assert e['M2_complete'] and not e['later_stages_started']
    print(json.dumps({'passed':True,'manifest_files':len(manifest),'all_eight_intervals_recomputed':True,'maximum_interval_error':maxerr,'diagnostic_decompositions_recomputed':True,'all_32_adjacent_intervals_recomputed_from_condition_gains':True,'primary_fresh_worlds':32768,'diagnostic_worlds':64},indent=2))

if __name__=='__main__':main()
