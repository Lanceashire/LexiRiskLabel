from pathlib import Path
import sys,json,concurrent.futures
import numpy as np
import pandas as pd
OLD=Path('LOCAL_WORKSPACE/2026-10-31/ji-x')
sys.path.insert(0,str(OLD/'work/m2_closure'))
from driver import audit
from common import sha,write_json
OUT=Path(__file__).resolve().parent

def check(child):
    saved=json.loads((child/'independent_audit.json').read_text())
    for name,h in saved['file_hashes'].items():assert sha(child/name)==h,(str(child),name)
    values,report=audit(child)
    assert report==saved, str(child)
    return values,report

def main():
    run=OLD/'work/M2_independent_closure_20261031'
    children=sorted(run.glob('batch_[0-9][0-9][0-9][0-9][0-9]'))
    assert len(children)==256
    values=[];reports=[]
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        for i,(v,r) in enumerate(pool.map(check,children),1):
            values.append(v);reports.append(r)
            if i%16==0:print('primary batches independently reaudited',i,'/256',flush=True)
    frame=pd.concat(values,ignore_index=True)
    assert len(frame)==32768 and frame.world_id.nunique()==32768
    assert sorted(frame.world_id)==list(range(100001,132769))
    registered=pd.read_csv(run/'look_32768/world_contrasts.csv')
    assert np.max(np.abs(frame.value.to_numpy()-registered.value.to_numpy()))<1e-14
    frame.to_csv(OUT/'M2_primary_fresh_worlds_reaudited.csv',index=False)
    result={'passed':True,'worlds':32768,'batches':256,'prediction_rows_recomputed':262144,
      'maximum_risk_error':max(r['maximum_risk_error'] for r in reports),
      'all_prior_audits_and_hashes_exactly_reproduced':True,
      'source_training_labels_locks_and_predictions_verified':True}
    write_json(OUT/'M2_primary_reaudit_final.json',result)
    print(json.dumps(result),flush=True)

if __name__=='__main__':main()
