from pathlib import Path
import json,hashlib,shutil,zipfile
import pandas as pd

HERE=Path(__file__).resolve().parent
TASK=HERE.parent
OLD=Path('LOCAL_WORKSPACE/2026-10-31/ji-x')
D=OLD/'work/M2_mechanism_bridge'
OUT=TASK/'outputs/LexiRiskLabel_M2_机制研究收尾_20261031'

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def cp(src,dst):dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
def main():
    acceptance=json.loads((D/'M2_FINAL_ACCEPTANCE.json').read_text())
    assert acceptance['M2_complete'] and not acceptance['later_stages_started']
    assert json.loads((HERE/'M2_primary_reaudit_final.json').read_text())['passed']
    assert json.loads((HERE/'M2_weak_recovery_consistency.json').read_text())['passed']
    OUT.mkdir(exist_ok=True,parents=True)
    for p in D.glob('*.csv'):cp(p,OUT/'tables'/p.name)
    for p in D.glob('*.json'):cp(p,OUT/'verification'/p.name)
    for p in D.glob('*.txt'):cp(p,OUT/'theory'/p.name)
    for p in (D/'figures').glob('*.png'):cp(p,OUT/'figures'/p.name)
    for p in HERE.glob('M2_*.json'):cp(p,OUT/'verification'/p.name)
    for p in HERE.glob('*.py'):cp(p,OUT/'code'/p.name)
    cp(OLD/'work/M2_math_and_acceptance_final_tests.log',OUT/'verification/M2_math_and_acceptance_final_tests.log')
    cp(OLD/'outputs/LexiRiskLabel_M2_续研_20261031.zip',OUT/'historical/original_M2_4096_complete_archive.zip')
    cp(OLD/'outputs/LexiRiskLabel_M2_续研报告_20261031.txt',OUT/'historical/original_M2_4096_report.txt')
    oldrun=OLD/'work/M2_resumed_restart_20261031'
    cp(oldrun/'look_4096/world_interactions.csv',OUT/'tables/historical_world_interactions.csv')
    cp(HERE/'M2_primary_fresh_worlds_reaudited.csv',OUT/'tables/fresh_primary_world_contrasts.csv')
    cp(OLD/'work/M2_independent_closure_20261031/historical_conservative_reanalysis.csv',OUT/'tables/historical_conservative_reanalysis.csv')
    for p in (OLD/'outputs/LexiRiskLabel_M2_续研_20261031/tables').glob('*.csv'):cp(p,OUT/'historical/tables'/p.name)
    frames=[]
    for p in sorted((OLD/'work/M2_independent_closure_20261031').glob('batch_?????/fit_outcomes.csv')):
        frames.append(pd.read_csv(p,usecols=['world_id','direction','ordinary_n','method','excess_brier','train_n']))
    pd.concat(frames,ignore_index=True).to_csv(OUT/'tables/fresh_primary_endpoint_risks.csv',index=False)
    regs=[OLD/'work/M2_independent_closure_20261031/registration.json',OLD/'work/M2_precision_continuation_20261031/registration.json',OLD/'work/M2_conditional_bridge_confirmation/registration.json',OLD/'work/M2_conditional_bridge_confirmation/batch_01/registration.json',OLD/'work/M2_weak_boundary_confirmation/registration.json',OLD/'work/M2_weak_boundary_confirmation/batch_01/registration.json']
    sources={}
    for i,p in enumerate(regs):
        reg=json.loads(p.read_text());cp(p,OUT/f'verification/source_registration_{i}.json')
        sources.update(reg['sources'])
    for name in ['analysis_registration.json']:
        sources.update(json.loads((D/name).read_text())['source_sha256'])
    w=json.loads((D/'weak_analysis_registration.json').read_text());sources[str(OLD/'work/analyze_m2_weak_response.py')]=w['analysis_source_sha256']
    for name in ['accept_m2_serious_completion.py','test_m2_completion_acceptance.py','plot_m2_serious.py']:
        p=OLD/'work'/name;sources[str(p)]=sha(p)
    snapshot={}
    for name,h in sources.items():
        p=Path(name);assert sha(p)==h,name
        dest=Path('code/source_snapshots')/f'{h[:12]}_{p.name}';cp(p,OUT/dest);snapshot[name]={'packaged_path':str(dest),'sha256':h}
    (OUT/'verification/SOURCE_SNAPSHOT_INDEX.json').write_text(json.dumps(snapshot,ensure_ascii=False,indent=2)+'\n')
    # Retain original and stricter target results, never silently replace intervals.
    for run in ['M2_independent_closure_20261031','M2_precision_continuation_20261031']:
        for p in (OLD/'work'/run).glob('look_*/result.json'):cp(p,OUT/'verification'/run/p.parent.name/'result.json')
        for name in ['execution_complete.json','batch_audits.json','latest_result.json','statistical_closure.json']:
            p=OLD/'work'/run/name
            if p.exists():cp(p,OUT/'verification'/run/name)
    final=pd.read_csv(D/'M2_final_all_eight_mechanisms.csv')
    names={'supports_meaningful_registered_direction':'支持超过0.0001的正向预测','opposite_direction':'反向','meaningful_registered_positive_excluded':'排除达到0.0001的正效应','approximately_equivalent_at_registered_margin':'在登记门槛内近似等效'}
    lines=['LexiRiskLabel M2 机制研究收尾报告','日期：2026-10-31（Asia/Shanghai）','',
      '研究结论：原有完整矩阵、剩余机制的独立确认、条件偏差—方差诊断、五档反馈响应与独立审计已完成。本轮补充验收通过；原4096世界研究当时的未完成状态保持原样。通过的是包含负结果的研究验收，不是原正向理论故事全部成立。',
      '当前证据支持2项正向替代对比、4项反向对比、2项排除实质正效应，没有未确定的必需主机制。没有一项原登记解锁对比得到正向确认。M3/M4/M5未运行，原治理文件也未被自动改为下一阶段。','',
      '一、研究对象与新的工作量',
      '固定额外探索集S，探索价值V_g(n)=R(OrdinaryOnly)-R(D-only)。I_g=V_g(4000)-V_g(500)，K_sub=I_irrelevant-I_target，K_unlock=I_unlock-I_irrelevant。K是差之差，不能把K_sub<0误读为目标方向的绝对价值必然上升。',
      '旧研究：4096独立世界，两个生成器×2反馈数量×3方向×4动作×2学习器，393216名义预测记录。',
      '剩余单项：32768个全新独立世界，8个风险端点/世界，262144次CUDA XGB拟合；目标是等信息谱控制/XGB/K_unlock。新旧世界不混合。',
      '新机制诊断：64个独立世界，每世界32次未来反馈，实现原六条件、两个生成器、LR/XGB、OrdinaryOnly/D-only，共98304名义预测记录。',
      '弱反馈扩展：复用同64世界和前16次反馈，在0、32、128条反馈处补充73728名义预测记录，与500、4000共同组成五档曲线。不能把它与强反馈诊断相加说成128世界；M次标签也不是M个独立世界。','',
      '二、主机制统计结论',
      'delta仍为0.0001。联合验收将原8项×4检查的总体预算从0.05保守重算为0.025，新独立单项预算另为0.025。新流的几何检查N_k=8192×4^k，a_k=0.025/2^(k+1)；本次在32768已达到终止判定，不执行131072。所有主区间仍依赖世界级t近似，不宣称有限样本置信序列定理。',
      '原两检查补充方案曾把32768的区间判为反向；扩展方案在此检查点前冻结，联合验收采用更宽的统一包络，只作“排除实质正效应”。两个记录均保留，不选择较有利的区间。','']
    for r in final.sort_values(['variant','learner','contrast']).itertuples():lines.append(f'{r.variant} / {r.learner} / {r.contrast}: n={r.n_worlds}, 均值={r.mean:.9f}, 同时区间=[{r.simultaneous_low:.9f}, {r.simultaneous_high:.9f}]；{names[r.verdict]}。')
    lines+=['','最后一项区间上端约0.000008852，低于0.0001，因此足以排除预定实质正效应；区间仍跨0，既不能说已严格确认负效应，也不能说近似等于0。','',
      '三、实际研究出了哪些机制条件',
      '1. 解锁需要完整几何与合适的信息区间。F(t)=tr G[(H+tJ)^-1-(H+tJ+A)^-1]，其导数取决于H、J、A、G的共同关系。如果四矩阵可同时对角化，F不随t增加而上升；非对角耦合可能解锁，但不是充分保证。构造例明确展示同一斜向设计可先解锁、后替代，见theory/M2_MECHANISM_CONDITIONS_AND_LIMITS.txt。',
      '新64世界中，估计信息代理的解锁对比在原生成器约-0.000153681、控制约-0.000183677。说明本研究实际固定选集与500→4000区间，在代理层就没有给出正向解锁。这里是该设置的描述证据，不是不存在任何解锁机制的定理。',
      '2. 信息代理与固定D的实际重训风险不是同一个风险对象。线性化logistic风险=条件平方偏差+未来反馈预测方差=逆信息项+D锚点修正。修正项来自已经实现的D标签误差和正则化，可能改变边际价值符号；实际分类器还保留局部近似余项。',
      '3. 这个修正不能包办所有反转。新64世界原生成器K_sub：真实参数逆信息代理+0.000077516，加入D修正后+0.000099337；实际LR均值-0.000082999。修正后符号仍不一致，因此不能报告“反转已由D误差/正则化解释”。该局部模型对XGB也没有近似保证。',
      '4. 实际风险分解揭示方向相反的贡献。控制K_sub中，LR方差贡献+0.000158198，XGB+0.003509408；二者24项同时诊断区间均全正。控制K_unlock中，对应方差贡献为-0.000163000和-0.001842462，区间均全负。原生成器XGB的K_sub方差贡献也显著为正，但总对比的诊断均值为负，偏差贡献均值更负。偏差项本身的区间较宽，不能把这种均值抵消模式升级为已确认的唯一主因。',
      '5. irrelevant只指旋转学习坐标，普通样本仍带截距和业务信息。原生成器目标方向的探索价值会下降，但参照方向下降更多，导致K_sub反向；参照组不是零信息对照。零目标信号控制则另改了真实参数，不能据它声称原信号下存在纯信息方向的普遍因果效应。','',
      '四、弱反馈边界',
      '所有0/32/128/500/4000点均保留，同一D/C/Q/T、价格、预算、S与反馈随机数配对。0反馈时各方向预测逐元素相同，是必要的零对照。完整60个曲线点和32个相邻K对比各自使用描述性同时区间。它们不替换原八项主机制，也不把挑出的正值升级为新确认假设。',
      '本轮最有价值的新边界证据：等信息谱控制的LR在0→32条反馈时，K_unlock=+0.003450649，32项诊断同时区间[+0.000584756,+0.006316541]；32→128条时，K_unlock=-0.001217958，区间[-0.002044460,-0.000391456]。同一批世界、同一选集、同一学习器，在两个相邻区间中出现方向相反且分别离开0的诊断证据，支持“解锁依赖反馈区间”的具体边界；不把它追认为原500→4000主假设通过。',
      '原生成器在0→32条反馈时，LR的K_sub=+0.019912726，区间[+0.011412989,+0.028412462]；XGB=+0.028811379，区间[+0.015316381,+0.042306376]。这与原登记500→4000的反向主结果共同表明，替代预测的适用区间不能从低反馈直接外推到高反馈。64世界的高反馈诊断本身仍较宽，不能单凭该诊断声称完整高反馈反转已再次独立确认。']
    weak=pd.read_csv(D/'weak_all_adjacent_interval_signs.csv')
    pos=weak[weak.interval_sign=='positive'];neg=weak[weak.interval_sign=='negative']
    lines.append(f'32个相邻区间对比中：{len(pos)}个描述性同时区间全正，{len(neg)}个全负，{sum(weak.interval_sign=="includes_zero")}个跨零。')
    for r in pd.concat([pos,neg]).sort_values(['variant','learner','ordinary_low','contrast']).itertuples():lines.append(f'  {r.variant}/{r.learner}/{r.contrast}，{r.ordinary_low}→{r.ordinary_high}: {r.mean:.9f} [{r.simultaneous_low:.9f}, {r.simultaneous_high:.9f}]。')
    lines+=['','五、验证与研究边界',
      '全新主研究32768世界的262144行预测已再次独立重算，训练ID、隐藏标签、选择锁、源码与原审计逐一核对；最大风险差为0。强诊断98304行、弱诊断73728行均从保存预测重算三种Brier，最大差为0。条件偏差—方差恒等式误差在浮点舍入范围。两轮弱反馈中断记录均保留并与最终重跑逐元素比较，不重复计入样本。',
      '恢复一致性核对覆盖641条已提交状态记录（其中包含两轮中重复的世界状态，不作为新增样本）；全部已提交预测与最终批次逐元素完全一致。原中断另留下1个0字节预测文件，该状态未进入当时的拟合账本或进度提交；空文件保留、不纳入一致性样本，最终批次已完整生成并审计该状态。',
      '13项原补充数学与门禁测试通过；包内另提供不依赖GPU与原路径的世界级复算入口，复现全部八项区间、判定和诊断恒等式。数学公式与强/弱诊断分析脚本均在相应结果分析前冻结；本轮新增的完整残差账本明确标为事后描述，不改变主结论。',
      '通过验收表示登记任务、必要判定、完整证据和报告已收尾，支持、反向和足够精度的否定都允许关闭对应假设。它不表示所有诊断分量都已高精度识别，更不表示原生成器替代反转的主要因果来源已唯一确定。',
      '局限仍是一个合成生成器及一个零目标信号控制、有限固定反馈范围、固定选集与当前LR/XGB参数；没有真实信用数据、跨机构、十轮动态流程的确认，也不能据此断言CCF B投稿已具备充分核心贡献。','',
      '六、文件与复核',
      '运行：python code/verify_m2_package.py（需要numpy、pandas、scipy，无需GPU）。SHA256_MANIFEST.json覆盖交付内容。tables/含世界级主对比、每端点风险、诊断条件收益、分量与相邻区间；verification/含验收、登记、审计和原/更严格区间；code/含脚本快照和源码映射；historical/完整保留上一轮原4096世界紧凑包。',
      '原始逐样本数据、全部预测与中断记录在本机旧项目work/下保留，体积较大，没有重复装进紧凑包。原始地址索引：',
      str(OLD/'work/M2_resumed_restart_20261031'),str(OLD/'work/M2_independent_closure_20261031'),str(OLD/'work/M2_conditional_bridge_confirmation'),str(OLD/'work/M2_weak_boundary_confirmation'),
      '未上传GitHub。临时MPS只用于本次GPU调度，实验完成后关闭；没有改变生成器、阈值、学习器或选集。']
    (OUT/'M2_机制研究收尾报告.txt').write_text('\n'.join(lines)+'\n')
    cp(OUT/'M2_机制研究收尾报告.txt',TASK/'outputs/M2_机制研究收尾报告.txt')
    manifest={str(p.relative_to(OUT)):sha(p) for p in sorted(OUT.rglob('*')) if p.is_file() and p.name!='SHA256_MANIFEST.json'}
    (OUT/'SHA256_MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
    archive=OUT.with_suffix('.zip')
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in sorted(OUT.rglob('*')):
            if p.is_file():z.write(p,str(p.relative_to(OUT.parent)))
    archive.with_suffix('.zip.sha256').write_text(f'{sha(archive)}  {archive.name}\n')
    print(json.dumps({'output':str(OUT),'files':len(manifest),'zip_bytes':archive.stat().st_size,'zip_sha256':sha(archive)},ensure_ascii=False,indent=2))

if __name__=='__main__':main()
