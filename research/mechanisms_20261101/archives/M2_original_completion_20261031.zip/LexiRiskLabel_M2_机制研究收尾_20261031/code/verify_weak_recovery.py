from pathlib import Path
import json,hashlib,csv
import numpy as np
RUN=Path('LOCAL_WORKSPACE/2026-10-31/ji-x/work/M2_weak_boundary_confirmation')
OUT=Path(__file__).resolve().parent

def main():
    assert json.loads((RUN/'completion.json').read_text())['completed']
    reports=[]
    for old in sorted(RUN.glob('batch_??_interrupted_*')):
        new=RUN/old.name[:8];checked=0;arrays=0
        assert json.loads((old/'registration.json').read_text())['sources']==json.loads((new/'registration.json').read_text())['sources']
        assert (old/'selection_locks.jsonl').read_bytes()==(new/'selection_locks.jsonl').read_bytes()
        ledger=list(csv.DictReader((old/'fit_outcomes.csv').open()))
        committed={r['condition_id'] for r in ledger}
        assert len(committed)==json.loads((old/'progress.json').read_text())['completed_states']
        assert len(ledger)==len(committed)*64
        allfiles=list(old.glob('private/*/predictions.npz'))
        uncommitted=[{'path':str(p.relative_to(old)),'bytes':p.stat().st_size} for p in allfiles if p.parent.name not in committed]
        assert all(p['bytes']==0 for p in uncommitted), 'unexpected nonempty uncommitted prediction needs manual inspection'
        for sid in sorted(committed):
            p=old/'private'/sid/'predictions.npz'
            q=new/p.relative_to(old)
            with np.load(p) as a,np.load(q) as b:
                assert a.files==b.files
                for k in a.files:
                    assert np.array_equal(a[k],b[k]),(str(p),k)
                    arrays+=1
            checked+=1
        reports.append({'retained_directory':str(old),'completed_states_compared':checked,'arrays_compared':arrays,'all_predictions_exactly_equal':True,'all_selection_locks_exactly_equal':True,'uncommitted_empty_files_retained_not_counted':uncommitted})
    assert len(reports)==8
    before=json.loads((RUN/'registration_before_recovery_20261031.json').read_text())
    after=json.loads((RUN/'registration.json').read_text())
    assert before['sources']==after['sources'] and before['main_protocol']==after['main_protocol']
    result={'passed':True,'interrupted_directories':reports,'compared_state_records_including_repeated_states':sum(x['completed_states_compared'] for x in reports),'same_original_protocol_and_source_hashes':True,'duplicate_states_in_confirmation':0,'temporary_MPS_changes_predictions':False}
    (OUT/'M2_weak_recovery_consistency.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(result,ensure_ascii=False,indent=2))

if __name__=='__main__':main()
