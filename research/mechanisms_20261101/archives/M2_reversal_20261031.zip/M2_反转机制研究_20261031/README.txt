先读M2_反转机制研究报告.txt。无GPU复核：python code/verify_package.py。
主家族与附加诊断的预算分别报告，所有负/未定结果保留；不以干预正结果改判原模型。
