"""Prospective localization on untouched additional LR worlds only."""
from pathlib import Path
import sys,json,hashlib,concurrent.futures
import numpy as np
import pandas as pd
from scipy.special import expit
from scipy.stats import t
HERE=Path(__file__).resolve().parent

def one(dest):
    world=int(dest.name[1:]);assert 1001025<=world<=1004096
    with np.load(dest/'inputs.npz') as z:X=z['X_eval'];p=z['p_eval']
    with np.load(dest/'coefficients.npz') as z:
        allkeys=[str(k).split('|') for k in z['keys']];ix=[i for i,k in enumerate(allkeys) if k[4]=='full'];coef=z['theta'][ix];keys=[allkeys[i] for i in ix]
    assert len(keys)==64
    truth=np.array([-1.,.8,1.4,0.,0.]);eta=X@coef.T;eta0=X@truth;pred=expit(eta);error=pred-p[:,None];deta=eta-eta0[:,None];w=p*(1-p)
    slope=np.divide(error,deta,out=np.broadcast_to(w[:,None],deta.shape).copy(),where=np.abs(deta)>1e-10)
    max_secant=float(np.max(np.abs(error**2-slope**2*deta**2)));assert max_secant<1e-12
    actual=error**2;linkgap=(slope*slope-w[:,None]**2)*deta*deta
    best=X[:,:2]@coef[:,:2].T;zest=X[:,2,None]*coef[:,2][None,:];btrue=X[:,:2]@truth[:2];ztrue=X[:,2]*truth[2]
    rb=(expit(btrue[:,None]+zest)-p[:,None])**2;rz=(expit(best+ztrue[:,None])-p[:,None])**2
    parts={'actual':actual,'link_gap':linkgap,'business_shapley':(actual+rz-rb)/2,'signal_shapley':(actual+rb-rz)/2}
    rows=[]
    for region,mask in [('ordinary_support',X[:,1]<=.8),('outside_ordinary_support',X[:,1]>.8)]:
        for name,values in parts.items():
            values=(values*mask[:,None]).mean(axis=0)
            q=pd.DataFrame([{'direction':k[0],'n':int(k[1]),'method':k[3],'value':values[i]} for i,k in enumerate(keys)]).groupby(['direction','n','method']).value.mean()
            I={d:q[d,4000,'OrdinaryOnly']-q[d,4000,'D-only']-q[d,500,'OrdinaryOnly']+q[d,500,'D-only'] for d in ['target','irrelevant']}
            rows.append({'world_id':world,'region':region,'component':name,'I_target':I['target'],'I_irrelevant':I['irrelevant'],'K_sub':I['irrelevant']-I['target']})
    return rows,max_secant

def main():
    reg=json.loads((HERE/'suffix_localization_registration.json').read_text())
    assert hashlib.sha256(Path(__file__).read_bytes()).hexdigest()==reg['analysis_sha256']
    run=HERE/'confirmation_LR';assert json.loads((run/'look_1_execution_complete.json').read_text())['completed']
    worlds={int(p.name[1:]):p for p in run.glob('shard_look1_*/w[0-9]*') if p.name[1:].isdigit() and (p/'complete.json').exists()}
    assert set(worlds)==set(range(1001025,1004097));rows=[];maxerr=0.
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        for i,(rr,e) in enumerate(pool.map(one,[worlds[w] for w in sorted(worlds)]),1):
            rows.extend(rr);maxerr=max(maxerr,e)
            if i%256==0:print('localized new suffix worlds',i,'/3072',flush=True)
    out=HERE/'suffix_localization';out.mkdir(exist_ok=True);f=pd.DataFrame(rows);f.to_csv(out/'world_contrasts.csv',index=False);summary=[]
    for (region,component),q in f.groupby(['region','component']):
        for col in ['K_sub','I_target','I_irrelevant']:
            x=q[col];se=x.std(ddof=1)/np.sqrt(len(x));rad=t.ppf(1-.05/(2*24),len(x)-1)*se
            summary.append({'region':region,'component':component,'contrast':col,'n_worlds':len(x),'mean':x.mean(),'low':x.mean()-rad,'high':x.mean()+rad})
    pd.DataFrame(summary).to_csv(out/'summary.csv',index=False)
    result={'passed':True,'independent_suffix_worlds':3072,'old_first_look_worlds_excluded':1024,'interval_family':24,'alpha':.05,'scope':'separate diagnostic family; not a new primary test or a refit intervention','cutpoint_from_original_generator':.8,'weighted_partition_sums_to_original_target_risk':True,'max_exact_secant_identity_error':maxerr}
    (out/'audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)

if __name__=='__main__':main()
