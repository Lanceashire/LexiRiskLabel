from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,shutil,zipfile,concurrent.futures
import pandas as pd
R=Path(__file__).resolve().parent
TASK=R.parent.parent
OUT=TASK/'outputs/M2_反转机制研究_20261031'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def copy(p,q):q.parent.mkdir(exist_ok=True,parents=True);shutil.copy2(p,q)
def read(p):return json.loads(p.read_text())
def main():
    required=[R/'analysis_LR_look1_parallel/audit.json',R/'analysis_XGB_look1/audit.json',R/'additional_independent_audit.json',R/'histogram_actual_parameter_check.json',R/'baseline_refinement/audit.json',R/'suffix_localization/audit.json',R/'xgb_anchor_independent/audit.json',R/'anchor_factual_bridge/audit.json',R/'final_scheduler_comparison.json']
    assert all(read(p)['passed'] for p in required)
    assert read(R/'runtime_shutdown.json')['all_training_complete']
    frozen=read(R/'frozen_registration.json');assert all(sha(p)==h for p,h in frozen['source_sha256'].items())
    hist=read(R/'hist_precision_registration.json');assert all(sha(p)==h for p,h in hist['sources'].items())
    for reg,code,key in [('xgb_anchor_independent_registration.json','xgb_anchor_independent.py','source_sha256'),('anchor_factual_bridge_registration.json','anchor_factual_bridge.py','source_sha256'),('suffix_localization_registration.json','localize_suffix.py','analysis_sha256')]:assert read(R/reg)[key]==sha(R/code)
    OUT.mkdir(exist_ok=True,parents=True)
    mappings={
      'LR_worlds.csv':'analysis_LR_look1_parallel/world_contrasts.csv','LR_primary_summary.csv':'analysis_LR_look1_parallel/primary_summary.csv','LR_bias_variance_worlds.csv':'analysis_LR_look1_parallel/world_bias_variance_contrasts.csv','LR_linearization_worlds.csv':'analysis_LR_look1_parallel/world_risk_linearization_trace.csv','LR_diagnostic_summary.csv':'analysis_LR_look1_parallel/diagnostic_summary.csv',
      'XGB_worlds.csv':'analysis_XGB_look1/world_contrasts.csv','XGB_primary_summary.csv':'analysis_XGB_look1/primary_summary.csv','XGB_bias_variance_worlds.csv':'analysis_XGB_look1/world_bias_variance_contrasts.csv','XGB_diagnostic_summary.csv':'analysis_XGB_look1/diagnostic_summary.csv',
      'LR_first_look_worlds.csv':'analysis_LR_look0/world_contrasts.csv','LR_first_look_summary.csv':'analysis_LR_look0/primary_summary.csv','XGB_first_look_worlds.csv':'analysis_XGB_look0/world_contrasts.csv','XGB_first_look_summary.csv':'analysis_XGB_look0/primary_summary.csv',
      'domain_worlds.csv':'suffix_localization/world_contrasts.csv','domain_summary.csv':'suffix_localization/summary.csv','target_mixture_curve.csv':'suffix_localization/target_mixture_curve.csv',
      'anchor_worlds.csv':'xgb_anchor_independent/world_contrasts.csv','anchor_summary.csv':'xgb_anchor_independent/summary.csv','anchor_factual_worlds.csv':'anchor_factual_bridge/world_contrasts.csv','anchor_factual_summary.csv':'anchor_factual_bridge/summary.csv',
      'hist_worlds.csv':'hist_precision/world_contrasts.csv','hist_summary.csv':'hist_precision/summary.csv','precision_worlds.csv':'baseline_refinement/world_precision_differences.csv'}
    for name,p in mappings.items():copy(R/p,OUT/'tables'/name)
    for p in R.glob('*.json'):copy(p,OUT/'verification'/p.name)
    for p in R.glob('*.txt'):
        if p.name!='CONTINUATION_STATE.txt':copy(p,OUT/'methods'/p.name)
    for p in R.glob('*.py'):
        if p.name!='connect_m1_m2.py':copy(p,OUT/'code'/p.name)
    for p in (R/'confirmation_protocols').glob('*.json'):copy(p,OUT/'protocols/primary'/p.name)
    for p in (R/'hist_precision_protocols').glob('*.json'):copy(p,OUT/'protocols/histogram'/p.name)
    for p in (R/'figures').glob('*.png'):copy(p,OUT/'figures'/p.name)
    checks={
      'LR_final_audit.json':'analysis_LR_look1_parallel/audit.json','XGB_final_audit.json':'analysis_XGB_look1/audit.json','domain_audit.json':'suffix_localization/audit.json','mixture_boundary.json':'suffix_localization/mixture_boundary.json','baseline_refinement_audit.json':'baseline_refinement/audit.json','anchor_audit.json':'xgb_anchor_independent/audit.json','anchor_factual_audit.json':'anchor_factual_bridge/audit.json','histogram_execution_complete.json':'hist_precision/execution_complete.json'}
    for name,p in checks.items():copy(R/p,OUT/'verification'/name)
    snapshots=dict(frozen['source_sha256']);snapshots.update(hist['sources']);index={}
    for path,h in snapshots.items():
        p=Path(path);assert sha(p)==h;dest=Path('code/source_snapshots')/(h[:12]+'_'+p.name);copy(p,OUT/dest);index[path]={'path':str(dest),'sha256':h}
    (OUT/'verification/SOURCE_SNAPSHOT_INDEX.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n')
    # Raw prediction/state records remain local; hash the complete analyzed record set.
    raw=[]
    for folder in ['confirmation_LR','confirmation_XGB','hist_precision']:
        for p in (R/folder).glob('shard_*/w[0-9]*/*'):
            if p.is_file() and p.suffix in ['.npz','.csv','.json']:raw.append(p)
    for folder in ['xgb_anchor_independent','anchor_factual_bridge','baseline_refinement']:
        for p in (R/folder).glob('w[0-9]*/*'):
            if p.is_file() and p.suffix in ['.npz','.csv','.json']:raw.append(p)
    def record(p):return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
    with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:rawindex=list(pool.map(record,sorted(set(raw))))
    (OUT/'verification/LOCAL_RAW_RECORD_INDEX.json').write_text(json.dumps(rawindex,ensure_ascii=False,indent=2)+'\n')
    def row(learner,arm,contrast='K_sub'):
        f=pd.read_csv(OUT/'tables'/f'{learner}_primary_summary.csv');return f[(f.arm==arm)&(f.contrast==contrast)].iloc[0]
    def fmt(r):return f'{r["mean"]:+.9f}，同时区间[{r.low:+.9f}, {r.high:+.9f}]'
    lr=row('LR','full');slope=row('LR','known_business_slope');business=row('LR','known_business');xgb=row('XGB','full');xcal=row('XGB','known_business','paired_change_vs_full');xjoint=row('XGB','known_business_signal_only','paired_change_vs_full')
    hp=pd.read_csv(OUT/'tables/hist_summary.csv').set_index('contrast');precision=read(R/'baseline_refinement/audit.json');mixture=read(R/'suffix_localization/mixture_boundary.json')
    d=pd.read_csv(OUT/'tables/LR_diagnostic_summary.csv');trace=d[(d.source=='linearization_trace')&(d.contrast=='K_sub')].set_index('component')
    xd=pd.read_csv(OUT/'tables/XGB_diagnostic_summary.csv');xbv=xd[(xd.source=='bias_variance')&(xd.arm=='full')&(xd.contrast=='K_sub')].set_index('component')
    root_status={'registered_reversal_studies_complete':True,'LR_reversal_chain_identified':True,'XGB_business_calibration_contribution_confirmed':True,'XGB_composite_meaningful_recovery_condition_confirmed':bool(hp.loc['calibrated8192','low']>.0001),'unique_cause_for_all_learners_established':False,'histogram_change_alone_established':bool(hp.loc['full_histogram_change','low']>0),'historical_eight_M2_results_unchanged':True,'M3_started':False,'M3_automatically_authorized':False,'all_registered_null_and_unresolved_results_retained':True,'generated_utc':datetime.now(timezone.utc).isoformat()}
    (OUT/'verification/RESEARCH_CONCLUSIONS.json').write_text(json.dumps(root_status,indent=2)+'\n')
    lines=['M2反转机制研究报告','研究启动日期：2026-10-31；本报告只讨论当前合成设置。','',
      '核心结论：本轮已给出原生成器/LR反转的具体解释链：业务斜率估计与评价目标的覆盖域混合相互作用，并通过非线性概率风险改变差之差方向。固定真实业务斜率可使方向恢复为正；反转集中在普通反馈未覆盖的业务坐标区间。XGB中业务校准的贡献得到确认，并找到了能恢复有意义正向替代的复合条件；单一零点偏移与单独分箱均值效应尚不能包办解释。',
      '所有登记研究、复核和负结果均已交付。原八项M2主机制没有被改判；本轮不以干预后的正结果替换原始设定，也没有推进M3。唯一、普适的单因解释尚未成立。','',
      '一、为什么原来的“反转”需要解释',
      '探索价值V_g(n)=R(OrdinaryOnly)-R(D-only)，I_g=V_g(4000)-V_g(500)，K_sub=I_irrelevant-I_target。负K表示相对于参照方向的替代预测反向，并不表示目标方向的探索价值绝对上升。',
      '普通方向名称只约束三个学习坐标中的旋转方向。所有普通样本仍有截距与业务坐标a，真实logit为-1+0.8a+1.4z1。D与O的a在[-2,.8]，目标评价a在[-2,2.2]，候选探索对象的a约2.0986。因而“irrelevant”不是整条样本对目标预测完全无信息，目标中还包含普通反馈未覆盖的业务区间。','',
      '二、独立干预设计与工作量',
      '主研究：LR4096个新世界、每世界8次未来标签；XGB1024个新世界、每世界4次标签，后者与LR前1024世界共享，不能相加算5120。正常干预固定同一事实D-only选集、数据、成本与预算。仅标签耦合参照明确允许用独立Db重选Sb，以比较Sb/Db与Sa/Db的依赖关系。',
      'LR12个随机标签模型干预，加未来期望标签/全部期望标签两个去噪分支；30项主对比，alpha=.025，在1024/4096两个固定检查。XGB8个干预、17项主对比，alpha=.025，在256/1024检查。两个家族共同按并合界计入.05，使用世界级t近似，不宣称有限样本精确置信序列。',
      '区域定位由首看形成假设，在未用于首看的3072个LR世界单独验证，24项诊断、alpha=.05；不替换主家族。独立树零点诊断使用另1024世界、2次标签，24项预算、alpha=.01，单次分析；同世界原全特征事实参照在数据采集前追加，实际显示21项，仍在24项预算内。最后分箱控制另用512世界、2次标签、四模型分支，8项、alpha=.01。不同诊断家族分别报告，不声称所有后补家族共同具有统一95%覆盖。',
      '本轮独立世界合计5632=主LR4096（包含主XGB1024）+独立树1024+分箱512；区域3072只是LR后缀。主LR输出3211264条模型风险记录；GPU主/附加确认合计327680次拟合，另有4次实际配置复核。262144次事实LR高精度精化属于数值验证，不是新样本。工程世界全部排除。','',
      '三、LR反转的干预证据',f'事实模型：{fmt(lr)}。',f'只固定真实业务斜率0.8：{fmt(slope)}。',f'固定真实截距与业务斜率：{fmt(business)}。',
      '只固定斜率就足以确认方向转正，而只固定截距仍未确认转正。这把业务斜率估计定位为一个可干预、可重复验证的因素。该干预是合成真值诊断，不是实际部署时可以直接获得的知识。',
      '幅度边界：校准后LR的正K约0.000038，仍小于原实质门槛0.0001；它确认的是方向恢复，不等于原登记的有意义正向主假设通过。业务斜率干预相对事实的变化约0.000128，主同时下界约0.000094，不能声称已确认变化至少0.0001。',
      '替代解释得到约束：去掉z2后仍显著反向；去掉z3后仍反向；同时去两者仅部分减轻。去掉未来O/C标签噪声后仍反向，因此不能仅归因于未来标签噪声。全部标签替为均值后转正，但fit(EY)一般不等于Efit(Y)，该分支是去噪干预，不是原随机拟合风险的无偏估计。',
      '标签选择/重训耦合的负向影响约0.00000657，同时区间约[-0.00001292,-0.00000021]；其量级远小于0.0001，打断耦合后的模型也仍反向。它有小影响，不能解释主要反转。强ridge10能恢复有意义正向，低ridge0.1仍未定；正则化敏感性不允许把改变设置后的结果改写成原设置通过。','',
      '四、反转发生在哪里：目标覆盖域的可验证边界',
      '在独立的3072个LR后续世界中，按原生成器业务上界a=.8分区，采用对总目标风险的加权贡献，两个区域严格加和：',
      '普通反馈覆盖区间：K贡献+0.000053836，同时区间[+0.000021064,+0.000086608]。',
      '普通反馈未覆盖区间：K贡献-0.000144273，同时区间[-0.000172528,-0.000116019]。',
      '负向区域贡献盖过正向区域贡献，因此总体反向。业务参数误差和信号参数误差的Shapley分摊在域外都为负，不能把全部作用硬拆成一个独立业务项；业务与信号估计的交互、非线性风险共同参与。',
      '原目标总体有2/3位于覆盖区间、1/3位于域外。用已知区域概率缩放得到条件区域K，再仅改变域外目标占比q，有严格恒等式K(q)=(1-q)kL+qkH。无需重训，也没有换选集。',
      f'本设定变号比例点估计{mixture["estimated_sign_change_fraction"]:.4f}，由既有24项联合界导出范围[{mixture["joint_bound_for_sign_change_fraction"][0]:.4f},{mixture["joint_bound_for_sign_change_fraction"][1]:.4f}]；原占比1/3高于该范围上界。该曲线说明评价目标的域混合本身可以改变机制对比符号，不是普适的16%定律。','',
      '五、信息代理为什么没有预测实际反转',
      '本轮把一阶参数近似与一阶概率链接近似分开。以下是同一批4096世界、同一组事实拟合的精确风险账本：',
      f'一阶score风险对比 {trace.loc["one_step_score_risk","mean"]:+.9f}',
      f'加参数拟合线性化差项 {trace.loc["parameter_linearization_gap","mean"]:+.9f}',
      f'加logistic链接线性化差项 {trace.loc["link_linearization_gap","mean"]:+.9f}',
      f'等于实际分类风险对比 {trace.loc["actual","mean"]:+.9f}。',
      '两项近似差的诊断同时区间均为负；概率链接差约-0.000148，主要集中在域外，域外该差约-0.000148而覆盖区间接近0。线性化风险对象遗漏了实际拟合概率误差随状态变化的曲率权重，因此不能直接继承简单逆信息模型的方向。',
      '精确表达为sigmoid(eta_hat)-sigmoid(eta)=m(eta_hat,eta)*(eta_hat-eta)，其中m是割线斜率。真实Brier权重是随拟合状态变化的m²，而非固定在真实参数点的[p(1-p)]²。加和恒等式用于定位失配；因果证据来自前述固定业务斜率等干预，二者不能互相冒充。','',
      '六、XGB：偏差盖过方差收益，业务校准具有贡献',f'事实模型：{fmt(xgb)}。',f'只做已知业务项的配对变化：{fmt(xcal)}。',f'已知业务项且只保留信号特征的配对变化：{fmt(xjoint)}。',
      f'事实XGB的条件偏差贡献均值{xbv.loc["bias","mean"]:+.9f}，未来反馈方差贡献{xbv.loc["variance","mean"]:+.9f}，实际总贡献{xbv.loc["total","mean"]:+.9f}。完整区间见XGB_diagnostic_summary.csv。',
      '方差贡献为正、偏差贡献为负，原预想的方差收益被更大的反向偏差变化盖住。业务校准的配对改善得到确认；但校准后总K的区间仍跨0，不能说恢复了正向或证明等效0。单独去掉零信号坐标反而使XGB更负，这否定了把“冗余坐标就是根因”作为通用解释。',
      '独立零点诊断进一步表明：树模型即使使用真实业务logit作offset，也会学习剩余函数。将f(0)校正为真实0后的变化约+0.000162，99%家族同时区间约[-0.000263,+0.000586]，没有支持它足以包办剩余现象。该负结果完整保留。原拟复用后续世界的队列因与已分析LR世界重叠，在训练前取消；实际采用完全独立的新1024世界。','',
      '七、XGB恢复条件与分箱控制',
      f'已知业务项、仅保留真实信号、8192分箱：{fmt(hp.loc["calibrated8192"])}，同时下界超过0.0001，支持该复合设置下的有意义正向替代。',
      f'8192分箱下，校准分支相对全模型的变化：{fmt(hp.loc["calibration_change_8192"])}。',
      f'原全模型仅提高分箱精度的变化：{fmt(hp.loc["full_histogram_change"])}。',
      f'已知业务信号分支仅提高分箱精度的变化：{fmt(hp.loc["calibrated_histogram_change"])}。',
      '后两项区间跨0，因此不能单独把均值反转归因于256分箱。已确认的是复合条件下能恢复正向，以及业务校准在高精度分箱下仍具有贡献；并未证明分箱是唯一原因，也没有把复合正结果替换原主模型的负结果。4次验证重拟合已从Booster实际配置确认256/8192生效，保存预测逐元素复现。','',
      '八、数值与数据完整性',
      f'全部事实LR262144次拟合经独立高精度Newton精化，平均K从{precision["mean_K_frozen"]:+.12f}变为{precision["mean_K_refined"]:+.12f}，平均变化{precision["mean_K_difference"]:+.12e}，不足解释约9e-5的反转。原拟合结果未覆盖。',
      '初始最坏案例核验的单标签1e-6容差曾失败，最大差约1.57e-6；该失败未被删除或暗自放宽，随后进行了上述全量精化。',
      '主族从保存系数/预测重算风险，并重建生成器、未来标签、训练哈希、选择锁和业务offset。LR原线程审计与独立进程调度审计的5张结果表逐字节相同。附加独立诊断也重算了输入、标签、选择、预测与区间。',
      '独立零点诊断未校正分支使用float32概率，保存量为rawmargin；从margin重构概率存在很小舍入差。实测最大风险差8.43e-10，已按概率误差界核验；校正分支、事实参照与分箱诊断风险差为0。该数值容差不是效应门槛。','',
      '九、证据支持到哪里',
      '可以确认：当前LR反转有业务斜率估计、目标域覆盖和非线性风险的具体证据链；XGB业务校准有因果贡献，并存在恢复有意义正向替代的明确复合条件。',
      '不能确认：一个因素唯一解释所有学习器；单独分箱变化已造成均值变号；校准后的原256分箱XGB总效应等于0或为正；当前合成分布规律可直接外推真实任务。因果干预作用彼此存在交互，不能把均值分摊百分比当成唯一因果贡献。',
      '本轮登记研究与验证已完成，关键解释有实质进展；仍未识别的归因边界必须保留。M3没有启动，也没有因报告完成自动放行下一阶段。','',
      '十、复核与文件',
      '执行 python code/verify_package.py（需要numpy/pandas/scipy，无需GPU或原机器路径），可重算主族47项两检查、域定位24项、独立树21项和分箱8项的所有区间，并检查风险恒等式与目标混合界。',
      'tables/为世界级可复算数据；verification/为登记、源快照映射、所有审计及本机完整原始记录的SHA256索引；methods/为数学推导与协议说明；figures/为科学图；code/为冻结和复核脚本。训练脚本保留原路径用于来源追溯，异机训练需重建源布局与依赖。',
      f'本机原始数据根目录：{R}。逐样本预测/系数、全部标签/选集绑定与数值精化记录均保留，紧凑包不重复收入数GB原始文件。',
      '未上传GitHub。临时MPS服务已关闭，退出日志为0。实现依据仅使用官方文档：业务offset https://xgboost.readthedocs.io/en/stable/tutorials/intercept.html ；分箱参数 https://xgboost.readthedocs.io/en/latest/parameter.html 。以上实验结论均来自本机冻结数据，并非文档结论。']
    report='\n'.join(lines)+'\n';(OUT/'M2_反转机制研究报告.txt').write_text(report);copy(OUT/'M2_反转机制研究报告.txt',TASK/'outputs/M2_反转机制研究报告.txt')
    (OUT/'README.txt').write_text('先读M2_反转机制研究报告.txt。无GPU复核：python code/verify_package.py。\n主家族与附加诊断的预算分别报告，所有负/未定结果保留；不以干预正结果改判原模型。\n')
    manifest={str(p.relative_to(OUT)):sha(p) for p in sorted(OUT.rglob('*')) if p.is_file() and p.name!='SHA256_MANIFEST.json'}
    (OUT/'SHA256_MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
    archive=OUT.with_suffix('.zip')
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in sorted(OUT.rglob('*')):
            if p.is_file():z.write(p,str(p.relative_to(OUT.parent)))
    archive.with_suffix('.zip.sha256').write_text(sha(archive)+'  '+archive.name+'\n')
    print(json.dumps({'output':str(OUT),'manifest_files':len(manifest),'raw_record_files_indexed':len(rawindex),'zip_bytes':archive.stat().st_size,'zip_sha256':sha(archive)},ensure_ascii=False,indent=2))
if __name__=='__main__':main()
