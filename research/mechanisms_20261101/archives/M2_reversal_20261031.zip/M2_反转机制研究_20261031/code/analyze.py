from pathlib import Path
import argparse,json,sys
import numpy as np
import pandas as pd
from scipy.special import expit
from scipy.stats import t

def interval(x,family=1,alpha=.05):
    x=np.asarray(x);se=x.std(ddof=1)/np.sqrt(len(x));r=t.ppf(1-alpha/(2*family),len(x)-1)*se
    return {'n_worlds':len(x),'mean':float(x.mean()),'SE':float(se),'low':float(x.mean()-r),'high':float(x.mean()+r)}

def world_contrasts(run):
    frames=[];components=[];audits=[]
    reg=json.loads((run/'registration.json').read_text());plan=reg['plan']
    for world in plan['world_ids']:
        d=run/f'w{world}';comp=json.loads((d/'complete.json').read_text());assert comp['completed']
        f=pd.read_csv(d/'risks.csv')
        p=f.groupby(['direction','ordinary_n','method','arm'],as_index=False).risk.mean().pivot(index='arm',columns=['direction','ordinary_n','method'],values='risk')
        I={a:{g:float(p.loc[a,(g,4000,'OrdinaryOnly')]-p.loc[a,(g,4000,'D-only')]-p.loc[a,(g,500,'OrdinaryOnly')]+p.loc[a,(g,500,'D-only')]) for g in ['target','irrelevant']} for a in p.index}
        for arm in p.index:frames.append({'world_id':world,'arm':arm,'I_target':I[arm]['target'],'I_irrelevant':I[arm]['irrelevant'],'K_sub':I[arm]['irrelevant']-I[arm]['target']})
        with np.load(d/'inputs.npz') as z:X=z['X_eval'];truth=z['p_eval']
        with np.load(d/'coefficients.npz') as z:keys=[str(k).split('|') for k in z['keys']];coefs=z['theta']
        maxrisk=0.;rows=[]
        for arm in plan['arms']:
            for direction in ['target','irrelevant']:
                for on in [500,4000]:
                    for method in ['OrdinaryOnly','D-only']:
                        ix=[i for i,k in enumerate(keys) if k[0]==direction and int(k[1])==on and k[3]==method and k[4]==arm]
                        assert len(ix)==plan['label_M'];pred=expit(X@coefs[ix].T).T
                        variance=float(pred.var(axis=0,ddof=1).mean());bias=float(np.mean((pred.mean(axis=0)-truth)**2))-variance/len(ix);total=float(np.mean((pred-truth)**2))
                        expected=f[(f.arm==arm)&(f.direction==direction)&(f.ordinary_n==on)&(f.method==method)].risk.mean()
                        maxrisk=max(maxrisk,abs(expected-total));assert maxrisk<1e-13
                        rows.append({'arm':arm,'direction':direction,'ordinary_n':on,'method':method,'bias':bias,'variance':variance,'total':total})
        q=pd.DataFrame(rows)
        for arm in plan['arms']:
            a=q[q.arm==arm].set_index(['direction','ordinary_n','method']);out={'world_id':world,'arm':arm}
            for component in ['bias','variance','total']:
                v={(g,n):float(a.loc[(g,n,'OrdinaryOnly'),component]-a.loc[(g,n,'D-only'),component]) for g in ['target','irrelevant'] for n in [500,4000]}
                out[component]=(v['irrelevant',4000]-v['irrelevant',500])-(v['target',4000]-v['target',500])
            assert abs(out['total']-out['bias']-out['variance'])<1e-12;components.append(out)
        audits.append({'world_id':world,'maximum_reconstructed_risk_error':maxrisk,'max_baseline_prediction_difference_high_accuracy':comp['max_baseline_prediction_difference_high_accuracy']})
    return pd.DataFrame(frames),pd.DataFrame(components),audits

def summarize(frame,components,confirmation):
    summary=[]
    # Declared primary family: all arm K values + paired changes from factual.
    arms=frame.arm.unique();family=len(arms)+len(arms)-1
    baseline=frame[frame.arm=='full'].set_index('world_id').K_sub
    for arm,q in frame.groupby('arm'):
        q=q.set_index('world_id');summary.append({'arm':arm,'contrast':'K_sub'}|interval(q.K_sub,family))
        if arm!='full':summary.append({'arm':arm,'contrast':'paired_change_vs_full'}|interval(q.K_sub-baseline,family))
    return pd.DataFrame(summary)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--run',type=Path,required=True);ap.add_argument('--out',type=Path,required=True);a=ap.parse_args()
    assert json.loads((a.run/'completion.json').read_text())['completed'];a.out.mkdir(exist_ok=True,parents=True)
    f,c,audits=world_contrasts(a.run);f.to_csv(a.out/'world_contrasts.csv',index=False);c.to_csv(a.out/'world_bias_variance.csv',index=False)
    s=summarize(f,c,False);s.to_csv(a.out/'summary.csv',index=False)
    f.groupby('arm',as_index=False)[['I_target','I_irrelevant','K_sub']].mean().to_csv(a.out/'direction_components.csv',index=False)
    c.groupby('arm',as_index=False)[['bias','variance','total']].mean().to_csv(a.out/'bias_variance_means.csv',index=False)
    (a.out/'audit.json').write_text(json.dumps({'passed':True,'worlds':len(audits),'audits':audits},indent=2)+'\n')
    print(s.to_string(index=False))

if __name__=='__main__':main()
