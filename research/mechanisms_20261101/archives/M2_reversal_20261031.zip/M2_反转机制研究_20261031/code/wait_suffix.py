from pathlib import Path
import time,subprocess,sys
R=Path(__file__).resolve().parent
while not (R/'confirmation_LR/look_1_execution_complete.json').exists():time.sleep(5)
with (R/'suffix_localization.log').open('w') as f:
 p=subprocess.run([sys.executable,str(R/'localize_suffix.py')],stdout=f,stderr=subprocess.STDOUT)
assert p.returncode==0
