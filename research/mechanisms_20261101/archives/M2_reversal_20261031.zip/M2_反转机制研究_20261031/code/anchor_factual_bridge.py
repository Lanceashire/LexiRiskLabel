"""Pre-data extension: factual full-XGB comparator on the independent anchor cohort."""
from study_v3 import *
from xgboost import XGBClassifier
from scipy.stats import t
import subprocess,os,concurrent.futures

def worker(world):
    source=HERE/'xgb_anchor_independent'/f'w{world}';out=HERE/'anchor_factual_bridge'/f'w{world}'
    if (out/'complete.json').exists():return
    out.mkdir(parents=True,exist_ok=True);cfg=json.loads((SOURCE/'mechanism_protocol.json').read_text())['pilot'];plan=json.loads((HERE/'confirmation_master.json').read_text())['XGB'];plan['label_M']=2;plan['label_start']=11000
    with np.load(source/'inputs.npz') as z:a={k:z[k] for k in z.files}
    previous=pd.read_csv(source/'risks.csv').set_index(['direction','ordinary_n','replicate','method']);rows=[];pred=[];keys=[]
    for d in ['target','irrelevant']:
        for n in [500,4000]:
            O=a[f'O_{d}_{n}'];s=type('State',(),{'ordinary_x':O,'candidate_x':a['C']})()
            for rep in [11000,11001]:
                yo,yc=hidden_draw(world,rep,s,cfg,plan['label_tag'])
                for method,idx in [('OrdinaryOnly',np.empty(0,int)),('D-only',a['selected_indices'])]:
                    x=np.vstack([a['D'],O,a['C'][idx]]);y=np.r_[a['yD'],yo,yc[idx]];old=previous.loc[d,n,rep,method];assert digest(x)==old.train_x_hash and digest(y)==old.train_y_hash
                    model=XGBClassifier(**cfg['xgb'],random_state=world+7000,objective='binary:logistic',eval_metric='logloss');model.fit(x[:,1:].astype(np.float32),y)
                    backend=json.loads(model.get_booster().save_config())['learner']['generic_param']['device'];assert backend.startswith('cuda')
                    p=model.predict_proba(a['X_eval'][:,1:].astype(np.float32))[:,1];risk=float(np.mean((p.astype(float)-a['p_eval'])**2));pred.append(p);keys.append(f'{d}|{n}|{rep}|{method}');rows.append({'world_id':world,'direction':d,'ordinary_n':n,'replicate':rep,'method':method,'factual':risk,'train_x_hash':digest(x),'train_y_hash':digest(y),'backend':backend})
    pd.DataFrame(rows).to_csv(out/'risks.csv',index=False);np.savez_compressed(out/'predictions.npz',keys=np.array(keys),prediction=np.array(pred,dtype=np.float32));write_json(out/'complete.json',{'world_id':world,'completed':True,'CUDA_fits':len(rows),'identical_training_inputs_and_labels_to_anchor_branches':True})

def analyze():
    out=HERE/'anchor_factual_bridge';data=[];root=HERE/'xgb_anchor_independent'
    for w in range(1010001,1011025):
        f=pd.read_csv(out/f'w{w}/risks.csv');g=pd.read_csv(root/f'w{w}/risks.csv');data.append(f.merge(g,on=['world_id','direction','ordinary_n','replicate','method'],suffixes=('_factual','_treated'),validate='one_to_one'))
    f=pd.concat(data,ignore_index=True);worlds=[]
    for w,g in f.groupby('world_id'):
        q=g.groupby(['direction','ordinary_n','method'])[['factual','unanchored','anchored']].mean();r={'world_id':w}
        for arm in ['factual','unanchored','anchored']:
            I={d:q.loc[d,4000,'OrdinaryOnly'][arm]-q.loc[d,4000,'D-only'][arm]-q.loc[d,500,'OrdinaryOnly'][arm]+q.loc[d,500,'D-only'][arm] for d in ['target','irrelevant']};r[arm]=I['irrelevant']-I['target']
        worlds.append(r)
    g=pd.DataFrame(worlds);g.to_csv(out/'world_contrasts.csv',index=False);summary=[]
    for name,x in [('factual',g.factual),('anchored_minus_factual',g.anchored-g.factual),('unanchored_minus_factual',g.unanchored-g.factual)]:
        se=x.std(ddof=1)/np.sqrt(1024);rad=t.ppf(1-.01/(2*24),1023)*se;summary.append({'contrast':name,'n_worlds':1024,'mean':x.mean(),'low':x.mean()-rad,'high':x.mean()+rad})
    pd.DataFrame(summary).to_csv(out/'summary.csv',index=False)
    write_json(out/'audit.json',{'passed':True,'worlds':1024,'extra_CUDA_fits':16384,'shared_family_with_anchor_diagnostic':24,'alpha':.01,'registered_before_new_anchor_data_collection':True,'no_new_worlds_added_for_this_comparator':True,'all_paired_training_inputs_labels_and_selections_identical':True})

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--shard',type=int);a=ap.parse_args();reg=json.loads((HERE/'anchor_factual_bridge_registration.json').read_text());assert sha(Path(__file__))==reg['source_sha256']
    if a.shard is not None:
        for w in list(range(1010001,1011025))[a.shard::8]:worker(w)
        return
    while not (HERE/'xgb_anchor_independent/audit.json').exists():time.sleep(5)
    def run(i):
        with (HERE/f'anchor_factual_bridge_shard_{i}.log').open('w') as f:p=subprocess.run([sys.executable,str(Path(__file__)),'--shard',str(i)],env=os.environ.copy(),stdout=f,stderr=subprocess.STDOUT)
        assert p.returncode==0,i
    with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:list(pool.map(run,range(8)))
    analyze();print('FACTUAL_BRIDGE_COMPLETE',flush=True)
if __name__=='__main__':main()
