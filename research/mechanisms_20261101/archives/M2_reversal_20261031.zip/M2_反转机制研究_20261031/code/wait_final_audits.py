from pathlib import Path
import time,subprocess,sys
R=Path(__file__).resolve().parent
while not (R/'hist_precision/execution_complete.json').exists():time.sleep(5)
with (R/'additional_independent_audit.log').open('w') as f:
 p=subprocess.run([sys.executable,str(R/'audit_additional.py')],stdout=f,stderr=subprocess.STDOUT)
assert p.returncode==0
