"""Portable verification: numpy/pandas/scipy, no GPU or original workspace."""
from pathlib import Path
import hashlib,json
import numpy as np
import pandas as pd
from scipy.stats import t
R=Path(__file__).resolve().parent.parent

def interval(x,alpha,family,looks=1):
    x=np.asarray(x);se=x.std(ddof=1)/np.sqrt(len(x));rad=t.ppf(1-alpha/(2*family*looks),len(x)-1)*se
    return np.array([x.mean(),x.mean()-rad,x.mean()+rad])

def compare(values,row,alpha,family,looks=1):
    actual=interval(values,alpha,family,looks);expected=np.array([row['mean'],row['low'],row['high']]);err=float(np.max(np.abs(actual-expected)));assert err<1e-12,(actual,expected);return err

def primary(worlds,summary,learner):
    p=worlds.pivot(index='world_id',columns='arm',values='K_sub');values={}
    for arm in p:
        values[arm,'K_sub']=p[arm]
        if arm!='full':values[arm,'paired_change_vs_full']=p[arm]-p.full
    values['resampled_D_coupled','coupled_minus_decoupled']=p.resampled_D_coupled-p.independent_D_labels
    values['drop_z2','drop_z2_minus_drop_z3']=p.drop_z2-p.drop_z3
    if learner=='LR':values['business_by_redundancy','factorial_interaction']=p.known_all_nuisance-p.drop_both-p.known_business+p.full
    family=30 if learner=='LR' else 17;assert len(values)==len(summary)==family
    return max(compare(values[r.arm,r.contrast],r._asdict(),.025,family,2) for r in summary.itertuples())

def main():
    manifest=json.loads((R/'SHA256_MANIFEST.json').read_text())
    for name,digest in manifest.items():assert hashlib.sha256((R/name).read_bytes()).hexdigest()==digest,name
    worst=0.;tables=R/'tables'
    for learner,n in [('LR',4096),('XGB',1024)]:
        f=pd.read_csv(tables/f'{learner}_worlds.csv');s=pd.read_csv(tables/f'{learner}_primary_summary.csv');assert f.world_id.nunique()==n
        assert np.max(np.abs(f.K_sub-f.I_irrelevant+f.I_target))<1e-12
        worst=max(worst,primary(f,s,learner))
        first=pd.read_csv(tables/f'{learner}_first_look_worlds.csv');ss=pd.read_csv(tables/f'{learner}_first_look_summary.csv');worst=max(worst,primary(first,ss,learner))
        c=pd.read_csv(tables/f'{learner}_bias_variance_worlds.csv');p=c.pivot(index=['world_id','arm'],columns='component',values='K_sub');assert np.max(np.abs(p.total-p.bias-p.variance))<1e-12
    trace=pd.read_csv(tables/'LR_linearization_worlds.csv');p=trace.pivot(index='world_id',columns='component',values='K_sub')
    assert np.max(np.abs(p.actual-p.one_step_score_risk-p.parameter_linearization_gap-p.link_linearization_gap))<1e-12
    assert np.max(np.abs(p.actual-p.business_parameter_shapley-p.signal_parameter_shapley))<1e-12
    region=pd.read_csv(tables/'domain_worlds.csv');s=pd.read_csv(tables/'domain_summary.csv');assert region.world_id.nunique()==3072 and set(region.world_id)==set(range(1001025,1004097))
    for row in s.itertuples():
        q=region[(region.region==row.region)&(region.component==row.component)];worst=max(worst,compare(q[row.contrast],row._asdict(),.05,24))
    full=pd.read_csv(tables/'LR_worlds.csv').query("arm == 'full'").set_index('world_id')
    q=region.query("component == 'actual'").groupby('world_id')[['I_target','I_irrelevant','K_sub']].sum();assert np.max(np.abs(q-full.loc[q.index,q.columns]))<1e-12
    mix=json.loads((R/'verification/mixture_boundary.json').read_text());a=s.query("region == 'ordinary_support' and component == 'actual' and contrast == 'K_sub'").iloc[0];b=s.query("region == 'outside_ordinary_support' and component == 'actual' and contrast == 'K_sub'").iloc[0]
    A=np.array([a['mean'],a.low,a.high])*1.5;B=np.array([b['mean'],b.low,b.high])*3
    assert np.max(np.abs(A-mix['conditional_K_ordinary']))<1e-12 and np.max(np.abs(B-mix['conditional_K_outside']))<1e-12
    assert abs(A[0]/(A[0]-B[0])-mix['estimated_sign_change_fraction'])<1e-12
    anchor=pd.read_csv(tables/'anchor_worlds.csv');p=anchor.pivot(index='world_id',columns='component',values='K_sub');s=pd.read_csv(tables/'anchor_summary.csv')
    assert np.max(np.abs(p.unanchored-p.level_shapley-p.shape_shapley))<1e-12
    for arm in ['unanchored','anchored']:assert np.max(np.abs(p[arm+'_total']-p[arm+'_bias']-p[arm+'_variance']))<1e-12
    for row in s.itertuples():
        if row.component=='anchored_minus_unanchored':x=p.anchored-p.unanchored
        elif row.component.startswith('paired_'):
            c=row.component[len('paired_'):];x=p['anchored_'+c]-p['unanchored_'+c]
        else:x=anchor[anchor.component==row.component][row.contrast]
        worst=max(worst,compare(x,row._asdict(),.01,24))
    bridge=pd.read_csv(tables/'anchor_factual_worlds.csv');s=pd.read_csv(tables/'anchor_factual_summary.csv')
    for row in s.itertuples():
        x=bridge.factual if row.contrast=='factual' else bridge.anchored-bridge.factual if row.contrast=='anchored_minus_factual' else bridge.unanchored-bridge.factual;worst=max(worst,compare(x,row._asdict(),.01,24))
    hist=pd.read_csv(tables/'hist_worlds.csv');s=pd.read_csv(tables/'hist_summary.csv');v={k:hist[k] for k in ['full256','full8192','calibrated256','calibrated8192']}
    v.update(full_histogram_change=hist.full8192-hist.full256,calibrated_histogram_change=hist.calibrated8192-hist.calibrated256,calibration_change_256=hist.calibrated256-hist.full256,calibration_change_8192=hist.calibrated8192-hist.full8192)
    for row in s.itertuples():worst=max(worst,compare(v[row.contrast],row._asdict(),.01,8))
    precision=pd.read_csv(tables/'precision_worlds.csv');audit=json.loads((R/'verification/baseline_refinement_audit.json').read_text());assert abs(precision.K_difference.mean()-audit['mean_K_difference'])<1e-14
    assert abs(precision.K_frozen.mean()-full.K_sub.mean())<1e-14
    result={'passed':True,'manifest_files':len(manifest),'main_primary_contrasts_recomputed':47,'both_registered_looks_recomputed':True,'domain_intervals_recomputed':24,'independent_anchor_and_factual_intervals_recomputed':21,'histogram_intervals_recomputed':8,'maximum_interval_error':worst,'exact_accounting_and_domain_partition_verified':True,'mean_K_precision_change_verified':True,'no_GPU_or_original_absolute_paths_needed':True}
    print(json.dumps(result,indent=2))
if __name__=='__main__':main()
