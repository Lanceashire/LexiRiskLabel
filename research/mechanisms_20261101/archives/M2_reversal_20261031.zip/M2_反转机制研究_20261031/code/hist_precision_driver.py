from pathlib import Path
import subprocess,sys,os,json,hashlib,concurrent.futures
import pandas as pd
import numpy as np
from scipy.stats import t
R=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
    reg=json.loads((R/'hist_precision_registration.json').read_text());assert all(sha(p)==h for p,h in reg['sources'].items());out=R/'hist_precision';out.mkdir(exist_ok=True)
    def run(i):
        with (out/f'shard_{i}.log').open('w') as f:p=subprocess.run([sys.executable,str(R/'xgb_hist_precision.py'),'--plan',str(R/f'hist_precision_protocols/shard_{i}.json'),'--out',str(out/f'shard_{i}'),'--workers','1'],env=os.environ.copy(),stdout=f,stderr=subprocess.STDOUT)
        assert p.returncode==0,i
    with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:list(pool.map(run,range(8)))
    rows=[]
    for d in sorted(out.glob('shard_*/w[0-9]*')):
        if not d.name[1:].isdigit():continue
        assert json.loads((d/'complete.json').read_text())['completed'];world=int(d.name[1:]);f=pd.read_csv(d/'risks.csv');q=f.groupby(['arm','direction','ordinary_n','method']).risk.mean();r={'world_id':world}
        for arm in ['full256','full8192','calibrated256','calibrated8192']:
            I={g:q[arm,g,4000,'OrdinaryOnly']-q[arm,g,4000,'D-only']-q[arm,g,500,'OrdinaryOnly']+q[arm,g,500,'D-only'] for g in ['target','irrelevant']};r[arm]=I['irrelevant']-I['target']
        rows.append(r)
    assert len(rows)==512;f=pd.DataFrame(rows);f.to_csv(out/'world_contrasts.csv',index=False);raw=[(k,f[k]) for k in ['full256','full8192','calibrated256','calibrated8192']]
    raw += [('full_histogram_change',f.full8192-f.full256),('calibrated_histogram_change',f.calibrated8192-f.calibrated256),('calibration_change_256',f.calibrated256-f.full256),('calibration_change_8192',f.calibrated8192-f.full8192)]
    summary=[]
    for name,x in raw:
        se=x.std(ddof=1)/np.sqrt(512);radius=t.ppf(1-.01/(2*8),511)*se;summary.append({'contrast':name,'worlds':512,'mean':x.mean(),'low':x.mean()-radius,'high':x.mean()+radius})
    pd.DataFrame(summary).to_csv(out/'summary.csv',index=False)
    assert all(sha(p)==h for p,h in reg['sources'].items())
    (out/'execution_complete.json').write_text(json.dumps({'completed':True,'worlds':512,'CUDA_fits':32768,'family':8,'alpha':.01,'sources_unchanged':True,'independent_world_range':[1020001,1020512],'M3_started':False},indent=2)+'\n');print(pd.DataFrame(summary).to_string(index=False),flush=True)
if __name__=='__main__':main()
