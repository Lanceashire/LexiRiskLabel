from pathlib import Path
import json,time,sys,subprocess,concurrent.futures,os
R=Path(__file__).resolve().parent

def main(learner):
    complete=R/f'confirmation_{learner}/look_0_execution_complete.json'
    while not complete.exists():time.sleep(5)
    assert json.loads(complete.read_text())['completed']
    out=R/f'analysis_{learner}_look0';log=R/f'analysis_{learner}_look0.log'
    print('START registered analysis',learner,flush=True)
    with log.open('w') as f:
        p=subprocess.run([sys.executable,str(R/'analyze_confirmation.py'),'--master',str(R/'look_0_master.json'),'--learner',learner,'--run',str(R/f'confirmation_{learner}'),'--out',str(out)],env=os.environ.copy(),stdout=f,stderr=subprocess.STDOUT)
    assert p.returncode==0,(learner,str(log))
    print('PASS registered analysis',learner,flush=True)
if __name__=='__main__':
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        list(pool.map(main,['LR','XGB']))
