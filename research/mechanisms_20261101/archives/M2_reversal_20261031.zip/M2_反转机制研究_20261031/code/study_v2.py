"""M2 reversal interventions, with frozen factual selection and paired labels."""
from pathlib import Path
import sys, json, copy, time, argparse, hashlib
import numpy as np
import pandas as pd
from scipy.special import expit
from scipy.linalg import solve

SOURCE=Path('LOCAL_WORKSPACE/2026-10-31/zhe/work/LexiRiskLabel/experiments/mechanism_v2')
sys.path.insert(0,str(SOURCE))
from run_paired_mechanism_states import generate,action_family,frozen,digest,sha,write_json
from evaluate_frozen_family import target,hidden_draw
from stage_gate import require_stage

HERE=Path(__file__).resolve().parent
ARMS={'full':([0,1,2,3,4],1.),'drop_z2':([0,1,2,4],1.),
      'drop_z3':([0,1,2,3],1.),'drop_both':([0,1,2],1.),
      'known_business':([2,3,4],1.),'known_all_nuisance':([2],1.),
      'ridge_0.1':([0,1,2,3,4],.1),'ridge_10':([0,1,2,3,4],10.),
      'known_intercept':([1,2,3,4],1.),'known_business_slope':([0,2,3,4],1.)}

def objective(x,y,b,offset,ridge):
    v=offset+x@b
    return float(np.sum(np.logaddexp(0,v)-y*v)+ridge*np.dot(b,b)/2)

def newton(x,y,cols,ridge,truth,known_business=False,known_fixed=None):
    """Independent sum-log-loss Newton solver; supports soft Bernoulli labels."""
    fixed=([0,1] if known_business else []) if known_fixed is None else known_fixed
    xx=x[:,cols];offset=x[:,fixed]@truth[fixed] if fixed else np.zeros(len(x))
    b=np.zeros(len(cols));converged=False
    for iteration in range(100):
        p=expit(offset+xx@b);grad=xx.T@(p-y)+ridge*b
        if np.max(np.abs(grad))<1e-8:converged=True;break
        h=xx.T@((p*(1-p))[:,None]*xx)+ridge*np.eye(len(cols))
        step=solve(h,grad,assume_a='pos');loss=objective(xx,y,b,offset,ridge);scale=1.
        while scale>2**-30:
            trial=b-scale*step
            if objective(xx,y,trial,offset,ridge)<=loss-1e-4*scale*np.dot(grad,step)+1e-12:break
            scale/=2
        assert scale>2**-30
        b=trial
        if np.max(np.abs(scale*step))<1e-11:converged=True;break
    residual=float(np.max(np.abs(xx.T@(expit(offset+xx@b)-y)+ridge*b)))
    assert converged and residual<2e-6,(iteration,residual)
    theta=np.zeros(5);theta[cols]=b
    if fixed:theta[fixed]=truth[fixed]
    return theta,residual

def run_world(world,plan,out):
    require_stage('M2');out=Path(out);dest=out/f'w{world}';complete=dest/'complete.json'
    if complete.exists():return json.loads(complete.read_text())
    if dest.exists():dest.rename(out/f'w{world}_interrupted_{time.time_ns()}')
    dest.mkdir();started=time.perf_counter()
    cfg=copy.deepcopy(json.loads((SOURCE/'mechanism_protocol.json').read_text())['pilot'])
    truth=np.array(cfg['truth_theta']);states=generate(world,cfg)[0]
    states=[s for s in states if s[1] in ['target','irrelevant'] and s[3]=='neutral']
    assert len(states)==4
    first=states[0];selected=action_family(first[4],first[7])['D-only'];ev=target(world,plan['eval_tag'],plan['evaluation_n'],cfg)
    s=first[4];cid=first[7]
    lock={'world':world,'selected_indices':selected,'selected_ids':cid[selected],'select_hash':digest(cid[selected]),'D':digest(s.visible_x),'yD':digest(s.visible_y),'C':digest(s.candidate_x),'Q':digest(s.reference_x),'cost':digest(s.cost),'B':s.budget,'all_arms_same_factual_selection':True}
    write_json(dest/'selection_lock.json',lock)
    data={'D':s.visible_x,'yD':s.visible_y,'C':s.candidate_x,'Q':s.reference_x,'cost':s.cost,'B':s.budget,'candidate_ids':cid,'selected_indices':selected,'X_eval':ev[0],'p_eval':ev[1]}
    for row in states:
        sid,direction,on,_,s,*_=row
        assert digest(s.visible_x)==lock['D'] and digest(s.visible_y)==lock['yD'] and digest(s.candidate_x)==lock['C']
        data[f'O_{direction}_{on}']=s.ordinary_x
    np.savez_compressed(dest/'inputs.npz',**data)
    rows=[];coefs=[];keys=[];max_optimizer=0.;max_baseline_pred=0.;max_identity=0.
    for original_id,direction,on,assoc,s,_,_,cid,did,oid,_ in states:
        for rep in range(plan['label_start'],plan['label_start']+plan['label_M']):
            yo,yc=hidden_draw(world,rep,s,cfg,plan['label_tag'])
            for method,indices in [('OrdinaryOnly',np.empty(0,int)),('D-only',selected)]:
                x=np.vstack([s.visible_x,s.ordinary_x,s.candidate_x[indices]])
                y=np.r_[s.visible_y,yo,yc[indices]]
                for arm in plan['arms']:
                    cols,ridge=ARMS[arm]
                    if arm=='full':
                        theta=frozen.fit_logistic(x,y,ridge)
                        if rep==plan['label_start']:
                            exact,residual=newton(x,y,cols,ridge,truth)
                            max_baseline_pred=max(max_baseline_pred,float(np.max(np.abs(expit(ev[0]@theta)-expit(ev[0]@exact)))))
                            max_optimizer=max(max_optimizer,residual)
                    elif arm.startswith('ridge_'):theta=frozen.fit_logistic(x,y,ridge)
                    else:
                        fixed=([0] if arm=='known_intercept' else [1] if arm=='known_business_slope' else [0,1] if arm.startswith('known_') else [])
                        theta,residual=newton(x,y,cols,ridge,truth,known_fixed=fixed)
                        max_optimizer=max(max_optimizer,residual)
                    pred=expit(ev[0]@theta);risk=float(np.mean((pred-ev[1])**2))
                    key=f'{direction}|{on}|{rep}|{method}|{arm}';keys.append(key);coefs.append(theta)
                    rows.append({'world_id':world,'direction':direction,'ordinary_n':on,'replicate':rep,'method':method,'arm':arm,'risk':risk,'train_n':len(y),'train_label_hash':digest(y),'train_x_hash':digest(x),'select_hash':lock['select_hash'] if method=='D-only' else digest(np.empty(0,int))})
        # Deterministic synthetic interventions replace future labels, then D labels.
        if plan.get('soft_label_diagnostics',True):
            for method,indices in [('OrdinaryOnly',np.empty(0,int)),('D-only',selected)]:
                x=np.vstack([s.visible_x,s.ordinary_x,s.candidate_x[indices]])
                for arm in ['future_expected_labels','all_expected_labels']:
                    y=expit(x@truth)
                    if arm=='future_expected_labels':y[:len(s.visible_y)]=s.visible_y
                    theta,residual=newton(x,y,[0,1,2,3,4],1.,truth)
                    max_optimizer=max(max_optimizer,residual);pred=expit(ev[0]@theta)
                    keys.append(f'{direction}|{on}|-1|{method}|{arm}');coefs.append(theta)
                    rows.append({'world_id':world,'direction':direction,'ordinary_n':on,'replicate':-1,'method':method,'arm':arm,'risk':float(np.mean((pred-ev[1])**2)),'train_n':len(y),'train_label_hash':digest(y),'train_x_hash':digest(x),'select_hash':lock['select_hash'] if method=='D-only' else digest(np.empty(0,int))})
    frame=pd.DataFrame(rows);frame.to_csv(dest/'risks.csv',index=False)
    np.savez_compressed(dest/'coefficients.npz',keys=np.array(keys),theta=np.array(coefs))
    # Predictions are exactly reconstructible from saved coefficients and inputs.
    for arm in plan['arms']:
        for direction in ['target','irrelevant']:
            for on in [500,4000]:
                for method in ['OrdinaryOnly','D-only']:
                    ix=[i for i,k in enumerate(keys) if k.split('|')[0]==direction and k.split('|')[1]==str(on) and k.split('|')[3]==method and k.split('|')[4]==arm]
                    pred=expit(ev[0]@np.array(coefs)[ix].T).T
                    variance=pred.var(axis=0,ddof=1);bias=(pred.mean(axis=0)-ev[1])**2-variance/len(ix);total=((pred-ev[1])**2).mean(axis=0)
                    max_identity=max(max_identity,float(np.max(np.abs(total-bias-variance))))
    result={'world_id':world,'completed':True,'rows':len(rows),'seconds':time.perf_counter()-started,'max_custom_score_residual':max_optimizer,'max_baseline_prediction_difference_high_accuracy':max_baseline_pred,'max_bias_variance_identity_error':max_identity,'source_hash':sha(Path(__file__)),'factual_selection_unchanged':True}
    write_json(complete,result);return result

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--plan',type=Path,required=True);ap.add_argument('--out',type=Path,required=True);ap.add_argument('--workers',type=int,default=4);args=ap.parse_args()
    plan=json.loads(args.plan.read_text());args.out.mkdir(parents=True,exist_ok=True)
    from concurrent.futures import ThreadPoolExecutor
    sources={str(p):sha(p) for p in [Path(__file__),args.plan,SOURCE/'stage_gate.py',SOURCE/'stage_governance.json',SOURCE/'mechanism_protocol.json',SOURCE/'run_paired_mechanism_states.py',SOURCE/'evaluate_frozen_family.py',SOURCE.parents[1]/'experiments/research_v2/core.py']}
    registration=args.out/'registration.json'
    if registration.exists():assert json.loads(registration.read_text())['sources']==sources
    else:write_json(registration,{'plan':plan,'sources':sources,'started_utc':pd.Timestamp.now(tz='UTC').isoformat(),'role':plan['role'],'M3_started':False})
    reports=[]
    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        futures=[pool.submit(run_world,w,plan,args.out) for w in plan['world_ids']]
        for future in futures:
            r=future.result();reports.append(r);write_json(args.out/'progress.json',{'completed_worlds':len(reports),'total_worlds':len(plan['world_ids']),'last_world':r['world_id']});print('completed',len(reports),r,flush=True)
    assert all(sha(Path(p))==h for p,h in sources.items())
    write_json(args.out/'completion.json',{'completed':True,'worlds':len(reports),'rows':sum(r['rows'] for r in reports),'reports':reports,'sources_unchanged':True,'M3_started':False})

if __name__=='__main__':main()
