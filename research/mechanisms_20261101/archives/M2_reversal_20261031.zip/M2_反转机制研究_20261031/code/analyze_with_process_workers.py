"""Execute the unchanged frozen analysis with isolated world workers only."""
import multiprocessing as mp
from concurrent.futures import ProcessPoolExecutor
import analyze_confirmation as frozen_analysis

class WorldPool(ProcessPoolExecutor):
    def __init__(self,max_workers=4):
        super().__init__(max_workers=8,mp_context=mp.get_context('fork'))

if __name__=='__main__':
    frozen_analysis.concurrent.futures.ThreadPoolExecutor=WorldPool
    frozen_analysis.main()
