"""Independent high-accuracy refinement of every factual LR fit, no replacement."""
from study_v3 import *
import subprocess,os,concurrent.futures

def one(dest):
    world=int(dest.name[1:]);out=HERE/'baseline_refinement'/f'w{world}'
    if (out/'complete.json').exists():return
    out.mkdir(parents=True,exist_ok=True);cfg=json.loads((SOURCE/'mechanism_protocol.json').read_text())['pilot'];plan=json.loads((HERE/'confirmation_master.json').read_text())['LR']
    with np.load(dest/'inputs.npz') as z:a={k:z[k] for k in z.files}
    with np.load(dest/'coefficients.npz') as z:allkeys=[str(k).split('|') for k in z['keys']];coef=z['theta']
    keys=[];refined=[];rows=[];maxscore=0.;maxrisk=0.;maxprob=0.
    for i,k in enumerate(allkeys):
        d,n,rep,method,arm=k;n=int(n);rep=int(rep)
        if arm!='full':continue
        O=a[f'O_{d}_{n}'];s=type('State',(),{'ordinary_x':O,'candidate_x':a['C']})();yo,yc=hidden_draw(world,rep,s,cfg,plan['label_tag']);idx=a['selected_indices'] if method=='D-only' else np.empty(0,int)
        x=np.vstack([a['D'],O,a['C'][idx]]);y=np.r_[a['yD'],yo,yc[idx]];theta=coef[i].copy()
        for _ in range(8):
            p=expit(x@theta);g=x.T@(p-y)+theta
            if np.max(np.abs(g))<1e-8:break
            H=x.T@((p*(1-p))[:,None]*x)+np.eye(5);theta-=solve(H,g,assume_a='pos')
        residual=float(np.max(np.abs(x.T@(expit(x@theta)-y)+theta)));assert residual<1e-7;maxscore=max(maxscore,residual)
        p=expit(a['X_eval']@coef[i]);q=expit(a['X_eval']@theta);r=float(np.mean((p-a['p_eval'])**2));rr=float(np.mean((q-a['p_eval'])**2));maxrisk=max(maxrisk,abs(rr-r));maxprob=max(maxprob,float(np.max(np.abs(p-q))))
        keys.append('|'.join(k));refined.append(theta);rows.append({'world_id':world,'direction':d,'ordinary_n':n,'replicate':rep,'method':method,'frozen_risk':r,'refined_risk':rr})
    f=pd.DataFrame(rows);f.to_csv(out/'risks.csv',index=False);np.savez_compressed(out/'coefficients.npz',keys=np.array(keys),theta=np.array(refined));values={}
    for col in ['frozen_risk','refined_risk']:
        q=f.groupby(['direction','ordinary_n','method'])[col].mean();I={d:q[d,4000,'OrdinaryOnly']-q[d,4000,'D-only']-q[d,500,'OrdinaryOnly']+q[d,500,'D-only'] for d in ['target','irrelevant']};values[col]=I['irrelevant']-I['target']
    write_json(out/'complete.json',{'world_id':world,'completed':True,'fits':len(rows),'max_score_residual':maxscore,'max_endpoint_risk_difference':maxrisk,'max_probability_difference':maxprob,'K_frozen':values['frozen_risk'],'K_refined':values['refined_risk'],'K_difference':values['refined_risk']-values['frozen_risk']})

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--shard',type=int);a=ap.parse_args();paths=sorted([p for p in (HERE/'confirmation_LR').glob('shard_*/w[0-9]*') if p.name[1:].isdigit() and (p/'complete.json').exists()]);assert len(paths)==4096
    if a.shard is not None:
        for p in paths[a.shard::8]:one(p)
        return
    out=HERE/'baseline_refinement';out.mkdir(exist_ok=True)
    def run(i):
        with (out/f'shard_{i}.log').open('w') as f:p=subprocess.run([sys.executable,str(Path(__file__)),'--shard',str(i)],env=os.environ.copy(),stdout=f,stderr=subprocess.STDOUT)
        assert p.returncode==0,i
    with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:list(pool.map(run,range(8)))
    reports=[json.loads((out/f'w{int(p.name[1:])}/complete.json').read_text()) for p in paths];f=pd.DataFrame(reports);f.to_csv(out/'world_precision_differences.csv',index=False)
    result={'passed':True,'worlds':4096,'all_factual_LR_fits_refined':int(f.fits.sum()),'frozen_risks_and_original_results_unchanged':True,'mean_K_frozen':float(f.K_frozen.mean()),'mean_K_refined':float(f.K_refined.mean()),'mean_K_difference':float(f.K_difference.mean()),'maximum_world_K_difference':float(f.K_difference.abs().max()),'maximum_endpoint_risk_difference':float(f.max_endpoint_risk_difference.max()),'maximum_score_residual':float(f.max_score_residual.max()),'initial_worst_case_tolerance_failure_retained':True,'original_delta':.0001}
    write_json(out/'audit.json',result);print(json.dumps(result),flush=True)

if __name__=='__main__':main()
