"""Read-only independent reconstruction of ancillary prediction ledgers."""
from study_v3 import *
from concurrent.futures import ProcessPoolExecutor
import multiprocessing as mp

def anchor_world(world):
    d=HERE/'xgb_anchor_independent'/f'w{world}';b=HERE/'anchor_factual_bridge'/f'w{world}';cfg=json.loads((SOURCE/'mechanism_protocol.json').read_text())['pilot'];plan=json.loads((HERE/'confirmation_master.json').read_text())['XGB']
    complete=json.loads((d/'complete.json').read_text());assert complete['completed']
    with np.load(d/'inputs.npz') as z:a={k:z[k] for k in z.files}
    with np.load(d/'margins.npz') as z:keys=[str(k).split('|') for k in z['keys']];margin=z['margin'].astype(float);level=z['anchor'];assert np.array_equal(a['p_eval'],z['p'])
    with np.load(b/'predictions.npz') as z:bkeys=[str(k).split('|') for k in z['keys']];bp=z['prediction'].astype(float)
    assert keys==bkeys and len(keys)==16
    X,p=a['X_eval'],a['p_eval'];truth=np.array(cfg['truth_theta']);expected=target(world,plan['eval_tag'],plan['evaluation_n'],cfg);assert np.array_equal(X,expected[0]) and np.array_equal(p,expected[1])
    generated=[s for s in generate(world,cfg)[0] if s[1] in ['target','irrelevant'] and s[3]=='neutral'];s=generated[0][4];assert np.array_equal(a['D'],s.visible_x) and np.array_equal(a['yD'],s.visible_y) and np.array_equal(a['C'],s.candidate_x) and np.array_equal(a['selected_indices'],action_family(s,generated[0][7])['D-only'])
    f=pd.read_csv(d/'risks.csv').set_index(['direction','ordinary_n','replicate','method']);bf=pd.read_csv(b/'risks.csv').set_index(['direction','ordinary_n','replicate','method']);max_anchor=0.;max_unanchored=0.;max_factual=0.;un=[];an=[]
    epsilon=complete['maximum_probability_margin_consistency_error']
    for i,k in enumerate(keys):
        direction,n,rep,method=k;n=int(n);rep=int(rep);row=f.loc[direction,n,rep,method];br=bf.loc[direction,n,rep,method]
        O=a[f'O_{direction}_{n}'];state=next(s[4] for s in generated if s[1]==direction and s[2]==n);assert np.array_equal(state.ordinary_x,O)
        yo,yc=hidden_draw(world,rep,state,cfg,plan['label_tag']);idx=a['selected_indices'] if method=='D-only' else np.empty(0,int);xx=np.vstack([a['D'],O,a['C'][idx]]);yy=np.r_[a['yD'],yo,yc[idx]]
        assert digest(xx)==row.train_x_hash==br.train_x_hash and digest(yy)==row.train_y_hash==br.train_y_hash and row.backend.startswith('cuda') and br.backend.startswith('cuda')
        p0=expit(margin[i]);p1=expit(margin[i]-level[i]);r0=float(np.mean((p0-p)**2));r1=float(np.mean((p1-p)**2));r2=float(np.mean((bp[i]-p)**2));bound=2*epsilon*float(np.mean(np.abs(p0-p)))+epsilon**2+1e-13
        assert abs(r0-row.unanchored)<=bound and abs(r1-row.anchored)<1e-13 and abs(r2-br.factual)<1e-13
        max_anchor=max(max_anchor,abs(r1-row.anchored));max_unanchored=max(max_unanchored,abs(r0-row.unanchored));max_factual=max(max_factual,abs(r2-br.factual));un.append(p0);an.append(p1)
    comp=pd.read_csv(d/'components.csv').set_index(['direction','ordinary_n','method','arm']);max_component=0.
    for direction in ['target','irrelevant']:
        for n in [500,4000]:
            for method in ['OrdinaryOnly','D-only']:
                ix=[i for i,k in enumerate(keys) if k[0]==direction and int(k[1])==n and k[3]==method]
                for name,z in [('unanchored',np.array(un)[ix]),('anchored',np.array(an)[ix])]:
                    variance=float(z.var(axis=0,ddof=1).mean());bias=float(np.mean((z.mean(axis=0)-p)**2))-variance/2;total=float(np.mean((z-p)**2));c=comp.loc[direction,n,method,name];err=max(abs(variance-c.variance),abs(bias-c.bias),abs(total-c.total));max_component=max(max_component,err);assert err<2e-7
    return {'world_id':world,'rows':len(keys),'maximum_anchored_risk_error':max_anchor,'maximum_factual_risk_error':max_factual,'maximum_unanchored_margin_rounding_risk_error':max_unanchored,'maximum_component_error':max_component,'all_training_labels_and_factual_selections_verified':True}

def hist_world(dest):
    cfg=json.loads((SOURCE/'mechanism_protocol.json').read_text())['pilot'];world=int(dest.name[1:]);reg=json.loads((dest.parent/'registration.json').read_text());assert all(sha(Path(p))==h for p,h in reg['sources'].items())
    with np.load(dest/'inputs.npz') as z:a={k:z[k] for k in z.files}
    ev=target(world,reg['plan']['eval_tag'],reg['plan']['evaluation_n'],cfg);assert np.array_equal(a['X_eval'],ev[0]) and np.array_equal(a['p_eval'],ev[1])
    original=[s for s in generate(world,cfg)[0] if s[1] in ['target','irrelevant'] and s[3]=='neutral'];state=original[0][4]
    assert np.array_equal(state.visible_x,a['D']) and np.array_equal(state.visible_y,a['yD']) and np.array_equal(state.candidate_x,a['C']) and np.array_equal(action_family(state,original[0][7])['D-only'],a['selected_indices'])
    with np.load(dest/'predictions.npz') as z:keys=[str(k).split('|') for k in z['keys']];pred=z['prediction'].astype(float)
    f=pd.read_csv(dest/'risks.csv').set_index(['direction','ordinary_n','replicate','method','arm']);error=0.
    for i,k in enumerate(keys):
        d,n,rep,m,arm=k;n=int(n);rep=int(rep);row=f.loc[d,n,rep,m,arm];O=a[f'O_{d}_{n}'];s=type('State',(),{'ordinary_x':O,'candidate_x':a['C']})();yo,yc=hidden_draw(world,rep,s,cfg,reg['plan']['label_tag']);idx=a['selected_indices'] if m=='D-only' else np.empty(0,int);x=np.vstack([a['D'],O,a['C'][idx]]);y=np.r_[a['yD'],yo,yc[idx]]
        assert digest(x)==row.train_x_hash and digest(y)==row.train_label_hash and digest(a['candidate_ids'][idx])==row.select_hash and row.backend.startswith('cuda')
        columns=[2] if arm.startswith('calibrated') else [1,2,3,4];assert digest(x[:,columns].astype(np.float32))==row.training_feature_hash
        if arm.startswith('calibrated'):assert digest((x[:,:2]@np.array(cfg['truth_theta'])[:2]).astype(np.float32))==row.training_offset_hash
        r=float(np.mean((pred[i]-a['p_eval'])**2));error=max(error,abs(r-row.risk));assert error<1e-13
    return {'world_id':world,'rows':len(keys),'max_risk_error':error,'all_training_labels_selections_verified':True}

def main():
    assert (HERE/'anchor_factual_bridge/audit.json').exists() and (HERE/'hist_precision/execution_complete.json').exists()
    with ProcessPoolExecutor(max_workers=8,mp_context=mp.get_context('fork')) as pool:
        anchors=list(pool.map(anchor_world,range(1010001,1011025)));histpaths=sorted([p for p in (HERE/'hist_precision').glob('shard_*/w[0-9]*') if p.name[1:].isdigit()]);assert len(histpaths)==512;hist=list(pool.map(hist_world,histpaths))
    result={'passed':True,'independent_anchor_worlds':1024,'histogram_worlds':512,'maximum_anchored_risk_error':max(r['maximum_anchored_risk_error'] for r in anchors),'maximum_factual_risk_error':max(r['maximum_factual_risk_error'] for r in anchors),'maximum_unanchored_margin_rounding_risk_error':max(r['maximum_unanchored_margin_rounding_risk_error'] for r in anchors),'maximum_histogram_risk_error':max(r['max_risk_error'] for r in hist),'raw_training_labels_and_selections_checked':True,'rounding_tolerance_not_effect_threshold':True,'anchor_audits':anchors,'histogram_audits':hist}
    write_json(HERE/'additional_independent_audit.json',result);print(json.dumps({k:v for k,v in result.items() if not k.endswith('_audits')}),flush=True)
if __name__=='__main__':main()
