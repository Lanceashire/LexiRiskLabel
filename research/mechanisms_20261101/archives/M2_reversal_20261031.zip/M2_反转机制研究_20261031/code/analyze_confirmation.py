"""Frozen independent analysis of reversal interventions; world is the unit."""
from study_v3 import *
from scipy.stats import t
from scipy.special import expit
import concurrent.futures

def ci(x,alpha,family,looks):
    x=np.asarray(x);se=x.std(ddof=1)/np.sqrt(len(x));rad=t.ppf(1-alpha/(2*family*looks),len(x)-1)*se
    return {'n_worlds':len(x),'mean':float(x.mean()),'SE':float(se),'low':float(x.mean()-rad),'high':float(x.mean()+rad)}

def make_contrast(frame,value):
    p=frame.pivot(index=['world_id','arm'],columns=['direction','ordinary_n','method'],values=value)
    it=p['target',4000,'OrdinaryOnly']-p['target',4000,'D-only']-p['target',500,'OrdinaryOnly']+p['target',500,'D-only']
    ii=p['irrelevant',4000,'OrdinaryOnly']-p['irrelevant',4000,'D-only']-p['irrelevant',500,'OrdinaryOnly']+p['irrelevant',500,'D-only']
    return pd.DataFrame({'I_target':it,'I_irrelevant':ii,'K_sub':ii-it}).reset_index()

def audit_world(dest,plan,learner):
    cfg=json.loads((SOURCE/'mechanism_protocol.json').read_text())['pilot'];truth=np.array(cfg['truth_theta']);world=int(dest.name[1:])
    with np.load(dest/'inputs.npz') as z:a={k:z[k] for k in z.files}
    X,p=a['X_eval'],a['p_eval'];ev=target(world,plan['eval_tag'],plan['evaluation_n'],cfg)
    assert np.array_equal(X,ev[0]) and np.array_equal(p,ev[1])
    lock=json.loads((dest/'selection_lock.json').read_text());f=pd.read_csv(dest/'risks.csv');expected_rows=(len(plan['arms'])*plan['label_M']+2 if learner=='LR' else len(plan['arms'])*plan['label_M'])*8
    assert len(f)==expected_rows and not f.duplicated(['direction','ordinary_n','replicate','method','arm']).any()
    assert digest(a['candidate_ids'][a['selected_indices']])==lock['select_hash'];assert a['cost'][a['selected_indices']].sum()<=float(a['B'])+1e-10
    generated=[s for s in generate(world,cfg)[0] if s[1] in ['target','irrelevant'] and s[3]=='neutral']
    for _,direction,on,_,s,*_ in generated:
        assert np.array_equal(s.visible_x,a['D']) and np.array_equal(s.visible_y,a['yD']) and np.array_equal(s.candidate_x,a['C']) and np.array_equal(s.ordinary_x,a[f'O_{direction}_{on}'])
    s=generated[0][4];assert np.array_equal(action_family(s,a['candidate_ids'])['D-only'],a['selected_indices'])
    dlabels,dsets,dlocks=resampled_D(world,plan,s,a['candidate_ids'],truth)
    for rep in dlabels:assert np.array_equal(a[f'yD_resampled_{rep}'],dlabels[rep]) and np.array_equal(a[f'S_resampled_{rep}'],dsets[rep])
    if learner=='LR':
        with np.load(dest/'coefficients.npz') as z:keys=[str(k).split('|') for k in z['keys']];theta=z['theta']
        prediction=expit(X@theta.T).T
    else:
        with np.load(dest/'predictions.npz') as z:keys=[str(k).split('|') for k in z['keys']];prediction=z['prediction'].astype(float)
        assert set(f.backend)=={'cuda:0'}
    assert len(keys)==len(f)
    lookup={(k[0],int(k[1]),int(k[2]),k[3],k[4]):i for i,k in enumerate(keys)};assert len(lookup)==len(keys)
    labelcache={};hashcache={};maxerror=0.;records=[];decomposed=[];trace=[]
    # Validate all reconstructed inputs/labels and the fitted feature intervention.
    for row in f.itertuples():
        direction,on,rep,method,arm=row.direction,row.ordinary_n,row.replicate,row.method,row.arm
        indices=a[f'S_resampled_{rep}'] if arm=='resampled_D_coupled' and method=='D-only' else a['selected_indices'] if method=='D-only' else np.empty(0,int)
        O=a[f'O_{direction}_{on}'];s0=next(s[4] for s in generated if s[1]==direction and s[2]==on)
        labelkey=(direction,on,rep)
        if rep!=-1 and labelkey not in labelcache:labelcache[labelkey]=hidden_draw(world,rep,s0,cfg,plan['label_tag'])
        x=np.vstack([a['D'],O,a['C'][indices]])
        if rep==-1:
            y=expit(x@truth)
            if arm=='future_expected_labels':y[:len(a['D'])]=a['yD']
        else:
            yo,yc=labelcache[labelkey];yd=a[f'yD_resampled_{rep}'] if arm in ['independent_D_labels','resampled_D_coupled'] else a['yD'];y=np.r_[yd,yo,yc[indices]]
        assert digest(x)==row.train_x_hash and digest(y)==row.train_label_hash and digest(a['candidate_ids'][indices])==row.select_hash and len(y)==row.train_n
        index=lookup[direction,on,rep,method,arm];pred=prediction[index];risk=float(np.mean((pred-p)**2));maxerror=max(maxerror,abs(risk-row.risk));assert maxerror<1e-13
        if learner=='XGB':
            from xgb_study_v3 import XARMS
            cols,offset=XARMS[arm];assert digest(x[:,cols].astype(np.float32))==row.training_feature_hash
            if offset:assert digest((x[:,:2]@truth[:2]).astype(np.float32))==row.training_offset_hash
        elif arm.startswith('known_'):
            fixed=[0] if arm=='known_intercept' else [1] if arm=='known_business_slope' else [0,1]
            assert np.array_equal(theta[index,fixed],truth[fixed])
        if learner=='LR' and arm=='full':
            actual=theta[index];w=p*(1-p);linear_actual=float(np.mean((w*(X@(actual-truth)))**2))
            pt=expit(x@truth);h=x.T@((pt*(1-pt))[:,None]*x)+np.eye(5);score=x.T@(y-pt)-truth;one=solve(h,score,assume_a='pos');linear_score=float(np.mean((w*(X@one))**2))
            btrue=X[:,:2]@truth[:2];best=X[:,:2]@actual[:2];ztrue=X[:,2]*truth[2];zest=X[:,2]*actual[2]
            rb=float(np.mean((expit(btrue+zest)-p)**2));rz=float(np.mean((expit(best+ztrue)-p)**2))
            bsh=(risk+rz-rb)/2;zsh=(risk+rb-rz)/2
            assert abs(bsh+zsh-risk)<1e-12
            trace.append({'world_id':world,'arm':'full','direction':direction,'ordinary_n':on,'method':method,'replicate':rep,'actual':risk,'one_step_score_risk':linear_score,'actual_coefficients_linear_link_risk':linear_actual,'parameter_linearization_gap':linear_actual-linear_score,'link_linearization_gap':risk-linear_actual,'business_parameter_shapley':bsh,'signal_parameter_shapley':zsh,'business_only_error':rz,'signal_only_error':rb})
    grouped=f.groupby(['world_id','arm','direction','ordinary_n','method'],as_index=False).risk.mean();contrast=make_contrast(grouped,'risk')
    for arm in plan['arms']:
        for direction in ['target','irrelevant']:
            for on in [500,4000]:
                for method in ['OrdinaryOnly','D-only']:
                    ix=[i for i,k in enumerate(keys) if k[0]==direction and int(k[1])==on and k[3]==method and k[4]==arm]
                    pred=prediction[ix];assert len(ix)==plan['label_M']
                    v=float(pred.var(axis=0,ddof=1).mean());b=float(np.mean((pred.mean(axis=0)-p)**2))-v/len(ix);r=float(np.mean((pred-p)**2));assert abs(r-b-v)<1e-12
                    records.append({'world_id':world,'arm':arm,'direction':direction,'ordinary_n':on,'method':method,'bias':b,'variance':v,'total':r})
    components=pd.DataFrame(records);cc=[]
    for component in ['bias','variance','total']:
        q=make_contrast(components,component);q['component']=component;cc.append(q)
    trace_result=[]
    if trace:
        g=pd.DataFrame(trace).groupby(['world_id','arm','direction','ordinary_n','method'],as_index=False).mean(numeric_only=True)
        for name in [k for k in trace[0] if k not in ['world_id','arm','direction','ordinary_n','method','replicate']]:
            q=make_contrast(g,name);q['component']=name;trace_result.append(q)
    return contrast,pd.concat(cc,ignore_index=True),pd.concat(trace_result,ignore_index=True) if trace_result else pd.DataFrame(),{'world_id':world,'rows':len(f),'maximum_reconstructed_risk_error':maxerror,'all_labels_features_selections_offsets_verified':True}

def primary(frame,learner):
    p=frame.pivot(index='world_id',columns='arm',values='K_sub');rows=[]
    for arm in p.columns:
        rows.append((arm,'K_sub',p[arm]))
        if arm!='full':rows.append((arm,'paired_change_vs_full',p[arm]-p.full))
    rows.append(('resampled_D_coupled','coupled_minus_decoupled',p.resampled_D_coupled-p.independent_D_labels))
    rows.append(('drop_z2','drop_z2_minus_drop_z3',p.drop_z2-p.drop_z3))
    if learner=='LR':rows.append(('business_by_redundancy','factorial_interaction',p.known_all_nuisance-p.drop_both-p.known_business+p.full))
    return rows

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--master',type=Path,required=True);ap.add_argument('--learner',choices=['LR','XGB'],required=True);ap.add_argument('--run',type=Path,required=True);ap.add_argument('--out',type=Path,required=True);a=ap.parse_args()
    master=json.loads(a.master.read_text());plan=master[a.learner];worlds=plan['world_ids'];assert len(worlds) in master['looks'][a.learner]
    # A complete declared look is required; partial worlds are never analyzed.
    paths={int(p.name[1:]):p for p in a.run.glob('shard_*/w[0-9]*') if p.name[1:].isdigit() and (p/'complete.json').exists()};assert set(paths)==set(worlds)
    for p in a.run.glob('shard_*/registration.json'):
        reg=json.loads(p.read_text());assert all(sha(Path(k))==h for k,h in reg['sources'].items())
    a.out.mkdir(exist_ok=True,parents=True);contrasts=[];components=[];traces=[];audits=[]
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        futures=[pool.submit(audit_world,paths[w],plan,a.learner) for w in worlds]
        for i,future in enumerate(futures,1):
            c,b,tr,au=future.result();contrasts.append(c);components.append(b);traces.append(tr);audits.append(au)
            if i%64==0:print('audited',a.learner,i,'/',len(worlds),flush=True)
    f=pd.concat(contrasts,ignore_index=True);b=pd.concat(components,ignore_index=True);tr=pd.concat(traces,ignore_index=True)
    f.to_csv(a.out/'world_contrasts.csv',index=False);b.to_csv(a.out/'world_bias_variance_contrasts.csv',index=False)
    if len(tr):tr.to_csv(a.out/'world_risk_linearization_trace.csv',index=False)
    family=master['families'][a.learner];raw=primary(f,a.learner);assert len(raw)==family
    summary=[]
    for arm,name,values in raw:summary.append({'learner':a.learner,'arm':arm,'contrast':name}|ci(values,.025,family,2))
    pd.DataFrame(summary).to_csv(a.out/'primary_summary.csv',index=False)
    diagnostic=[]
    for component,df in [('bias_variance',b),('linearization_trace',tr)]:
        if not len(df):continue
        for (arm,name),q in df.groupby(['arm','component']):
            for column in ['K_sub','I_target','I_irrelevant']:diagnostic.append({'learner':a.learner,'source':component,'arm':arm,'component':name,'contrast':column}|ci(q[column],.05,256,2))
    pd.DataFrame(diagnostic).to_csv(a.out/'diagnostic_summary.csv',index=False)
    f.groupby('arm',as_index=False)[['I_target','I_irrelevant','K_sub']].mean().to_csv(a.out/'direction_components.csv',index=False)
    report={'passed':True,'learner':a.learner,'worlds':len(worlds),'prediction_rows_reconstructed':sum(x['rows'] for x in audits),'maximum_risk_error':max(x['maximum_reconstructed_risk_error'] for x in audits),'primary_family_size':family,'primary_alpha':.025,'reserved_looks':2,'all_worlds_and_negative_results_retained':True,'source_code_training_labels_selections_and_offsets_verified':True,'M3_started':False,'audits':audits}
    write_json(a.out/'audit.json',report);print(pd.DataFrame(summary).to_string(index=False),flush=True)

if __name__=='__main__':main()
