"""Check worst factual LR optimization discrepancies, without changing fits."""
from study_v3 import *
from concurrent.futures import ThreadPoolExecutor

def one(pair):
    _,dest=pair;world=int(dest.name[1:]);plan=json.loads((HERE/'confirmation_master.json').read_text())['LR'];cfg=json.loads((SOURCE/'mechanism_protocol.json').read_text())['pilot'];truth=np.array(cfg['truth_theta'])
    with np.load(dest/'inputs.npz') as z:a={k:z[k] for k in z.files}
    with np.load(dest/'coefficients.npz') as z:keys=[str(k).split('|') for k in z['keys']];coef=z['theta']
    risks={};maxerr=0.;maxprob=0.
    for i,k in enumerate(keys):
        d,n,rep,method,arm=k;n=int(n);rep=int(rep)
        if arm!='full' or rep!=plan['label_start']:continue
        O=a[f'O_{d}_{n}'];s=type('State',(),{'ordinary_x':O,'candidate_x':a['C']})();yo,yc=hidden_draw(world,rep,s,cfg,plan['label_tag']);idx=a['selected_indices'] if method=='D-only' else np.empty(0,int)
        x=np.vstack([a['D'],O,a['C'][idx]]);y=np.r_[a['yD'],yo,yc[idx]];exact,residual=newton(x,y,[0,1,2,3,4],1.,truth)
        p=expit(a['X_eval']@coef[i]);q=expit(a['X_eval']@exact);rp=float(np.mean((p-a['p_eval'])**2));rq=float(np.mean((q-a['p_eval'])**2));risks[d,n,method]=(rp,rq);maxerr=max(maxerr,abs(rp-rq));maxprob=max(maxprob,float(np.max(np.abs(p-q))))
    K=[]
    for j in [0,1]:
        I={d:risks[d,4000,'OrdinaryOnly'][j]-risks[d,4000,'D-only'][j]-risks[d,500,'OrdinaryOnly'][j]+risks[d,500,'D-only'][j] for d in ['target','irrelevant']};K.append(I['irrelevant']-I['target'])
    return {'world_id':world,'max_prediction_difference':maxprob,'max_endpoint_risk_difference':maxerr,'K_sub_difference':K[1]-K[0]}

def main():
    run=HERE/'confirmation_LR';pairs=[]
    for p in run.glob('shard_*/w[0-9]*/complete.json'):
        if p.parent.name[1:].isdigit():pairs.append((json.loads(p.read_text())['max_baseline_prediction_difference_high_accuracy'],p.parent))
    assert len(pairs)==4096;chosen=sorted(pairs,reverse=True)[:64]
    with ThreadPoolExecutor(max_workers=4) as pool:rows=list(pool.map(one,chosen))
    report={'passed':True,'role':'numerical validation only; no hypothesis selection or replacement','all_worlds_initially_checked':4096,'worst_64_worlds_refitted_with_independent_high_accuracy_solver':True,'max_endpoint_risk_difference':max(r['max_endpoint_risk_difference'] for r in rows),'max_K_difference':max(abs(r['K_sub_difference']) for r in rows),'rows':rows}
    assert report['max_K_difference']<1e-6
    write_json(HERE/'numerical_precision_audit.json',report);print(json.dumps({k:v for k,v in report.items() if k!='rows'}),flush=True)

if __name__=='__main__':main()
