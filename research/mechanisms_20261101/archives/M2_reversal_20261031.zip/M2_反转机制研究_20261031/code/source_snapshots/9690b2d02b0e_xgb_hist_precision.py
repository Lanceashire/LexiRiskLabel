"""Matched XGB interventions; privileged offsets are diagnostic only."""
from study_v3 import *
from xgboost import XGBClassifier
import platform,importlib.metadata,subprocess

XARMS={'full256':([1,2,3,4],False,256),'full8192':([1,2,3,4],False,8192),
       'calibrated256':([2],True,256),'calibrated8192':([2],True,8192)}

def xworld(world,plan,out):
    require_stage('M2');out=Path(out);dest=out/f'w{world}';complete=dest/'complete.json'
    if complete.exists():return json.loads(complete.read_text())
    if dest.exists():dest.rename(out/f'w{world}_interrupted_{time.time_ns()}')
    dest.mkdir();started=time.perf_counter();cfg=copy.deepcopy(json.loads((SOURCE/'mechanism_protocol.json').read_text())['pilot']);truth=np.array(cfg['truth_theta'])
    states=[s for s in generate(world,cfg)[0] if s[1] in ['target','irrelevant'] and s[3]=='neutral'];assert len(states)==4
    first=states[0];s=first[4];cid=first[7];selected=action_family(s,cid)['D-only'];ev=target(world,plan['eval_tag'],plan['evaluation_n'],cfg)
    lock={'world_id':world,'selected_indices':selected,'selected_ids':cid[selected],'select_hash':digest(cid[selected]),'D':digest(s.visible_x),'yD':digest(s.visible_y),'C':digest(s.candidate_x),'cost':digest(s.cost),'B':s.budget,'all_arms_same_factual_selection_except':['resampled_D_coupled']}
    write_json(dest/'selection_lock.json',lock)
    data={'D':s.visible_x,'yD':s.visible_y,'C':s.candidate_x,'Q':s.reference_x,'cost':s.cost,'B':s.budget,'candidate_ids':cid,'selected_indices':selected,'X_eval':ev[0],'p_eval':ev[1]}
    dlabels,dsets,dlocks=resampled_D(world,plan,s,cid,truth)
    write_json(dest/'D_resampling_locks.json',dlocks)
    for rep in dlabels:data[f'yD_resampled_{rep}']=dlabels[rep];data[f'S_resampled_{rep}']=dsets[rep]
    for row in states:data[f'O_{row[1]}_{row[2]}']=row[4].ordinary_x
    np.savez_compressed(dest/'inputs.npz',**data)
    rows=[];keys=[];predictions=[];backends=set()
    for _,direction,on,_,s,_,_,cid,did,oid,_ in states:
        for rep in range(plan['label_start'],plan['label_start']+plan['label_M']):
            yo,yc=hidden_draw(world,rep,s,cfg,plan['label_tag'])
            for method,indices in [('OrdinaryOnly',np.empty(0,int)),('D-only',selected)]:
                x=np.vstack([s.visible_x,s.ordinary_x,s.candidate_x[indices]]);y=np.r_[s.visible_y,yo,yc[indices]]
                for arm in plan['arms']:
                    actual_indices=dsets[rep] if arm=='resampled_D_coupled' and method=='D-only' else indices
                    xx=x;yy=y
                    if arm in ['independent_D_labels','resampled_D_coupled']:
                        xx=np.vstack([s.visible_x,s.ordinary_x,s.candidate_x[actual_indices]])
                        yy=np.r_[dlabels[rep],yo,yc[actual_indices]]
                    cols,offset,bins=XARMS[arm];params=dict(cfg['xgb'],max_bin=bins);model=XGBClassifier(**params,random_state=world+7000,objective='binary:logistic',eval_metric='logloss')
                    fitkw={'base_margin':(xx[:,:2]@truth[:2]).astype(np.float32)} if offset else {}
                    predkw={'base_margin':(ev[0][:,:2]@truth[:2]).astype(np.float32)} if offset else {}
                    model.fit(xx[:,cols].astype(np.float32),yy,**fitkw)
                    backend=json.loads(model.get_booster().save_config())['learner']['generic_param']['device'];assert backend.startswith('cuda');backends.add(backend)
                    pred=model.predict_proba(ev[0][:,cols].astype(np.float32),**predkw)[:,1]
                    key=f'{direction}|{on}|{rep}|{method}|{arm}';keys.append(key);predictions.append(pred)
                    rows.append({'world_id':world,'direction':direction,'ordinary_n':on,'replicate':rep,'method':method,'arm':arm,'risk':float(np.mean((pred.astype(float)-ev[1])**2)),'train_n':len(yy),'train_label_hash':digest(yy),'train_x_hash':digest(xx),'training_feature_hash':digest(xx[:,cols].astype(np.float32)),'training_offset_hash':digest(fitkw['base_margin']) if offset else None,'select_hash':digest(cid[actual_indices]),'backend':backend})
    pd.DataFrame(rows).to_csv(dest/'risks.csv',index=False)
    np.savez_compressed(dest/'predictions.npz',keys=np.array(keys),prediction=np.array(predictions,dtype=np.float32))
    result={'world_id':world,'completed':True,'rows':len(rows),'seconds':time.perf_counter()-started,'actual_CUDA_fits':len(rows),'backends':sorted(backends),'source_hash':sha(Path(__file__)),'factual_selection_unchanged_except_registered_coupling_control':True}
    write_json(complete,result);return result

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--plan',type=Path,required=True);ap.add_argument('--out',type=Path,required=True);ap.add_argument('--workers',type=int,default=4);a=ap.parse_args();plan=json.loads(a.plan.read_text());a.out.mkdir(exist_ok=True,parents=True)
    gpu=subprocess.run(['nvidia-smi','--query-gpu=name,driver_version','--format=csv,noheader'],capture_output=True,text=True);assert gpu.returncode==0
    sources={str(p):sha(p) for p in [Path(__file__),HERE/'study_v3.py',a.plan,SOURCE/'stage_gate.py',SOURCE/'stage_governance.json',SOURCE/'mechanism_protocol.json',SOURCE/'run_paired_mechanism_states.py',SOURCE/'evaluate_frozen_family.py',SOURCE.parents[1]/'experiments/research_v2/core.py']}
    reg=a.out/'registration.json'
    if reg.exists():assert json.loads(reg.read_text())['sources']==sources
    else:write_json(reg,{'plan':plan,'sources':sources,'hardware':gpu.stdout.strip(),'environment':{'python':platform.python_version(),**{k:importlib.metadata.version(k) for k in ['numpy','scipy','scikit-learn','xgboost']}},'started_utc':pd.Timestamp.now(tz='UTC').isoformat(),'M3_started':False})
    from concurrent.futures import ThreadPoolExecutor
    reports=[]
    with ThreadPoolExecutor(max_workers=a.workers) as pool:
        futures=[pool.submit(xworld,w,plan,a.out) for w in plan['world_ids']]
        for future in futures:
            r=future.result();reports.append(r);write_json(a.out/'progress.json',{'completed_worlds':len(reports),'total_worlds':len(plan['world_ids']),'last_world':r['world_id']});print('completed',len(reports),r,flush=True)
    assert all(sha(Path(p))==h for p,h in sources.items())
    write_json(a.out/'completion.json',{'completed':True,'worlds':len(reports),'rows':sum(r['rows'] for r in reports),'reports':reports,'sources_unchanged':True,'M3_started':False})

if __name__=='__main__':main()
