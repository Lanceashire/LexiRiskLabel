"""Fresh-suffix test of residual level calibration in business-offset XGB."""
from study_v3 import *
from xgboost import XGBClassifier
from scipy.stats import t
import subprocess,os,concurrent.futures

def worker(world):
    out=HERE/'xgb_anchor_independent'/f'w{world}'
    if (out/'complete.json').exists():return
    out.mkdir(parents=True,exist_ok=True)
    plan=json.loads((HERE/'confirmation_master.json').read_text())['XGB'];plan['label_M']=2;plan['label_start']=11000
    cfg=json.loads((SOURCE/'mechanism_protocol.json').read_text())['pilot'];truth=np.array(cfg['truth_theta'])
    states=[s for s in generate(world,cfg)[0] if s[1] in ['target','irrelevant'] and s[3]=='neutral'];s=states[0][4];cid=states[0][7];chosen=action_family(s,cid)['D-only'];ev=target(world,plan['eval_tag'],plan['evaluation_n'],cfg)
    a={'D':s.visible_x,'yD':s.visible_y,'C':s.candidate_x,'cost':s.cost,'B':s.budget,'selected_indices':chosen,'candidate_ids':cid,'X_eval':ev[0],'p_eval':ev[1]}
    for row in states:a[f'O_{row[1]}_{row[2]}']=row[4].ordinary_x
    np.savez_compressed(out/'inputs.npz',**a)
    write_json(out/'selection_lock.json',{'world_id':world,'select_hash':digest(cid[chosen]),'selected_indices':chosen,'selected_ids':cid[chosen],'selection_before_future_labels':True})
    X,p=a['X_eval'],a['p_eval'];beval=(X[:,:2]@truth[:2]).astype(np.float32);rows=[];keys=[];margins=[];anchors=[];maxdiff=0.;preds={}
    for d in ['target','irrelevant']:
        for n in [500,4000]:
            O=a[f'O_{d}_{n}'];s=type('Features',(),{'ordinary_x':O,'candidate_x':a['C']})()
            for rep in range(plan['label_start'],plan['label_start']+plan['label_M']):
                yo,yc=hidden_draw(world,rep,s,cfg,plan['label_tag'])
                for method,idx in [('OrdinaryOnly',np.empty(0,int)),('D-only',a['selected_indices'])]:
                    x=np.vstack([a['D'],O,a['C'][idx]]);y=np.r_[a['yD'],yo,yc[idx]];margin=(x[:,:2]@truth[:2]).astype(np.float32)
                    model=XGBClassifier(**cfg['xgb'],random_state=world+7000,objective='binary:logistic',eval_metric='logloss');model.fit(x[:,[2]].astype(np.float32),y,base_margin=margin)
                    backend=json.loads(model.get_booster().save_config())['learner']['generic_param']['device'];assert backend.startswith('cuda')
                    raw=model.predict(X[:,[2]].astype(np.float32),output_margin=True,base_margin=beval)
                    probability=model.predict_proba(X[:,[2]].astype(np.float32),base_margin=beval)[:,1]
                    level=float(model.predict(np.zeros((1,1),np.float32),output_margin=True,base_margin=np.zeros(1,np.float32))[0])
                    anchored=expit(raw.astype(float)-level);original=probability.astype(float);maxdiff=max(maxdiff,float(np.max(np.abs(original-expit(raw.astype(float))))));assert maxdiff<2e-7
                    fullrisk=float(np.mean((original-p)**2));anchorrisk=float(np.mean((anchored-p)**2))
                    shapeoracle=expit(X[:,:2]@truth[:2]+X[:,2]*truth[2]+level);shape_risk=float(np.mean((shapeoracle-p)**2))
                    offset_part=(fullrisk+shape_risk-anchorrisk)/2;shape_part=(fullrisk+anchorrisk-shape_risk)/2
                    rows.append({'world_id':world,'direction':d,'ordinary_n':n,'replicate':rep,'method':method,'unanchored':fullrisk,'anchored':anchorrisk,'level_shapley':offset_part,'shape_shapley':shape_part,'level':level,'train_x_hash':digest(x),'train_y_hash':digest(y),'backend':backend})
                    key=f'{d}|{n}|{rep}|{method}';keys.append(key);margins.append(raw);anchors.append(level);preds[d,n,rep,method]=(original,anchored)
    f=pd.DataFrame(rows);f.to_csv(out/'risks.csv',index=False)
    np.savez_compressed(out/'margins.npz',keys=np.array(keys),margin=np.array(margins,dtype=np.float32),anchor=np.array(anchors),p=p)
    components=[]
    for d in ['target','irrelevant']:
        for n in [500,4000]:
            for method in ['OrdinaryOnly','D-only']:
                for arm,which in [('unanchored',0),('anchored',1)]:
                    z=np.array([preds[d,n,rep,method][which] for rep in range(plan['label_start'],plan['label_start']+plan['label_M'])]);v=float(z.var(axis=0,ddof=1).mean());b=float(np.mean((z.mean(axis=0)-p)**2))-v/len(z);r=float(np.mean((z-p)**2));assert abs(r-v-b)<1e-12
                    components.append({'world_id':world,'direction':d,'ordinary_n':n,'method':method,'arm':arm,'bias':b,'variance':v,'total':r})
    pd.DataFrame(components).to_csv(out/'components.csv',index=False)
    write_json(out/'complete.json',{'completed':True,'world_id':world,'CUDA_fits':len(rows),'maximum_probability_margin_consistency_error':maxdiff,'parent_model_params_features_offset_unchanged':True,'source_sha256':sha(Path(__file__))})

def analyze():
    out=HERE/'xgb_anchor_independent';worlds=list(range(1010001,1011025));rr=[];cc=[];reports=[]
    for w in worlds:
        d=out/f'w{w}';reports.append(json.loads((d/'complete.json').read_text()));rr.append(pd.read_csv(d/'risks.csv'));cc.append(pd.read_csv(d/'components.csv'))
    f=pd.concat(rr,ignore_index=True);c=pd.concat(cc,ignore_index=True);contrasts=[]
    def values(g,col):
        p=g.groupby(['world_id','direction','ordinary_n','method'])[col].mean().unstack(['direction','ordinary_n','method'])
        I={d:p[d,4000,'OrdinaryOnly']-p[d,4000,'D-only']-p[d,500,'OrdinaryOnly']+p[d,500,'D-only'] for d in ['target','irrelevant']}
        return pd.DataFrame({'I_target':I['target'],'I_irrelevant':I['irrelevant'],'K_sub':I['irrelevant']-I['target']})
    for name in ['unanchored','anchored','level_shapley','shape_shapley']:
        v=values(f,name);v['component']=name;contrasts.append(v.reset_index())
    for arm,q in c.groupby('arm'):
        for comp in ['bias','variance','total']:
            v=values(q,comp);v['component']=arm+'_'+comp;contrasts.append(v.reset_index())
    v=pd.concat(contrasts,ignore_index=True);v.to_csv(out/'world_contrasts.csv',index=False);summary=[]
    #24 prespecified diagnostic quantities, with shared/signed component identity.
    for component in ['unanchored','anchored']:
        q=v[v.component==component]
        for col in ['K_sub','I_target','I_irrelevant']:summary.append((component,col,q[col].to_numpy()))
    p=v.pivot(index='world_id',columns='component',values='K_sub')
    summary.append(('anchored_minus_unanchored','K_sub',(p.anchored-p.unanchored).to_numpy()))
    for component in ['level_shapley','shape_shapley','unanchored_bias','unanchored_variance','unanchored_total','anchored_bias','anchored_variance','anchored_total']:summary.append((component,'K_sub',p[component].to_numpy()))
    for comp in ['bias','variance','total']:summary.append(('paired_'+comp,'K_sub',(p['anchored_'+comp]-p['unanchored_'+comp]).to_numpy()))
    assert len(summary)<=24;records=[]
    for component,col,x in summary:
        se=x.std(ddof=1)/np.sqrt(len(x));radius=t.ppf(1-.01/(2*24),len(x)-1)*se;records.append({'component':component,'contrast':col,'n_worlds':len(x),'mean':x.mean(),'low':x.mean()-radius,'high':x.mean()+radius})
    pd.DataFrame(records).to_csv(out/'summary.csv',index=False)
    write_json(out/'audit.json',{'passed':True,'independent_worlds':1024,'no_overlap_with_LR_or_XGB_parent_worlds':True,'family':24,'alpha':.01,'scope':'separate preregistered independent residual-level diagnostic; no replacement of parent primary family','total_extra_CUDA_fits':sum(q['CUDA_fits'] for q in reports),'maximum_probability_margin_consistency_error':max(q['maximum_probability_margin_consistency_error'] for q in reports),'parent_model_params_features_offset_unchanged':True})

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--shard',type=int);a=ap.parse_args();reg=json.loads((HERE/'xgb_anchor_independent_registration.json').read_text());assert sha(Path(__file__))==reg['source_sha256']
    if a.shard is not None:
        for w in list(range(1010001,1011025))[a.shard::8]:worker(w);print('anchor world',w,flush=True)
        return
    while not (HERE/'confirmation_XGB/look_1_execution_complete.json').exists():time.sleep(5)
    def run(i):
        with (HERE/f'xgb_anchor_independent_shard_{i}.log').open('w') as f:p=subprocess.run([sys.executable,str(Path(__file__)),'--shard',str(i)],env=os.environ.copy(),stdout=f,stderr=subprocess.STDOUT)
        assert p.returncode==0,i
    with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:list(pool.map(run,range(8)))
    analyze();print('ANCHOR_DIAGNOSTIC_COMPLETE',flush=True)

if __name__=='__main__':main()
