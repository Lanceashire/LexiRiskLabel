from pathlib import Path
import argparse,subprocess,sys,json,hashlib,time,os,concurrent.futures
HERE=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,x):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);q=p.with_suffix('.tmp');q.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n');q.replace(p)
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--learner',choices=['LR','XGB'],required=True);ap.add_argument('--look',type=int,choices=[0,1],required=True);a=ap.parse_args()
    master=json.loads((HERE/'confirmation_master.json').read_text());reg=json.loads((HERE/'frozen_registration.json').read_text());assert all(sha(p)==h for p,h in reg['source_sha256'].items())
    out=HERE/f'confirmation_{a.learner}';out.mkdir(exist_ok=True)
    n=master['looks'][a.learner][a.look];plans=sorted((HERE/'confirmation_protocols').glob(f'{a.learner}_look{a.look}_shard_*.json'));assert len(plans)==8
    script=HERE/('study_v3.py' if a.learner=='LR' else 'xgb_study_v3.py')
    def run(p):
        child=out/f'shard_look{a.look}_{p.stem[-2:]}'
        with (out/(child.name+'.log')).open('a') as log:
            proc=subprocess.run([sys.executable,str(script),'--plan',str(p),'--out',str(child),'--workers','1'],env=os.environ.copy(),stdout=log,stderr=subprocess.STDOUT)
        assert proc.returncode==0,(p,proc.returncode)
        return {'path':str(child),'worlds':json.loads((child/'completion.json').read_text())['worlds']}
    done=[]
    with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
        futures=[pool.submit(run,p) for p in plans]
        for f in concurrent.futures.as_completed(futures):
            done.append(f.result());write(out/f'look_{a.look}_progress.json',{'completed_shards':len(done),'total_shards':8,'registered_worlds_at_look':n,'no_interim_statistical_tests':True});print('completed shard',a.learner,a.look,len(done),flush=True)
    assert all(sha(p)==h for p,h in reg['source_sha256'].items())
    write(out/f'look_{a.look}_execution_complete.json',{'completed':True,'learner':a.learner,'registered_worlds_at_look':n,'shards':done,'sources_unchanged':True,'M3_started':False})
if __name__=='__main__':main()
