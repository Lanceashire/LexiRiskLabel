"""Exact reweighting of jointly bounded, preregistered regional contrasts."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path(__file__).resolve().parent

def main():
    f=pd.read_csv(R/'suffix_localization/summary.csv')
    a=f[(f.region=='ordinary_support')&(f.component=='actual')&(f.contrast=='K_sub')].iloc[0]
    b=f[(f.region=='outside_ordinary_support')&(f.component=='actual')&(f.contrast=='K_sub')].iloc[0]
    # Original a ~ Uniform[-2,2.2], ordinary support ends at.8: exact masses2/3,1/3.
    A=np.array([a['mean'],a.low,a.high])*1.5;B=np.array([b['mean'],b.low,b.high])*3
    assert A[1]>0 and B[2]<0
    crossing=A[0]/(A[0]-B[0]);lo=A[1]/(A[1]-B[1]);hi=A[2]/(A[2]-B[2]);q=np.linspace(0,1,201)
    mean=(1-q)*A[0]+q*B[0];lower=(1-q)*A[1]+q*B[1];upper=(1-q)*A[2]+q*B[2]
    table=pd.DataFrame({'outside_target_fraction':q,'K_sub':mean,'joint_lower':lower,'joint_upper':upper});table.to_csv(R/'suffix_localization/target_mixture_curve.csv',index=False)
    result={'scope':'mathematical reweighting of two preregistered regional risk estimates, not new training or a new selected test','ordinary_target_mass':2/3,'outside_target_mass':1/3,'conditional_K_ordinary':A.tolist(),'conditional_K_outside':B.tolist(),'estimated_sign_change_fraction':crossing,'joint_bound_for_sign_change_fraction':[lo,hi],'original_fraction_exceeds_joint_upper_threshold':bool(1/3>hi),'joint_coverage_basis':'existing simultaneous24 diagnostic intervals; nonnegative mixture weights preserve joint bounds for every q, including postprocessed q','restriction':'same LR generator, selected sets, ridge, O500-to4000 and target conditional distributions; not a universal fraction'}
    (R/'suffix_localization/mixture_boundary.json').write_text(json.dumps(result,indent=2)+'\n')
    out=R/'figures';out.mkdir(exist_ok=True)
    fig,ax=plt.subplots(figsize=(9,4.8));ax.fill_between(q,lower,upper,color='#2166ac',alpha=.16,label='Band inherited from joint regional bounds');ax.plot(q,mean,color='#2166ac',lw=2,label='Reweighted K_sub');ax.axhline(0,color='black',lw=.8);ax.axvline(1/3,color='#b2182b',ls='--',label='Original target mixture: 1/3 outside');ax.axvline(crossing,color='#777777',ls=':',label=f'Estimated crossing: {crossing:.3f}')
    ax.set(xlabel='Target fraction outside ordinary business-coordinate support',ylabel='LR substitution contrast (excess Brier)',title='The target population mixture can reverse the aggregate contrast\nSame trained models, feedback, costs and exploration sets');ax.legend(fontsize=8);ax.grid(alpha=.2);ax.spines[['top','right']].set_visible(False);fig.tight_layout();fig.savefig(out/'M2_target_mixture_boundary.png',dpi=180);plt.close(fig)
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
