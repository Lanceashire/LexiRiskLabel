from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path(__file__).resolve().parent
O=R/'figures'
def finish(fig,name):fig.tight_layout();fig.savefig(O/name,dpi=180);plt.close(fig)
def main():
    O.mkdir(exist_ok=True);plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False})
    LR=pd.read_csv(R/'analysis_LR_look1_parallel/primary_summary.csv');XGB=pd.read_csv(R/'analysis_XGB_look1/primary_summary.csv')
    fig,axes=plt.subplots(1,2,figsize=(13,5))
    for ax,f,arms,title in [(axes[0],LR,['full','known_business_slope','known_intercept','known_business','known_all_nuisance','drop_both'],'LR / 4,096 worlds'),(axes[1],XGB,['full','known_business','known_business_signal_only','drop_both'],'XGB / 1,024 worlds')]:
        q=f[f.contrast=='K_sub'].set_index('arm').loc[arms]
        for i,(arm,r) in enumerate(q.iterrows()):ax.errorbar(r['mean'],i,xerr=[[r['mean']-r.low],[r.high-r['mean']]],fmt='o',capsize=4,color='#b2182b' if arm=='full' else '#2166ac')
        ax.set_yticks(range(len(q)),arms);ax.invert_yaxis();ax.axvline(0,color='black',lw=.8,ls='--');ax.set(title=title,xlabel='K_sub: excess Brier interaction');ax.grid(axis='x',alpha=.2)
    fig.suptitle('Paired interventions identify business calibration as a contributing mechanism\nFrozen selections; primary simultaneous intervals, including both registered looks',fontsize=12);finish(fig,'M2_calibration_interventions.png')
    d=pd.read_csv(R/'analysis_LR_look1_parallel/diagnostic_summary.csv');s=pd.read_csv(R/'suffix_localization/summary.csv')
    fig,axes=plt.subplots(1,2,figsize=(13,5))
    names=['one_step_score_risk','parameter_linearization_gap','link_linearization_gap','actual'];q=d[(d.source=='linearization_trace')&(d.contrast=='K_sub')].set_index('component').loc[names]
    axes[0].bar(range(4),q['mean'],color=['#777777','#4393c3','#2166ac','#b2182b']);axes[0].errorbar(range(4),q['mean'],yerr=[q['mean']-q.low,q.high-q['mean']],fmt='none',ecolor='black',capsize=3);axes[0].axhline(0,color='black',lw=.8);axes[0].set_xticks(range(4),['One-step\nlinear risk','Parameter\napproximation gap','Probability-link\napproximation gap','Actual\nclassifier risk']);axes[0].set_title('Exact accounting of the approximation failure');axes[0].set_ylabel('Contribution to LR K_sub');axes[0].grid(axis='y',alpha=.2)
    q=s[(s.component=='actual')&(s.contrast=='K_sub')].set_index('region').loc[['ordinary_support','outside_ordinary_support']]
    axes[1].bar(range(2),q['mean'],color=['#2166ac','#b2182b']);axes[1].errorbar(range(2),q['mean'],yerr=[q['mean']-q.low,q.high-q['mean']],fmt='none',ecolor='black',capsize=4);axes[1].axhline(0,color='black',lw=.8);axes[1].set_xticks([0,1],['Within ordinary\nbusiness support','Outside ordinary\nbusiness support']);axes[1].set_title('Where the reversal occurs: 3,072 untouched worlds');axes[1].set_ylabel('Weighted contribution to total-target K_sub');axes[1].grid(axis='y',alpha=.2)
    fig.suptitle('LR reversal: nonlinear prediction risk and target-domain coverage\nThe accounting identity locates the discrepancy; paired interventions supply causal evidence',fontsize=12);finish(fig,'M2_LR_reversal_mechanism.png')
    fig,axes=plt.subplots(1,2,figsize=(13,5))
    for ax,learner,path in [(axes[0],'LR','analysis_LR_look1_parallel'),(axes[1],'XGB','analysis_XGB_look1')]:
        f=pd.read_csv(R/path/'diagnostic_summary.csv');f=f[(f.source=='bias_variance')&(f.contrast=='K_sub')];arms=['full','known_business'];names=['bias','variance','total']
        for j,(name,color) in enumerate(zip(names,['#2166ac','#b2182b','#555555'])):
            q=f[f.component==name].set_index('arm').loc[arms];x=np.arange(2)+(j-1)*.22;ax.bar(x,q['mean'],width=.21,color=color,label=name);ax.errorbar(x,q['mean'],yerr=[q['mean']-q.low,q.high-q['mean']],fmt='none',ecolor=color,capsize=3)
        ax.axhline(0,color='black',lw=.8);ax.set_xticks([0,1],['Factual learner','True business parameters']);ax.set_title(learner);ax.set_ylabel('Conditional contribution to K_sub');ax.legend();ax.grid(axis='y',alpha=.2)
    fig.suptitle('Bias and feedback variance can contribute in opposite directions\nDescriptive simultaneous diagnostic intervals; finite-M unbiased components',fontsize=12);finish(fig,'M2_bias_variance_mechanism.png')
    a=pd.read_csv(R/'xgb_anchor_independent/summary.csv');b=pd.read_csv(R/'anchor_factual_bridge/summary.csv');fig,axes=plt.subplots(1,2,figsize=(13,4.8))
    q=pd.DataFrame([b[b.contrast=='factual'].iloc[0],a[(a.component=='unanchored')&(a.contrast=='K_sub')].iloc[0],a[(a.component=='anchored')&(a.contrast=='K_sub')].iloc[0]])
    axes[0].errorbar(range(3),q['mean'],yerr=[q['mean']-q.low,q.high-q['mean']],fmt='o',capsize=4,color='#2166ac');axes[0].axhline(0,color='black',lw=.8);axes[0].set_xticks(range(3),['Factual full XGB','Known business +\nsignal-only features','Also normalize\nresidual f(0)=0']);axes[0].set_ylabel('K_sub');axes[0].set_title('Independent cohort: 1,024 worlds')
    q=pd.DataFrame([b[b.contrast=='unanchored_minus_factual'].iloc[0],b[b.contrast=='anchored_minus_factual'].iloc[0],a[(a.component=='anchored_minus_unanchored')&(a.contrast=='K_sub')].iloc[0]])
    axes[1].errorbar(range(3),q['mean'],yerr=[q['mean']-q.low,q.high-q['mean']],fmt='o',capsize=4,color='#b2182b');axes[1].axhline(0,color='black',lw=.8);axes[1].set_xticks(range(3),['Calibration + features\nversus factual','Composite normalization\nversus factual','Residual-level correction\nwithin calibrated branch']);axes[1].set_ylabel('Paired change in K_sub');axes[1].set_title('Composite change and residual-level hypothesis')
    fig.suptitle('A scalar residual offset does not establish a complete explanation\nIndependent preregistered diagnosis: alpha .01, family 24; calibrated signs remain unresolved',fontsize=12);finish(fig,'M2_XGB_residual_diagnosis.png')
    h=pd.read_csv(R/'hist_precision/summary.csv').set_index('contrast');fig,axes=plt.subplots(1,2,figsize=(12,4.8))
    for ax,prefix,title in [(axes[0],'full','Factual XGB'),(axes[1],'calibrated','Known business + signal-only features')]:
        q=h.loc[[prefix+'256',prefix+'8192']];ax.errorbar([0,1],q['mean'],yerr=[q['mean']-q.low,q.high-q['mean']],fmt='o',capsize=4,color='#2166ac');ax.axhline(0,color='black',lw=.8);ax.set_xticks([0,1],['max_bin = 256','max_bin = 8,192']);ax.set_title(title);ax.set_ylabel('K_sub');ax.grid(axis='y',alpha=.2)
    fig.suptitle('Independent histogram-precision control: same model depth and boosting rounds\n512 new worlds; alpha .01 across eight registered contrasts',fontsize=12);finish(fig,'M2_XGB_histogram_control.png')
    print('generated',len(list(O.glob('*.png'))),'figures')
if __name__=='__main__':main()
