"""Portable evidence checks; uses NumPy, no model training or GPU."""
from pathlib import Path
from collections import Counter
import csv, gzip, hashlib, json
import numpy as np
from m3_entry_guard import require_m3_entry

ROOT=Path(__file__).resolve().parent
def read(p):return json.loads((ROOT/p).read_text())
def rows(p):
    with (ROOT/p).open() as f:return list(csv.DictReader(f))
def check(ok,message):
    if not ok:raise RuntimeError(message)

def verify():
    manifest=read('SHA256_MANIFEST.json')
    for name,expect in manifest['files'].items():
        check(hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==expect,'Hash mismatch: '+name)
    cfg=read('evidence/M1_bridge/M1_registration.json')['config']
    U=np.array(cfg['candidate_vectors']);HD=np.array(cfg['H_D']);G=np.array(cfg['G'])
    masks=np.arange(2**len(U));bits=(masks[:,None]>>np.arange(len(U)))&1
    additions=np.einsum('mi,ij,ik->mjk',bits,U,U)
    computed={}; fixed_error=0.
    for f in rows('evidence/M1_bridge/M1_fixed_set_values.csv'):
        d=np.array(cfg['directions'][f['direction']]);s=float(f['strength']);H=HD+s*np.outer(d,d)
        gain=float(np.trace(G@(np.linalg.inv(H)-np.linalg.inv(H+np.outer(U[0],U[0])))))
        fixed_error=max(fixed_error,abs(gain-float(f['fixed_u_gain'])))
        computed[f['direction'],s]=np.trace(G@np.linalg.inv(H))-np.einsum('ij,mji->m',G,np.linalg.inv(H+additions))
    check(fixed_error<1e-12,'M1 fixed-value error')
    groups={}; enum_error=0.
    with gzip.open(ROOT/'evidence/M1_bridge/M1_all_subset_values.csv.gz','rt') as file:
        for r in csv.DictReader(file):
            key=r['direction'],float(r['strength']),r['cost_condition']
            groups.setdefault(key,[]).append(r)
            enum_error=max(enum_error,abs(computed[key[:2]][int(r['mask'])]-float(r['gain'])))
    check(len(groups)==18 and all(len(v)==4096 for v in groups.values()),'M1 enumeration counts')
    check(enum_error<1e-12,'M1 enumerated gain error')
    max_cost_error=0.; max_opt_error=0.; max_bound_violation=0.
    cond=rows('evidence/M1_bridge/M1_condition_results.csv')
    for r in cond:
        key=r['direction'],float(r['strength']),r['cost_condition']; subset=groups[key]
        bymask={int(x['mask']):x for x in subset}
        single=np.array([float(bymask[1<<i]['cost']) for i in range(len(U))])
        for mask,x in bymask.items():
            cost=float(bits[mask]@single)
            max_cost_error=max(max_cost_error,abs(cost-float(x['cost'])))
            check((x['feasible']=='True')==(cost<=float(r['budget'])+1e-12),'Feasibility mismatch')
        best=max(float(x['gain']) for x in subset if x['feasible']=='True')
        max_opt_error=max(max_opt_error,abs(best-float(r['optimal_gain'])))
        max_bound_violation=max(max_bound_violation,best-float(r['fractional_total_bound']),float(r['headroom'])-float(r['headroom_upper_bound']))
    check(max_cost_error<1e-12 and max_opt_error<1e-12 and max_bound_violation<1e-12,'M1 cost/optimum/bound mismatch')
    bridge=rows('evidence/M1_bridge/M1_M2_bridge_worlds.csv')
    terms=['information_geometry','D_anchor_correction','score_MC_remainder','parameter_linearization_gap','link_linearization_gap']
    errors=[abs(float(x['actual'])-sum(float(x[k]) for k in terms)) for x in bridge]
    check(len(bridge)==4096 and len({x['world_id'] for x in bridge})==4096,'Bridge world count')
    check(max(errors)<1e-12,'Risk accounting error')
    expected=read('evidence/M1_bridge/M1_M2_bridge_verification.json')['means']
    for k,v in expected.items():
        check(abs(sum(float(r[k]) for r in bridge)/len(bridge)-v)<1e-12,'Bridge mean mismatch '+k)
    acceptance=read('evidence/M2_original/M2_FINAL_ACCEPTANCE.json')
    counts=Counter(r['verdict'] for r in acceptance['mandatory_mechanisms'])
    check(dict(counts)=={'supports_meaningful_registered_direction':2,'opposite_direction':4,'meaningful_registered_positive_excluded':2},'Original M2 verdict count')
    check(all(acceptance['items'].values()) and acceptance['M2_complete'],'Original acceptance incomplete')
    lr=rows('evidence/M2_reversal/LR_primary_summary.csv');xgb=rows('evidence/M2_reversal/XGB_primary_summary.csv')
    def one(table,arm,contrast):return next(r for r in table if r['arm']==arm and r['contrast']==contrast)
    check(float(one(lr,'full','K_sub')['high'])<0,'LR reversal no longer confirmed')
    treated=one(lr,'known_business_slope','K_sub')
    check(0<float(treated['low'])<float(treated['high'])<1e-4,'LR recovery scope mismatch')
    xb=one(xgb,'known_business','K_sub');check(float(xb['low'])<0<float(xb['high']),'XGB unresolved interval mismatch')
    h=rows('evidence/M2_reversal/histogram_summary.csv')
    check(float(next(r for r in h if r['contrast']=='calibrated8192')['low'])>1e-4,'Composite recovery threshold mismatch')
    for name in ['full_histogram_change','calibrated_histogram_change']:
        r=next(x for x in h if x['contrast']==name);check(float(r['low'])<0<float(r['high']),'Histogram individual limitation mismatch')
    sources=read('literature/primary_sources.json')['sources'];check(len(sources)==18,'Literature source count')
    check(len({r['id'] for r in sources})==18,'Literature duplicate IDs')
    check(all(r['reading_depth'] and r['url'].startswith('https://') for r in sources),'Missing reading scope')
    ids={x['id'] for x in sources}
    check(all(set(c['literature'])<=ids for c in read('claims.json')),'Unknown literature pointer')
    require_m3_entry('preparation',ROOT)
    blocked=[]
    for mode in ['pilot_training','confirmation_training']:
        try:require_m3_entry(mode,ROOT)
        except RuntimeError:blocked.append(mode)
    check(len(blocked)==2,'Draft silently allowed training')
    return {'passed':True,'manifest_files':len(manifest['files']),'M1_conditions':len(groups),'M1_subsets_recomputed':sum(len(v) for v in groups.values()),'M1_fixed_value_max_error':fixed_error,'M1_all_gain_max_error':enum_error,'M1_subset_cost_max_error':max_cost_error,'M1_optimum_max_error':max_opt_error,'M1_bound_violation':max_bound_violation,'bridge_worlds':len(bridge),'bridge_max_error':max(errors),'original_M2_verdict_counts':dict(counts),'primary_literature_sources':len(sources),'M3_preparation_entry_passed':True,'M3_training_entry_blocked':blocked,'model_fits_run':0,'GPU_required':False,'scope':'This verifies evidence transfer and stated bounds, not literature priority or a fresh full rerun of M2.'}

if __name__=='__main__':
    result=verify()
    (ROOT/'verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(result,ensure_ascii=False,indent=2))
