"""Preparation-only handoff: never silently promote a draft to training."""
from pathlib import Path
import json

def require_m3_entry(mode, root=None):
    root=Path(root or Path(__file__).resolve().parent)
    handoff=json.loads((root/'STAGE_HANDOFF_v1.json').read_text())
    protocol=json.loads((root/'M3_design_draft.json').read_text())
    if mode=='preparation':
        if not handoff.get('M3_preparation_allowed'):
            raise RuntimeError('M3 preparation is not enabled by this handoff')
        return protocol
    if mode not in ('pilot_training','confirmation_training'):
        raise ValueError('Unknown M3 mode')
    failures=[]
    if not handoff.get('M3_'+mode+'_allowed'):
        failures.append('handoff is preparation only')
    if not protocol.get('training_authorized'):
        failures.append('training not enabled')
    if not protocol.get('registration_frozen'):
        failures.append('registration not frozen')
    if not protocol.get('source_hashes_frozen'):
        failures.append('source hashes not frozen')
    if not protocol.get('inference_plan_frozen'):
        failures.append('inference plan not frozen')
    if mode=='confirmation_training':
        if not protocol.get('confirmation_n') or not protocol.get('confirmation_world_ids'):
            failures.append('confirmation N/worlds missing')
        if not protocol.get('literature_comparator_specification_final'):
            failures.append('differential/comparator specification not final')
    if failures:
        raise RuntimeError('M3 training blocked: '+'; '.join(failures))
    # A future registered runner must verify its actual hashes and visibility
    # invariants itself. This document guard is not an OS execution boundary.
    return protocol

if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser()
    parser.add_argument('mode',choices=['preparation','pilot_training','confirmation_training'])
    print(json.dumps(require_m3_entry(parser.parse_args().mode),ensure_ascii=False,indent=2))
