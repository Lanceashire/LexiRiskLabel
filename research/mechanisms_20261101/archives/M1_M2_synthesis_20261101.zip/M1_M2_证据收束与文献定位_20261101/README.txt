先读《文献查重与创新定位.txt》，再读《M1_M2_证据收束.txt》和《M3_准备方案.txt》。
claims.json逐项区分证据、限制与创新定位。literature包含18篇来源和阅读层级。
本包为紧凑交接，不复制全部大型预测记录；完整M2反转包位置和SHA256见SOURCE_INDEX.json。
历史冻结源仅作副本，未改原文件。M3没有训练，本草案不是确认登记。
运行python verify_delivery.py可在仅有numpy的环境复核本包哈希、M1固定收益与枚举结果、M1-M2账本及训练门禁。
