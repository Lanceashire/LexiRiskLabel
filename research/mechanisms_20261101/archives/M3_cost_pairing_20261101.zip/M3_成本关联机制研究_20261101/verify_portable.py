"""Recompute all registered M3 intervals from portable per-world evidence."""
from pathlib import Path
import argparse,gzip,hashlib,json,sys
import numpy as np
import pandas as pd
from scipy.stats import t

def main():
    root=Path(__file__).resolve().parent
    parser=argparse.ArgumentParser();parser.add_argument('--examples',action='store_true');args=parser.parse_args()
    manifest=json.loads((root/'SHA256_MANIFEST.json').read_text())
    for name,h in manifest['files'].items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==h,name
    plan=json.loads((root/'protocols/confirmation_v1_registration.json').read_text())
    f=pd.read_csv(root/'tables/world_contrasts.csv.gz');s=pd.read_csv(root/'tables/summary.csv')
    means=pd.read_csv(root/'tables/world_method_means.csv.gz')
    assert f.world_id.nunique()==plan['confirmation_n']==len(plan['world_ids'])
    assert set(f.world_id)==set(plan['world_ids']) and len(s)==52
    assert len(s[s.role=='primary'])==2 and len(s[s.role=='secondary'])==50
    error=0.
    for r in s.itertuples():
        q=f[(f.learner==r.learner)&(f.contrast==r.contrast)];x=q.loc[q.estimable,'value'].dropna().to_numpy()
        assert len(x)==r.n_worlds
        if len(x)>1:
            se=x.std(ddof=1)/np.sqrt(len(x));radius=t.ppf(1-r.family_alpha/(2*r.family),len(x)-1)*se
            error=max(error,abs(x.mean()-r.mean),abs(se-r.SE),abs(x.mean()-radius-r.low),abs(x.mean()+radius-r.high))
    assert error<1e-12
    accounting=0.
    for learner in ['LR','XGB']:
        q=means[means.learner==learner].pivot(index='world_id',columns=['cost_condition','method'],values='risk')
        derived={}
        for c in ['neutral','information_cheap','information_expensive']:
            derived[f'J/{c}']=q[c,'MinRisk']-q[c,'Pending-aware']
            derived[f'conditioning/{c}']=q[c,'D-only']-q[c,'Pending-aware']
            derived[f'conditioning_batch_interaction/{c}']=(q[c,'D-only']-q[c,'Pending-aware'])-(q[c,'Static-D']-q[c,'Static-Pending'])
            for name,m in [('fixed_count','FixedK-Pending'),('gain_budget','GainBudget-Pending'),('same_count','MinRisk-k'),('spendcap','MinRisk-spendcap'),('matched','CostCountMatched')]:derived[f'{name}/{c}']=q[c,m]-q[c,'Pending-aware']
        derived['price']=derived['J/information_cheap']-derived['J/information_expensive']
        derived['price_conditioning']=derived['conditioning/information_cheap']-derived['conditioning/information_expensive']
        for name,x in derived.items():
            stored=f[(f.learner==learner)&(f.contrast==name)].set_index('world_id').value
            valid=x.notna()&stored.notna();assert x.isna().equals(stored.isna())
            if valid.any():accounting=max(accounting,float(np.max(np.abs(x[valid]-stored[valid]))))
    assert accounting<1e-12
    examples=[]
    if args.examples:
        sys.path.insert(0,str(root/'code'));from audit import one
        plan['_plan_sha256']=hashlib.sha256((root/'protocols/confirmation_v1_registration.json').read_bytes()).hexdigest()
        for p in sorted((root/'examples').glob('w[0-9]*')):examples.append(one((p,plan)))
        assert len(examples)==4
    result={'passed':True,'registered_worlds':plan['confirmation_n'],'primary_intervals_recomputed':2,'secondary_intervals_recomputed':50,
            'maximum_interval_error':error,'maximum_estimand_accounting_error':accounting,'manifest_files':len(manifest['files']),'raw_example_worlds_reconstructed':len(examples),
            'no_GPU_or_new_training_required':True,'scope':'all published interval estimates and per-world risk contrasts; full raw record audit was completed locally and indexed separately'}
    (root/'portable_verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
